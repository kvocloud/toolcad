using System;
using System.Collections.Generic;
using System.Linq;
using NetTopologySuite.Geometries;
using QHPlanningRoads;

class Program
{
    static readonly GeometryFactory Gf = new GeometryFactory();

    static void Assert(bool ok, string name)
    {
        if (!ok) throw new Exception("FAILED: " + name);
        Console.WriteLine("PASS: " + name);
    }

    static Polygon Site()
    {
        return Gf.CreatePolygon(new[] { new Coordinate(0, 0), new Coordinate(100, 0),
            new Coordinate(100, 100), new Coordinate(0, 100), new Coordinate(0, 0) });
    }

    static RoadInput Road(string name, RoadProfile profile, params Coordinate[] coords)
    {
        return new RoadInput { Handle = name, RoadCode = name, Profile = profile, Points = new List<Coordinate>(coords) };
    }

    static void Main()
    {
        var engine = new RoadGeometry();
        var settings = new ProjectSettings();
        var p = new RoadProfile();
        Assert(Math.Abs(p.RightOfWay - 13) < 1e-9, "default 3+7+3 = 13m");
        p.ManagedLCurves = true;
        p.RoadName = "Đường trục CN.1";
        Assert(RoadProfile.Parse(p.Serialize()).ManagedLCurves,
            "managed L arc marker survives XData roundtrip");
        Assert(RoadProfile.Parse(p.Serialize()).RoadName == p.RoadName,
            "Unicode road name survives base64 XData roundtrip");
        p.BuildingSetbackLeft = 4.0;
        p.BuildingSetbackRight = 2.0;
        var roundtripSetback = RoadProfile.Parse(p.Serialize());
        Assert(roundtripSetback.BuildingSetbackLeft == 4.0
            && roundtripSetback.BuildingSetbackRight == 2.0,
            "building setbacks survive section XData roundtrip");
        p.BuildingSetbackLeft = 0.0;
        p.BuildingSetbackRight = 0.0;
        p.ManagedLCurves = false;
        p.RoadName = "";
        Assert(p.WidthSignature() == new RoadProfile { RoadName = "Tuyến khác",
            CurbRadius = 12, RedChamfer = 8 }.WidthSignature(),
            "roads with identical five widths share a section despite different names/R-C");
        Assert(p.WidthSignature() != new RoadProfile { LaneLeft = 4.0 }.WidthSignature(),
            "changing a component width creates a distinct road section");
        var single = engine.Build(Site(), new[] {
            Road("RD1", p, new Coordinate(10,50), new Coordinate(90,50))
        }, settings);
        Assert(Math.Abs(single.RedLine.Area - 80 * 13) < 0.1, "single road area 80m x 13m");
        Assert(Math.Abs(single.Curb.Area - 80 * 7) < 0.1, "single road curb width 7m");
        Assert(single.Curb.IsValid && single.RedLine.IsValid, "single road topology valid");
        Assert(single.BuildingLine == null,
            "zero building setbacks do not duplicate the red line");

        var setbackProfile = new RoadProfile {
            BuildingSetbackLeft = 4.0, BuildingSetbackRight = 2.0
        };
        var setback = engine.Build(Site(), new[] {
            Road("ROW", setbackProfile, new Coordinate(10,50), new Coordinate(90,50))
        }, settings);
        Assert(setback.BuildingLine != null && setback.BuildingLine.IsValid,
            "building-line geometry is valid for 4m/2m setbacks");
        Assert(Math.Abs(setback.BuildingLine.Area - 80 * 19) < 0.1,
            "building-line footprint offsets from both red-line edges");
        Assert(Math.Abs(setback.RedLine.Area - single.RedLine.Area) < 0.1,
            "setbacks do not change the red-line area used by land audit");

        var noBoundary = engine.Build(null, new[] {
            Road("NoSite", p, new Coordinate(10, 50), new Coordinate(90, 50))
        }, settings);
        Assert(!noBoundary.HasPlanningBoundary, "concept mode explicitly records no boundary");
        Assert(noBoundary.ComputationSite != null && noBoundary.ComputationSite.IsValid,
            "concept mode has a valid temporary computational frame");
        Assert(Math.Abs(noBoundary.RedLine.Area - 80 * 13) < 0.1,
            "no-boundary road still has a valid provisional area");

        var utmNoBoundary = engine.Build(null, new[] {
            Road("UTM", p, new Coordinate(585528.492, 2353082.736),
                new Coordinate(585608.492, 2353082.736))
        }, settings);
        Assert(Math.Abs(utmNoBoundary.RedLine.Area - 80 * 13) < 0.1,
            "concept mode works with real-world large map coordinates");

        var noBoundaryCross = engine.Build(null, new[] {
            Road("Main", p, new Coordinate(0, 50), new Coordinate(100, 50)),
            Road("Cross", p, new Coordinate(50, 0), new Coordinate(50, 100))
        }, settings);
        Assert(noBoundaryCross.Junctions.Count == 1,
            "concept mode detects junctions without a site polygon");
        Assert(noBoundaryCross.CenterlineCurves.Count == 0,
            "X crossing never bends any road centerline");
        Assert(noBoundaryCross.Curb.IsValid && noBoundaryCross.RedLine.IsValid,
            "concept mode retains valid intersection geometry");

        var roads = new[] {
            Road("RD1", p, new Coordinate(-10,50), new Coordinate(110,50)),
            Road("RD2", p, new Coordinate(50,-10), new Coordinate(50,110))
        };
        var cross = engine.Build(Site(), roads, settings);
        Assert(cross.Junctions.Count == 1, "one X junction");
        Assert(cross.RedLine.Area > cross.Curb.Area, "red line includes sidewalks");
        Assert(cross.RedLine.Area < Site().Area, "road inside site");
        Assert(cross.Curb.IsValid && cross.RedLine.IsValid, "X topology valid");

        var noCorner = new RoadProfile { CurbRadius = 0, RedChamfer = 0 };
        var plain = engine.Build(Site(), new[] {
            Road("RD1", noCorner, new Coordinate(-10,50), new Coordinate(110,50)),
            Road("RD2", noCorner, new Coordinate(50,-10), new Coordinate(50,110))
        }, settings);
        Assert(cross.Curb.Area > plain.Curb.Area, "R8 expands curb footprint at corners");
        Assert(cross.RedLine.Area > plain.RedLine.Area, "C6 expands red-line footprint at corners");

        var t = engine.Build(Site(), new[] {
            Road("Main", p, new Coordinate(0,50), new Coordinate(100,50)),
            Road("Branch", p, new Coordinate(50,80), new Coordinate(50,51))
        }, settings);
        Assert(t.ExtendedEndpoints >= 1, "T branch gap 1m extended");
        Assert(t.Junctions.Count >= 1, "T junction identified");
        Assert(t.CenterlineCurves.Count == 0, "T junction retains straight tim");

        var asymmetric = new RoadProfile { LaneLeft = 4, LaneRight = 3,
            SidewalkLeft = 2, SidewalkRight = 3, Median = 1 };
        var unequal = engine.Build(Site(), new[] {
            Road("Unequal", asymmetric, new Coordinate(10,50), new Coordinate(90,50))
        }, settings);
        Assert(Math.Abs(unequal.RedLine.Area - 80 * asymmetric.RightOfWay) < 0.1,
            "asymmetric profile area");
        Assert(unequal.Median.Area > 0, "median generated");

        var divided = new RoadProfile { Median = 2, MedianSetback = 20 };
        var dividedCross = engine.Build(Site(), new[] {
            Road("EW", divided, new Coordinate(0,50), new Coordinate(100,50)),
            Road("NS", divided, new Coordinate(50,0), new Coordinate(50,100))
        }, settings);
        Assert(dividedCross.Median.IsValid, "median topology valid at a crossing");
        Assert(!dividedCross.Median.Intersects(Gf.CreatePoint(new Coordinate(50,50)).Buffer(19)),
            "median has a rounded 20m setback around the junction");

        var tRound = engine.Build(Site(), new[] {
            Road("EW", p, new Coordinate(0,50), new Coordinate(100,50)),
            Road("N", p, new Coordinate(50,50), new Coordinate(50,100))
        }, settings);
        var plainProfile = new RoadProfile { CurbRadius = 0, RedChamfer = 0 };
        var tSharp = engine.Build(Site(), new[] {
            Road("EW", plainProfile, new Coordinate(0,50), new Coordinate(100,50)),
            Road("N", plainProfile, new Coordinate(50,50), new Coordinate(50,100))
        }, settings);
        var backOfT = Gf.CreatePolygon(new[] {
            new Coordinate(35,35),new Coordinate(65,35),new Coordinate(65,46),
            new Coordinate(35,46),new Coordinate(35,35)
        });
        Assert(tRound.Curb.SymmetricDifference(tSharp.Curb).Intersection(backOfT).Area < 0.1,
            "R8 does not change the back side of a T junction");
        Assert(tRound.RedLine.SymmetricDifference(tSharp.RedLine).Intersection(backOfT).Area < 0.1,
            "C6 does not change the back side of a T junction");

        var bend = engine.Build(Site(), new[] {
            Road("L", p, new Coordinate(10,50), new Coordinate(50,50), new Coordinate(50,90))
        }, settings);
        var sharpBend = engine.Build(Site(), new[] {
            Road("L", plainProfile, new Coordinate(10,50), new Coordinate(50,50), new Coordinate(50,90))
        }, settings);
        Assert(bend.Junctions.Count >= 1, "one-polyline 90 degree L bend is a corner node");
        Assert(bend.CenterlineCurves.Count == 1,
            "QHBUILD automatically plans one native centerline L arc");
        var lArc = bend.CenterlineCurves.Single();
        Assert(lArc.VertexIndex == 1 && Math.Abs(lArc.CenterlineRadius - 11.5) < 1e-7,
            "centerline radius is inside curb R8 + 3.5m offset");
        Assert(lArc.Entry.Distance(new Coordinate(38.5,50)) < 1e-6
            && lArc.Exit.Distance(new Coordinate(50,61.5)) < 1e-6,
            "L tim arc tangent points match inside curb radius");
        Assert(bend.Curb.Area > sharpBend.Curb.Area, "inside L curb land corner is rounded");
        Assert(bend.RedLine.Area > sharpBend.RedLine.Area, "inside L redline land corner is chamfered");
        Assert(bend.Curb.Covers(Gf.CreatePoint(new Coordinate(53,47)))
            && sharpBend.Curb.Covers(Gf.CreatePoint(new Coordinate(53,47))),
            "back of L curb is closed by a SQUARE MITER with no empty notch");
        Assert(bend.RedLine.Covers(Gf.CreatePoint(new Coordinate(56,44)))
            && sharpBend.RedLine.Covers(Gf.CreatePoint(new Coordinate(56,44))),
            "back of L redline has a squared connected junction");
        // Regression for screenshot OD-002: V1.5 triangular miter only touched
        // both road strips at a vertex and left a genuine land-triangle GAP.
        Assert(bend.Curb.Covers(Gf.CreatePoint(new Coordinate(51,49)))
            && bend.RedLine.Covers(Gf.CreatePoint(new Coordinate(52,48))),
            "L road contains the former triangular gap between strip ends and the miter");
        Assert(!sharpBend.Curb.Covers(Gf.CreatePoint(new Coordinate(45,55)))
            && bend.Curb.Covers(Gf.CreatePoint(new Coordinate(45,55))),
            "R8 acts inside L belly rather than outside its back");
        Assert(!sharpBend.RedLine.Covers(Gf.CreatePoint(new Coordinate(42,58)))
            && bend.RedLine.Covers(Gf.CreatePoint(new Coordinate(42,58))),
            "C6 acts inside L belly rather than outside its back");
        var outsideBack = Gf.CreatePolygon(new[] { new Coordinate(51,44),
            new Coordinate(58,44), new Coordinate(58,49), new Coordinate(51,49),
            new Coordinate(51,44) });
        Assert(bend.Curb.SymmetricDifference(sharpBend.Curb).Intersection(outsideBack).Area < 0.1,
            "L backside does not get an unwanted R8 corner treatment");
        var bendWithT = engine.Build(Site(), new[] {
            Road("L", p, new Coordinate(10,50), new Coordinate(50,50), new Coordinate(50,90)),
            Road("EastArm", p, new Coordinate(50,50), new Coordinate(90,50))
        }, settings);
        Assert(bendWithT.CenterlineCurves.Count == 0,
            "L corner coinciding with three-arm T is not auto curved");
        var bendAgain = engine.Build(Site(), new[] {
            Road("L", p, new Coordinate(10,50), new Coordinate(50,50), new Coordinate(50,90))
        }, settings);
        Assert(Math.Abs(bendAgain.Curb.Area - bend.Curb.Area) < 1e-7
            && Math.Abs(bendAgain.RedLine.Area - bend.RedLine.Area) < 1e-7,
            "same sharp design produces deterministic L curb/red geometry on rebuild");
        var rightBend = engine.Build(Site(), new[] {
            Road("RightL", p, new Coordinate(10,50), new Coordinate(50,50), new Coordinate(50,10))
        }, settings);
        Assert(rightBend.CenterlineCurves.Count == 1
            && rightBend.CenterlineCurves[0].Bulge < 0,
            "right-turn L yields clockwise native bulge, left-turn L counterclockwise");
        Assert(rightBend.Curb.Covers(Gf.CreatePoint(new Coordinate(53,53)))
            && rightBend.RedLine.Covers(Gf.CreatePoint(new Coordinate(56,56))),
            "right-turn L has a square back on both curb and redline");
        var twoRoutesL = engine.Build(Site(), new[] {
            Road("Horizontal", p, new Coordinate(10,50), new Coordinate(50,50)),
            Road("Vertical", p, new Coordinate(50,50), new Coordinate(50,90))
        }, settings);
        Assert(twoRoutesL.Junctions.Count == 1, "two PLINE endpoints form one two-arm L node");
        Assert(twoRoutesL.Curb.Covers(Gf.CreatePoint(new Coordinate(53,47)))
            && twoRoutesL.RedLine.Covers(Gf.CreatePoint(new Coordinate(56,44))),
            "two independent 90-degree roads connect curb AND red backs by square miters");
        Assert(twoRoutesL.Curb.Covers(Gf.CreatePoint(new Coordinate(51,49)))
            && twoRoutesL.RedLine.Covers(Gf.CreatePoint(new Coordinate(52,48))),
            "independent L segments do not leave a disconnected land triangle");
        Assert(tRound.CenterlineCurves.Count == 0 && cross.CenterlineCurves.Count == 0,
            "degree-3 and degree-4 intersections retain existing centerlines");

        var parcelSite = Gf.CreatePolygon(new[] {
            new Coordinate(0,0),new Coordinate(40,0),new Coordinate(40,30),
            new Coordinate(0,30),new Coordinate(0,0)
        });
        var frontageLots = LandGeometry.SplitByFrontage(parcelSite,
            new Coordinate(0,0),new Coordinate(40,0),8,5,80,15);
        Assert(frontageLots.Count == 5, "40m frontage creates five 8m lots");
        Assert(Math.Abs(frontageLots.Sum(l => l.Area) - parcelSite.Area) < 0.01,
            "subdivision reconciles the block's full area");
        Assert(Math.Abs(LandGeometry.FindLandBlocks(parcelSite,
            Gf.CreatePolygon(new[] { new Coordinate(0,0), new Coordinate(40,0),
                new Coordinate(40,5), new Coordinate(0,5), new Coordinate(0,0) })).Sum(p2 => p2.Area)
            - 1000) < 0.01, "land blocks equal site minus road area");

        var oneRow = LandGeometry.SplitByWidthAndDepth(parcelSite,
            new Coordinate(0,0), new Coordinate(40,0),
            new LotSplitOptions { Frontage = 20, Depth = 15, MinArea = 80 });
        Assert(oneRow.Lots.Count == 2, "one row splits two regular 20m lots");
        Assert(oneRow.Remainders.Sum(x => x.Area) > 0,
            "unused back part is explicit, not silently discarded");

        var doubleRows = LandGeometry.SplitByWidthAndDepth(parcelSite,
            new Coordinate(0,0), new Coordinate(40,0),
            new LotSplitOptions { Frontage = 20, Depth = 12, TwoRows = true,
                AccessRoad = true, AccessRoadWidth = 6, MinArea = 80 });
        Assert(doubleRows.Lots.Count == 4, "two rows create four lots");
        Assert(Math.Abs(doubleRows.InternalRoads.Sum(x => x.Area) - 40 * 6) < 0.1,
            "internal access road is exactly 6m wide for rectangle");
        Assert(Math.Abs(doubleRows.Lots.Sum(x => x.Shape.Area)
            + doubleRows.InternalRoads.Sum(x => x.Area) + doubleRows.Remainders.Sum(x => x.Area)
            - parcelSite.Area) < 0.01, "double-sided lot + road + remainder areas reconcile");

        var irregularSite = Gf.CreatePolygon(new[] {
            new Coordinate(-8,0), new Coordinate(40,0), new Coordinate(48,30),
            new Coordinate(-12,30), new Coordinate(-8,0) });
        var irregularPlan = LandGeometry.SplitByWidthAndDepth(irregularSite,
            new Coordinate(-8,0), new Coordinate(40,0),
            new LotSplitOptions { Frontage = 20, Depth = 15, MinArea = 80 });
        Assert(irregularPlan.Lots.Count >= 2,
            "irregular block with lateral projections no longer rejects frontage");
        Assert(Math.Abs(irregularPlan.Lots.Sum(x => x.Shape.Area)
            + irregularPlan.InternalRoads.Sum(x => x.Area)
            + irregularPlan.Remainders.Sum(x => x.Area) - irregularSite.Area) < 0.01,
            "irregular block conserves its total area");
        Console.WriteLine("ROAD GEOMETRY SELF TESTS PASSED");
    }
}
