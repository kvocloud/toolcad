# ASCII-only PowerShell script to support Windows PowerShell 5.1 (AutoCAD 2020).
# Usage: .\build.ps1 -AcadVersion 2020
# Optional: .\build.ps1 -AcadVersion 2020 -AcadDir 'D:\Autodesk\AutoCAD 2020'
param(
    [ValidateSet('2020', '2021', '2022', '2023', '2024')]
    [string]$AcadVersion = '2024',
    [string]$AcadDir = ''
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($AcadDir)) {
    $AcadDir = Join-Path ${env:ProgramFiles} "Autodesk\AutoCAD $AcadVersion"
}

if (-not (Test-Path -LiteralPath $AcadDir -PathType Container)) {
    throw "AutoCAD installation folder was not found: $AcadDir. Pass -AcadDir if installed elsewhere."
}

foreach ($reference in @('AcMgd.dll', 'AcDbMgd.dll', 'AcCoreMgd.dll')) {
    $candidate = Join-Path $AcadDir $reference
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
        throw "Missing AutoCAD reference DLL: $candidate"
    }
}

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'dotnet command was not found. Install Visual Studio / .NET SDK and restart PowerShell.'
}

$project = Join-Path $PSScriptRoot 'src\CadRoads\CadRoads.csproj'
if (-not (Test-Path -LiteralPath $project -PathType Leaf)) {
    throw "Project file was not found: $project"
}

$framework = if ($AcadVersion -eq '2020') { 'net47' } else { 'net48' }

Write-Host "Building for AutoCAD $AcadVersion, .NET Framework $framework" -ForegroundColor Cyan
Write-Host "AutoCAD reference folder: $AcadDir"

& dotnet restore $project "-p:AcadVersion=$AcadVersion" "-p:AutoCadDir=$AcadDir"
if ($LASTEXITCODE -ne 0) {
    throw 'NuGet restore failed. Check the error output and internet / NuGet access.'
}

& dotnet build $project -c Release "-p:AcadVersion=$AcadVersion" "-p:AutoCadDir=$AcadDir" --no-restore
if ($LASTEXITCODE -ne 0) {
    throw 'Compilation failed. Check compiler errors, .NET targeting pack and AutoCAD references.'
}

$outputFolder = Join-Path $PSScriptRoot "src\CadRoads\bin\Release\$framework"
$pluginDll = Join-Path $outputFolder 'QHPlanningRoads.dll'
if (-not (Test-Path -LiteralPath $pluginDll -PathType Leaf)) {
    throw "Build completed but plugin DLL is missing: $pluginDll"
}

Write-Host ''
Write-Host 'BUILD SUCCEEDED' -ForegroundColor Green
Write-Host "Plugin: $pluginDll"
Write-Host "Copy all runtime dependencies from $outputFolder to the same trusted plugin folder."
Write-Host 'In full AutoCAD, run NETLOAD and select QHPlanningRoads.dll.'
