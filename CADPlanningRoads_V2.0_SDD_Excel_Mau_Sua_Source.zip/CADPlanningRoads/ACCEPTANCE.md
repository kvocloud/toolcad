# Checklist nghiệm thu CAD Planning Roads V1.5 (góc L + ô/lô thủ công + block mẫu + mặt cắt)

Trạng thái hiện tại: **Mã nguồn đã viết; chưa build, chưa thử trong AutoCAD**. Các ô dưới đây cần người vận hành AutoCAD 2020–2024 thực hiện.

## CAD-01 — Ranh và layer

- [ ] QHSETUP nhận một LWPOLYLINE khép kín; từ chối ranh tự cắt hoặc diện tích không hợp lệ.
- [ ] QHSETUP với đường `Open` phải hiển thị khoảng cách hai đầu, hỏi `CloseCopy/Cancel`, không tự ý đóng nguồn.
- [ ] Chọn `CloseCopy` trên đường `Open` hợp lệ: bản sao được đóng, hình học gốc và thuộc tính `Open` của nguồn giữ nguyên.
- [ ] Chọn `Cancel`: không ghi ranh nhưng vẫn có thể dùng QHROADS/QHBUILD.
- [ ] Ranh gốc không bị đổi layer, màu, điểm tọa độ hoặc mất đối tượng.
- [ ] Có các layer giao thông được ghi trong README; các layer đất được tạo sau khi gọi lệnh đất.
- [ ] Chạy lại QHSETUP không nhân đôi ranh quản lý.
- [ ] Bản vẽ đang sử dụng mét (1 đơn vị CAD = 1 m), không ép đổi tỷ lệ.

## CAD-02 — Chọn và làm sạch tim

- [ ] QHROADS cho phép chọn hỗn hợp nhiều tim `LINE` và `LWPOLYLINE` hở.
- [ ] LINE đã chọn được thay bằng một LWPOLYLINE có XData; không còn cả LINE và PLINE chồng nhau.
- [ ] Đầu tim chữ T cách tuyến cắt 1,0 m, vuông góc: nối đúng tại giao.
- [ ] Khi khoảng hở lớn hơn ngưỡng QHTOL: không tự nối.
- [ ] Đường gần song song: không nối sai.
- [ ] Đường chéo 45 độ: không tự gán vuông góc.
- [ ] QHBUILD cập nhật **chính tim PLINE đã đăng ký** trên `QH_TIM_DUONG_SACH`; không tạo tim thứ hai.
- [ ] QHEDIT chọn được ngay tim sau QHBUILD và giữ đúng mặt cắt khi sửa.
- [ ] Khi mở DWG tạo từ V1/V1.2: tim sạch trùng thừa **không XData** được dọn sau QHBUILD; tim có XData được giữ.

## CAD-03 — Bó vỉa

- [ ] Mặc định 3,5 m mỗi bên tính từ tim (M=0).
- [ ] Khi dải giữa M=2 m, bó vỉa bên trái = 1+3,5 m, phải = 1+3,5 m.
- [ ] Nút X/T có góc đủ chỗ tạo bo R8, đo kiểm bằng AutoCAD.
- [ ] Nút **chữ T** có bo R8 đúng hai góc **phía bụng nút**, không bo hai góc phía lưng/đối diện nhánh cụt.
- [ ] **Một PLINE tự gấp 90° chữ L:** ngay khi chạy `QHBUILD`, tim chuyển thành **cung native bulge** tại góc; vẫn **chỉ một tim chính** có XData và giữ nguyên handle.
- [ ] **R bó vỉa = 8 m, đường rộng 3,5 m mỗi bên:** đo cung tim bằng `LIST`, bán kính tim phải xấp xỉ **11,5 m**, cong theo phía bụng.
- [ ] Bó vỉa phía bụng R8, phía lưng **hai cạnh gặp nhau góc vuông, không hở, không vát/bo nhầm**. Dùng `DIST`/`LIST` và phóng lớn góc lưng để kiểm tra.
- [ ] `QHBUILD` lần **hai** không làm biến dạng góc lưng, không nhân đôi hoặc bo tiếp tim; sau `SAVE`/`CLOSE`/`OPEN` rồi `QHBUILD` vẫn cho kết quả đó.
- [ ] `QHEDIT` đổi R8 thành R10 rồi `QHBUILD`: tim R13,5 m, bó vỉa phía bụng R10; lưng vẫn vuông. `QHSHIFT` di chuyển toàn tuyến có cung và dựng lại không mất góc.
- [ ] **Nút chữ T và X** giữ nguyên tim thẳng, không tự chèn cung; một đỉnh L trùng đúng nút T cũng **không được bo tim**.
- [ ] **Hai tuyến PLINE riêng gặp đầu tại 90° tạo chữ L:** lưng bó vỉa và lưng chỉ giới cùng nối vuông, không mỗi nét một kiểu; đo tại góc lưng không có khe tam giác.
- [ ] Nút 3 nhánh T và 4 nhánh X không áp dụng miter lưng 2 nhánh; kết quả không đổi so với trước.
- [ ] `QHCLCURVE` là lệnh tương thích gọi lại `QHBUILD`, không còn yêu cầu chọn tim.
- [ ] Nút quá ngắn không được âm thầm tạo cung sai; phải báo cảnh báo.
- [ ] Đầu tuyến, tuyến cong và nút 3/4/5 nhánh được kiểm tra riêng.

## CAD-04 — Chỉ giới đường đỏ

- [ ] Mặc định cách tim 6,5 m mỗi bên (3,5 + 3,0).
- [ ] Chỉ giới được dựng ngoài bó vỉa đúng vỉa hè trái/phải.
- [ ] Nút X/T có góc đủ chỗ vát C6, đo khoảng vát trên hai cạnh.
- [ ] Nút chữ T vát C6 đúng hai góc **phía bụng nút**, không vát phía lưng.
- [ ] Tại L một PLINE tự gấp 90°: chỉ giới đỏ **C6 tại bụng**, góc lưng vẫn nối vuông, kể cả sau `QHBUILD` lần hai.
- [ ] Vát không được làm polygon tự cắt, mất cạnh hoặc vùng âm.
- [ ] Với mặt cắt bất đối xứng, diện tích ranh chính xác theo từng bên.

## CAD-05 — Vùng và diện tích đất giao thông

- [ ] Không chạy QHSETUP vẫn chạy được QHBUILD với các tuyến đã đăng ký; diện tích được ghi rõ là sơ bộ chưa cắt ranh.
- [ ] Trong chế độ không ranh, không xuất ranh quy hoạch giả ra bản vẽ.
- [ ] Sau khi chốt ranh qua QHSETUP, chạy lại QHBUILD chuyển sang diện tích đã cắt ranh; không cần đăng ký lại tim.
- [ ] Vùng đất giao thông không đếm trùng giao lộ.
- [ ] Ranh đường cắt đúng tại biên quy hoạch.
- [ ] QHAREA báo diện tích m² và ha phù hợp với hình học DWG.
- [ ] Đường thẳng 80 × 13 m nằm trọn khu: diện tích 1.040 m².
- [ ] Không có polygon không hợp lệ, tự cắt hoặc lỗi đột ngột.

## Dải phân cách và nút giao

- [ ] Khi M = 2 m và lùi = 20 m, dải phân cách **dừng trước giao điểm tim** và có hai mũi bo tròn; không xuyên qua nút.
- [ ] Kiểm tra bằng `DIST` điểm gần nhất của mũi dải phân cách tới tim nút xấp xỉ 20 m (trong sai số lấy mẫu).
- [ ] Sửa lùi mũi dải phân cách 20 → 15 m bằng `QHEDIT` rồi `QHBUILD`; vị trí mũi cập nhật.
- [ ] Nút chữ T/X, hai bên dải phân cách và đường mặt cắt không đều không gây mảnh thừa tự giao.

## CAD-06 — Nhận diện ô đất còn lại (`QHLAND`)

- [ ] Không có ranh thật: QHLAND báo cần QHSETUP, **không xóa dữ liệu**.
- [ ] Có ranh thật: mỗi ô còn lại được tạo trên `QH_O_DAT` với mã không trùng.
- [ ] Thống kê diện tích có xét lỗ đất, không đếm phần đường đỏ.
- [ ] Có ô/lô cũ: plugin hỏi xác nhận trước khi tạo lại và xóa dữ liệu cũ.

## CAD-07 — Chức năng sử dụng đất (`QHZONE`)

- [ ] Chọn ô `OD-001`, gán `ODT`; XData được cập nhật, sau khi chạy `QHLABEL` thì nhãn được cập nhật.
- [ ] Sau khi ô đã chia, đổi chức năng ở ô mẹ sẽ cập nhật XData lô con.
- [ ] Từ chối ký tự lạ/chứa dấu `|`; không làm mất dữ liệu.
- [ ] Gán `CN.1`, `CN.2`, `CN.10` thành công; nhãn ô mẹ sau `QHLABEL` hiển thị mã đó.
- [ ] Từ chối `.CN`, `CN.`, `CN..1` và chữ có dấu.

## CAD-08 — Chia lô theo mặt tiền (`QHLOT`)

- [ ] Ô chữ nhật mặt tiền 40 m × sâu 30 m, nhập 20 m mặt tiền, 15 m chiều sâu → tạo đúng **2 lô giữa**, tổng 600 m² và còn lại 600 m² ở `QH_DAT_CHUA_CHIA`.
- [ ] Với ô 40 × 30 m, chọn hai dãy sâu 12 m, đường giữa 6 m → **4 lô** và 240 m² đường, không còn đất dư.
- [ ] Với mặt tiền 47 m, chọn 20 m: lô giữa rộng đúng 20 m, hai bên có phần góc/dư không bắt buộc mặt tiền 20 m.
- [ ] Mã lô `OD-001-L001...`, lô góc `OD-001-G001...` và ô mẹ nằm trong XData.
- [ ] Cạnh mặt tiền không phủ hết bề ngang ô vẫn chia được với những ô đơn giản và đủ điều kiện.
- [ ] Ô có lỗ vẫn từ chối; ô đất cần chuyên môn chia thủ công nếu không đủ chiều sâu hoặc hình học không hợp lệ.
- [ ] Diện tích kiểm toán: lô + đường nội bộ + đất chưa chia = diện tích ô mẹ; không âm thầm bỏ diện tích.
- [ ] Khi chia lại ô đã có lô, plugin hỏi xác nhận; giữ các ô khác nguyên vẹn.

## CAD-09 — Block attribute giống mẫu ảnh (`QHLABEL`)

- [ ] Không chồng lớp nhãn cũ sau khi gọi QHLABEL 2 lần.
- [ ] Loại đất xây dựng: block tròn 5 thuộc tính `LOT_CODE`, `DENSITY`, `FLOORS`, `AREA_M2`, `FAR`.
- [ ] `CX`, `MN`: block tròn chỉ có mã lô và diện tích.
- [ ] Có `ATTDEF` trong block definition và `ATTRIB` trên từng insert (kiểm tra `EATTEDIT`).
- [ ] Chỉnh mật độ/tầng/FAR bằng `EATTEDIT`, QHEXPORT phải đọc các giá trị mới.
- [ ] Save/Reopen DWG vẫn giữ thông tin XData sau khi nhãn được tạo lại.
- [ ] `QHLABEL` không còn `eNotApplicable` trên AutoCAD 2020.
- [ ] Block `sdd` từ `assets/block.dxf`: tag A=mã, B=mật độ, C=tầng, D=FAR, E=diện tích.
- [ ] Block `sdd2` từ DXF: tag 1=mã, 2=diện tích; block `VT` có mặt trong bản vẽ.
- [ ] `QHLABELSCALE` đổi đường kính nhãn 8 → 6 m và `QHLABEL` cập nhật đúng kích thước.
- [ ] Sau `EATTEDIT`, `QHEXPORT` đọc thuộc tính mới và giữ lại khi chạy `QHLABEL` lần nữa.

## CAD-09B — Vẽ và sửa ranh thủ công (`QHLA`)

- [ ] `QHLA` → `Lot` → `PickInside`: bấm vùng PLINE kín, sinh lô trên `QH_LO_DAT` và XData ô mẹ.
- [ ] `QHLA` → `EditLot` → chọn lô → `SelectPline`: thay ranh, giữ đúng mã cũ và ô mẹ.
- [ ] Khi tạo lô thủ công đầu tiên, phần còn lại của ô được tính trên `QH_DAT_CHUA_CHIA`; tổng diện tích lô + đất dư = ô mẹ.
- [ ] Lô mới vượt ô mẹ hoặc chồng lấn lô/đường nội bộ bị từ chối; transaction rollback.
- [ ] `QHLA` → `Block` / `EditBlock` hỗ trợ vẽ lại ranh ô; không nhân đôi ô cũ.
- [ ] Kiểm tra tổng lô/đường/đất dư sau chỉnh bằng `QHAUDIT`; trường hợp đất dư có lỗ trả lỗi an toàn.

## CAD-09C — Đường và mặt cắt (`QHNAME`, `QHMCBANG`, `QHMCGAN`, `QHMCVE`)

- [ ] `QHROADS` đăng ký 3 tim và yêu cầu nhập 3 tên riêng, lưu lại sau Save/Open DWG.
- [ ] `QHNAME` đổi tên một tuyến, không làm đổi mặt cắt tuyến khác.
- [ ] Hai tuyến có cùng bề rộng 3/3.5/0/3.5/3 được nhóm một `MC-xx`, tuyến có bề rộng khác tách nhóm.
- [ ] `QHMCGAN` đặt nét cắt ngang từ chỉ giới trái sang chỉ giới phải, chèn hai block `VT` và tên nhóm mặt cắt.
- [ ] `QHMCVE` vẽ đúng số nhóm mặt cắt và mỗi phần có kích thước theo mét, có cảnh báo là sơ đồ ý tưởng.

## CAD-10 — Hậu kiểm (`QHAUDIT`)

- [ ] Ranh - diện tích giao thông - tổng ô đất ≈ 0 trong dung sai báo cáo.
- [ ] Với ô đã chia kín, tổng diện tích các lô bằng diện tích ô mẹ.
- [ ] Cố tình tạo hai lô chồng lấn / lô vượt ranh / ID trùng → có cảnh báo.
- [ ] Cố tình sửa tim hoặc bề rộng đường rồi QHBUILD, chưa QHLAND lại → kiểm toán thấy diện tích không khớp.
- [ ] Cố tình chỉnh diện tích của block attribute sai hình học → cảnh báo lệch.

## CAD-11 — Thống kê và xuất Excel (`QHEXPORT`)

- [ ] Excel `.xlsx` mở được bằng Excel/LibreOffice; tiếng Việt không lỗi dấu.
- [ ] Sheet `Danh sach lo` chứa mã, chức năng, ô mẹ, diện tích m²/ha, mật độ, tầng, FAR từ block khi có dữ liệu.
- [ ] Excel ghi riêng dòng đường nội bộ và đất chưa chia nhưng không cộng lô con trùng vào cơ cấu chức năng ô mẹ.
- [ ] Sheet `Tong hop chuc nang` tổng hợp diện tích **theo ô**; không đếm thêm các lô con.
- [ ] Sheet `Tuyen va mat cat` có tên đường, mã mặt cắt, 5 thành phần bề rộng và lộ giới.
- [ ] Từ chối ghi đè file trùng tên nếu chưa xác nhận.
- [ ] Chọn điểm chèn bảng trong CAD tạo bảng thống kê; bỏ qua bằng Esc vẫn giữ file Excel.
- [ ] Đối chiếu 3 ô bằng AREA trong AutoCAD và tổng sheet trong Excel.

## Sửa tuyến, an toàn, tương thích

- [ ] QHEDIT sửa đúng 1 tuyến đã chọn.
- [ ] QHEDIT sửa tất cả tuyến có cùng mặt cắt hiện tại.
- [ ] QHEDIT sửa tất cả tuyến đã đăng ký.
- [ ] Nhập thay đổi chiều rộng trái/phải, vỉa hè trái/phải, dải giữa và dựng lại đúng.
- [ ] QHBUILD lỗi phải giữ dữ liệu tim và kết quả đường cũ nếu lỗi xảy ra trước commit transaction.
- [ ] QHBUILD lần 2 không nhân đôi kết quả trên các layer đầu ra.
- [ ] `QHSHIFT`: chọn tim, trái 2 m theo chiều vẽ → tim và các lớp đường cùng dịch; một lần gọi không làm trùng nét.
- [ ] `QHSHIFT` không làm thay đổi tim khác ngoài phần nối giao cần thiết; lỗi giữa thao tác phải rollback trong transaction.
- [ ] Undo sau QHBUILD khôi phục kết quả trước đó.
- [ ] Save/Close/Reopen DWG vẫn giữ được mặt cắt từng tim.
- [ ] NETLOAD và chạy được trong CAD 2020, 2021, 2022, 2023, 2024 (build riêng).
- [ ] Test tối thiểu 3 DWG: lưới chữ X, giao T bị hở, mạng lưới có đường cong.

**Chỉ đánh dấu sẵn sàng dùng cho hồ sơ chính thức sau khi các test trên đạt và bản vẽ được kiểm tra chuyên môn.**
