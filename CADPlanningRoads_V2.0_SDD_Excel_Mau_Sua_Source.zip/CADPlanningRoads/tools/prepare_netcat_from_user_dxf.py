"""Extract the actual *U24 section-cut heads from the supplied metric DXF.

The user's netcat is an anonymous block, not a block named 'netcat'.
Split its six decorative polylines and two ATTDEF into two named blocks;
the original model-space examples and source blocks remain intact.
The dashed middle is rebuilt parametrically by QHMCGAN from actual ROW.

Usage: python tools/prepare_netcat_from_user_dxf.py
Requires: pip install ezdxf
"""
from pathlib import Path
import math

import ezdxf
from ezdxf.math import Matrix44

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "assets" / "block_source_user_meters.dxf"
TARGET = ROOT / "assets" / "block.dxf"

LEFT = "QH_NETCAT_TRAI_V17"
RIGHT = "QH_NETCAT_PHAI_V17"


def main():
    doc = ezdxf.readfile(SOURCE)
    assert doc.header.get("$INSUNITS") == 6, "Source DXF must use metres"
    sample = doc.blocks["*U24"]
    line = next(iter(sample.query("LINE")))
    a, b = line.dxf.start, line.dxf.end
    theta = math.atan2(a.y - b.y, a.x - b.x)
    span = a.distance(b)
    assert span > 1, "Invalid sample cut line"

    rotate = Matrix44.z_rotate(-theta)
    for side, name, xcenter in (
        ("left", LEFT, -span / 2),
        ("right", RIGHT, span / 2),
    ):
        if name in doc.blocks:
            raise RuntimeError(f"The template already has {name}")
        out = doc.blocks.new(name)
        count = 0
        for ent in sample:
            if ent.dxftype() == "LWPOLYLINE":
                vertices = list(ent.get_points("xy"))
                sx = sum(pt[0] for pt in vertices) / len(vertices)
                sy = sum(pt[1] for pt in vertices) / len(vertices)
            elif ent.dxftype() == "ATTDEF":
                sx, sy = ent.dxf.insert.x, ent.dxf.insert.y
            else:
                continue
            side_coord = sx * math.cos(theta) + sy * math.sin(theta)
            if (side == "left" and side_coord >= 0) or (
                side == "right" and side_coord < 0
            ):
                continue
            copy = ent.copy()
            copy.transform(rotate)
            copy.transform(Matrix44.translate(-xcenter, 0, 0))
            copy.dxf.layer = "0"
            copy.dxf.discard("linetype")
            if copy.dxftype() == "ATTDEF":
                copy.dxf.tag = "SO"
                copy.dxf.text = "1"
                copy.dxf.prompt = "So mat cat"
                copy.dxf.style = "Standard"
                copy.dxf.rotation = 0
            out.add_entity(copy)
            count += 1
        assert count == 4, f"Expected three polyline graphics + one number on {side}, got {count}"

    doc.saveas(TARGET)
    print(f"Prepared metric block.dxf with original section-cut heads: {LEFT}, {RIGHT}")


if __name__ == "__main__":
    main()
