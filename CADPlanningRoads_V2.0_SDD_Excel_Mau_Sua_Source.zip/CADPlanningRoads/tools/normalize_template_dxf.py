"""Produce separate metric block definitions without overwriting user sdd/sdd2.

Requires: pip install ezdxf
The original assets/block.dxf is preserved as an unmodified reference.
"""
from pathlib import Path
import ezdxf
from ezdxf.math import Matrix44

base = Path(__file__).resolve().parents[1] / "assets"
doc = ezdxf.readfile(str(base / "block.dxf"))
scale = 8.0 / 71.52708859851714
for before, after in (
    ("sdd", "QH_SDD_METRIC_V16"),
    ("sdd2", "QH_SDD2_METRIC_V16"),
):
    if after in doc.blocks:
        raise RuntimeError("Metric block already exists: " + after)
    original = doc.blocks[before]
    block = doc.blocks.new(after, base_point=(0, 0, 0))
    block.block_record.dxf.units = 6  # metres
    for element in original:
        entity = element.copy()
        entity.transform(Matrix44.scale(scale, scale, scale))
        block.add_entity(entity)
doc.header["$INSUNITS"] = 6  # metres; all new block symbols 8m at scale 1
doc.saveas(str(base / "block_metric.dxf"))
print("Generated metric block templates at 1:1")
