# Hướng dẫn cài đặt CAD Planning Roads V1.8 (AutoCAD 2020–2024)

**V1.8:** `QHLABEL` mac dinh `Both`, `QHLABELSCALE` doi ngay ca nhan o va lo da co; `QHTENLO` nhap tien to `CN.1.` + so bat dau 1, chon lien tuc block `sdd2`; `QHMCGAN` dong thanh **1 block** voi 2 block dau + 1 polyline dut dung lo gioi, `QHMCSCALE` chi thay ty le dau/text; `QHMCVE` ve DIM tung be rong, chu "CHI GIOI DUONG DO" xoay dung, hoa gio o tim. Xem `V1.8_ACCEPTANCE_VI.md` de test.

## Lịch sử V1.7

**Mới trong V1.7:** `QHLA` → `Lo` → bấm trực tiếp nhiều vùng khép kín liên tục → Enter, tự xác định ô mẹ, không cần `Next`/chọn ô mẹ mỗi lần; `QHTENLO`/`QHLOTNAME` đổi mã lô; thứ tự hiển thị `QH_O_DAT` trên `QH_LO_DAT`; `QHMCGAN` dùng hình gốc của block *U24 trong file `block.dxf` đã tách thành hai đầu, kết nối bằng nét đứt đúng lộ giới; `QHMCVE` thêm kết cấu 0.6m/0.2m, chỉ giới đường đỏ và DIM tổng. `QHLABEL` mặc định chèn đúng block gốc `sdd/sdd2` với Scale=1 (ký hiệu sdd gốc trong DXF lớn khoảng 71.527m; tùy chỉnh `QHLABELSCALE` khi cần). Xem `V1.7_ACCEPTANCE_VI.md`.

**Mục tiêu:** đây là mã nguồn cần build trên Windows và kiểm thử trên bản sao DWG; không được coi là đã nghiệm thu AutoCAD chỉ vì script build thành công.

## Lịch sử V1.6

Bản vá V1.6: lưng chữ L (miter tứ giác), QHROADS tên N1 tự động và text trên tim, QHLA Next/Done nhiều vùng, QHDU ẩn/hiện phần dư, QHLABEL Lots 2 ATTRIB và block mét tỷ lệ 1:1, sửa GetEntity QHMCGAN và QHLA SelectPline, thêm nét đứng bó vỉa trong QHMCVE.

**Quan trọng:** làm trên bản sao DWG. Thoát CAD trước khi nạp DLL mới. QHBUILD không xóa ô/lô cũ; để xóa OD-002 sai, chạy QHLAND rồi chọn Replace, biết rằng lệnh này xóa toàn bộ ô/lô và chức năng đã gán.

**V1.5** bổ sung nối vuông lưng L cho hai tuyến riêng, QHLA sửa ranh ô/lô thủ công, QHZONE mã CN.1, block sdd/sdd2/VT từ DXF mẫu, tên tuyến và mặt cắt. Bản này **chưa được chạy biên dịch và NETLOAD trực tiếp trong AutoCAD** tại môi trường tạo gói; cần làm đủ checklist `ACCEPTANCE.md` trước khi dùng sản xuất.

**V1.3.1** sửa lỗi build `CS0136` với hai biến `start`/`end` trong `LandCommands.cs` mà người dùng AutoCAD 2020 đã báo.

Phiên bản V1.1 sửa script `build.ps1` để Windows PowerShell 5.1 đọc an toàn: nội dung script là ASCII, không còn lỗi tiếng Việt UTF-8 thiếu BOM. V1.2 cho dựng đường không cần thiết lập ranh. **V1.3** sửa một tim chính duy nhất, bo/vát phía bụng nút giao, lùi dải phân cách 20 m, thêm các lệnh ô đất/chia lô/XLSX. **Mã nguồn V1.3 chưa được biên dịch, NETLOAD hoặc nghiệm thu trong AutoCAD tại môi trường tạo gói.**

## 1. Máy cần có

1. Windows 10/11, AutoCAD 2020–2024 bản đầy đủ (không dùng AutoCAD LT).
2. Visual Studio hoặc Visual Studio Build Tools hỗ trợ C#/.NET desktop, kèm .NET SDK có lệnh `dotnet`.
3. **AutoCAD 2020**: .NET Framework **4.7 Developer Pack / Targeting Pack**.
4. **AutoCAD 2021–2024**: .NET Framework **4.8 Developer Pack / Targeting Pack**.
5. Kết nối Internet trong lần đầu NuGet khôi phục gói `NetTopologySuite`.

Lưu ý: .NET Framework **runtime** có sẵn trên Windows không luôn đồng nghĩa với **Developer Pack** cần để build.

## 2. Giải nén gói nguồn

Giải nén gói ZIP vào thư mục riêng. Ví dụ:

```text
E:\Setup\CAD\CADPlanningRoads_V1.7\CADPlanningRoads\
```

Trong thư mục `CADPlanningRoads` phải có:

- `build.ps1`
- `src\CadRoads\CadRoads.csproj`
- `README.md`
- `INSTALL_WINDOWS_AUTOCAD_2020-2024.md`
- `tests\CAD-Scripts\test_cross.scr`
- `tests\CAD-Scripts\test_t_gap.scr`

## 3. Kiểm tra môi trường trong PowerShell

Mở **Developer PowerShell for Visual Studio** hoặc PowerShell bình thường, nhập:

```powershell
dotnet --version
```

Nếu lệnh không tồn tại: cài .NET SDK/C# build tools và **mở lại** cửa sổ PowerShell.

Kiểm tra thư mục AutoCAD 2020 mặc định:

```powershell
Test-Path 'C:\Program Files\Autodesk\AutoCAD 2020\AcMgd.dll'
Test-Path 'C:\Program Files\Autodesk\AutoCAD 2020\AcDbMgd.dll'
Test-Path 'C:\Program Files\Autodesk\AutoCAD 2020\AcCoreMgd.dll'
```

Ba lệnh cần trả về `True`. Nếu có `False`, tìm thư mục AutoCAD đang cài; truyền đường dẫn đó bằng `-AcadDir` ở bước build. Không chép Autodesk DLL sang dự án để né lỗi.

Kiểm tra .NET Framework **4.7 Targeting Pack** (AutoCAD 2020):

```powershell
Test-Path 'C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.7'
```

Nếu `False`, cài .NET Framework 4.7 Developer Pack/targeting pack từ Microsoft hoặc bổ sung qua Visual Studio Installer.

## 4. Biên dịch plugin AutoCAD 2020

Chuyển đến thư mục chứa `build.ps1` (điều chỉnh đường dẫn theo máy):

```powershell
Set-Location 'E:\Setup\CAD\CADPlanningRoads_V1.4\CADPlanningRoads'
```

Biên dịch:

```powershell
.\build.ps1 -AcadVersion 2020
```

Nếu AutoCAD cài ở ổ D, ví dụ:

```powershell
.\build.ps1 -AcadVersion 2020 -AcadDir 'D:\Autodesk\AutoCAD 2020'
```

Nếu PowerShell cấm chạy script theo Execution Policy, có thể dùng quyền tạm thời **chỉ ở tiến trình hiện tại** (không sửa chính sách toàn máy):

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\build.ps1 -AcadVersion 2020
```

Không chạy bước này nếu chính sách của tổ chức không cho phép hoặc có Group Policy chặn. Không cần `Run as Administrator` chỉ để build.

Khi thành công, script in `BUILD SUCCEEDED` và tạo:

```text
src\CadRoads\bin\Release\net47\QHPlanningRoads.dll
```

Các phiên bản khác:

| AutoCAD | Lệnh | Thư mục đầu ra |
| --- | --- | --- |
| 2020 | `.\build.ps1 -AcadVersion 2020` | `bin\Release\net47` |
| 2021 | `.\build.ps1 -AcadVersion 2021` | `bin\Release\net48` |
| 2022 | `.\build.ps1 -AcadVersion 2022` | `bin\Release\net48` |
| 2023 | `.\build.ps1 -AcadVersion 2023` | `bin\Release\net48` |
| 2024 | `.\build.ps1 -AcadVersion 2024` | `bin\Release\net48` |

Phải build/test riêng với Autodesk DLL tương ứng mỗi đời CAD. Các bản 2021–2024 cùng `net48` nên đầu ra có thể ghi đè nhau: **sao chép đầu ra từng phiên bản sang thư mục riêng** trước khi build bản tiếp theo.

## 5. Nạp plugin vào AutoCAD (quan trọng nếu đã dùng V1.2)

1. Sao chép **toàn bộ file DLL phụ thuộc runtime** từ `src\CadRoads\bin\Release\net47\` (không chỉ `QHPlanningRoads.dll`) sang thư mục plugin riêng, ví dụ `E:\Setup\CAD\QHPlugin2020\`.
2. Nếu đang chạy V1/V1.2, **lưu và đóng HẾT phiên AutoCAD** trước. DLL .NET đã NETLOAD thường không được thay thế trực tiếp trong cùng phiên. Mở lại AutoCAD 2020 bản đầy đủ và **một DWG thử nghiệm**.
3. Nếu AutoCAD chặn vì đường dẫn không tin cậy, vào `OPTIONS` → tab **Files** → **Trusted Locations**, thêm **chỉ đúng thư mục plugin**. Không tắt SECURELOAD toàn cục.
4. Gõ `NETLOAD` trong command line; chọn `E:\Setup\CAD\QHPlugin2020\QHPlanningRoads.dll`.
5. Gõ `QHHELP`. Nếu hiển thị các lệnh, plugin đã được nạp; bước tiếp theo vẫn phải kiểm thử hình học.

## 6. Quy trình thử CAD-01 đến CAD-11

1. Tạo bản sao DWG để thử. Xác nhận **1 đơn vị CAD = 1 mét**. Nếu file đang dùng mm, chuyển đổi bản vẽ một cách có kiểm soát trước; đổi `INSUNITS` đơn thuần không có nghĩa là tọa độ tự chuyển mm sang m.
2. Gõ `SCRIPT`, chọn `tests\CAD-Scripts\test_t_gap.scr` trên **DWG trống** hoặc tự tạo ranh quy hoạch bằng `LWPOLYLINE` kín và hai tim đường bằng `LWPOLYLINE` hở.
3. **Có thể bỏ qua `QHSETUP`** khi muốn phát triển mạng đường trước. Nếu cần chọn ranh đang `Open`, dùng `QHSETUP`, xem khoảng cách hai đầu và chọn `CloseCopy` khi xác nhận đoạn nối thẳng là đúng; lựa chọn này chỉ đóng bản sao.
4. `QHROADS` → chọn 2 tim dạng `LINE` và/hoặc `PLINE` → hộp mặt cắt, giữ 3,5+3,5 m lòng đường, 3+3 m vỉa hè, R8, C6; nếu có dải phân cách chọn M (ví dụ 2 m) và khoảng lùi mũi 20 m → Lưu.
5. `QHBUILD` → kiểm tra **chỉ một tim** trên layer `QH_TIM_DUONG_SACH`, bó vỉa và chỉ giới đỏ. Không có ranh thì nhận thông báo **diện tích sơ bộ chưa cắt ranh**. Kiểm tra cung R8 và vát C6 phía **bụng** nút, dải phân cách dừng 20 m trước nút.
6. `QHAREA` → kiểm tra diện tích vùng giao thông theo m²/ha và trạng thái cắt ranh.
7. `QHEDIT` → chọn 1 tim → sửa các thông số rồi chạy lại `QHBUILD`.
8. `QHTOL` → thử đổi ngưỡng tự nối đường vuông góc nếu cần.
9. Thử thêm script `test_cross.scr` trong **DWG trống khác**, và các test tại `ACCEPTANCE.md`.
10. **Để làm các bước ô đất, bắt buộc có ranh thật:** chạy `QHSETUP` chọn ranh chính xác → `QHBUILD` lại → `QHLAND` để sinh ô đất.
11. `QHZONE`: chọn ô → nhập mã `ODT`, `CX`, `MN`, `TMDV`...; `QHLOT`: chọn ô và cạnh mặt tiền thẳng → nhập mặt tiền và **chiều sâu**, chọn chia **2 dãy hay không**, nếu có chọn **đường nội bộ** và bề rộng. Lưu ý đất chưa chia hiện tại được giữ ở `QH_DAT_CHUA_CHIA`.
12. `QHLABEL`: chọn `Blocks/Lots/Both`, tạo block attribute, dùng `EATTEDIT` chỉnh mật độ xây dựng, tầng cao, FAR trên từng block. `QHAUDIT`: kiểm tra đối chiếu diện tích block với polygon.
13. `QHEXPORT`: chọn nơi lưu `.xlsx`, mở Excel kiểm tra hai sheet, bao gồm các chỉ tiêu từ ATTRIB. Chọn điểm đặt bảng thống kê CAD hoặc nhấn Esc để bỏ qua.
14. `QHSHIFT`: chọn tim đang có XData, chọn `Left/Right`, nhập khoảng cách. Lệnh tịnh tiến toàn bộ tuyến và dựng lại các lớp bó vỉa/chỉ giới/đường giao thông. Lưu ý có thể phải làm lại ô/lô.
15. Với **một PLINE tự gấp 90° chữ L**, chỉ cần `QHBUILD` là tim được bo cong bằng bulge native; nút T/X không bo tim. Bó vỉa bụng R8, lưng nối vuông, chỉ giới bụng C6, lưng nối vuông. **Bắt buộc** chạy `QHBUILD` thêm lần nữa, `SAVE`/mở lại, thử `QHEDIT` rồi đối chiếu. `QHCLCURVE` chỉ là lệnh tương thích gọi `QHBUILD`.

### Kiểm thử chức năng V1.5

1. Trên **DWG thử nghiệm**, chạy `SCRIPT` với `tests\CAD-Scripts\test_two_routes_l.scr`; `QHROADS` chọn **hai tim riêng**, nhập tên từng tuyến và cùng mặt cắt 3 + 7 + 3. Chạy `QHBUILD`. Phóng to góc lưng: mép bó vỉa và chỉ giới đều phải kết thúc ở góc vuông kín. Kiểm tra riêng hình T/X, không được miter kiểu L tại nút có 3/4 nhánh.
2. Chạy `QHLAND` sau khi có ranh thực; `QHZONE` gán `CN.1`, `CN.10`. Chạy `QHLABEL` chọn `Blocks`: block `sdd` nhập từ resource DXF nhúng. Dùng `EATTEDIT` sửa mật độ/tầng/FAR và lệnh `LIST` kiểm tra `ATTRIB`. Với ô `CX.1` hoặc `MN.1`, dùng `sdd2` hai thuộc tính. Nếu cần, `QHLABELSCALE` đặt đường kính ký hiệu, mặc định 8 m.
3. `QHLA` → `Lot` → `PickInside`, bấm trong đường bao kín để tạo lô thủ công, hoặc chọn `SelectPline` để dùng PLINE có sẵn. `QHLA` → `EditLot`, chọn một lô đã có rồi chọn ranh mới. Kiểm tra `QHAUDIT` không chồng lấn, tổng diện tích đúng. `EditBlock` cho phép thay ranh ô đã có nhưng vẫn giữ lô con; phải hậu kiểm lại.
4. `QHMCBANG` kiểm tra các tên đường được gom theo cùng mặt cắt; `QHMCGAN` đặt nét cắt trên một tim, kiểm tra dùng block `VT` mẫu. `QHMCVE` chọn điểm và xác nhận vẽ, tạo sơ đồ mặt cắt của **mỗi nhóm bề rộng**, không phải hồ sơ trắc ngang thi công.
5. `QHEXPORT` kiểm tra thêm sheet `Tuyen va mat cat`, đối chiếu các bề rộng đã nhập khi chạy `QHROADS`.

**Lưu ý:** file `block.dxf` đã được **nhúng trong DLL** khi biên dịch; không cần tự copy DXF để `NETLOAD`. Nhưng phải build từ đầy đủ mã nguồn V1.5, không dùng lại DLL V1.4.1. Không nạp DLL mới đè lên DLL cũ trong cùng phiên AutoCAD; hãy thoát CAD và mở lại trước khi `NETLOAD`.

**Giá trị mặc định:** mỗi bên lòng đường 3,5 m; vỉa hè 3 m; tổng lộ giới 13 m; bó vỉa bo R8; chỉ giới đỏ chamfer C6; dung sai nối đầu tim 1,5 m; dải phân cách khi có M lớn hơn 0 sẽ lùi 20 m từ tâm nút. Chia lô: mặt tiền mục tiêu 8 m, nhỏ nhất 5 m, diện tích nhỏ nhất 80 m², chiều sâu bình quân nhỏ nhất 15 m.

**Nâng cấp DWG cũ:** Trên **bản sao DWG**, `QHBUILD` sẽ di chuyển tim nguồn có XData sang `QH_TIM_DUONG_SACH`, xóa tim sạch **không có XData** do bản cũ tạo. Sau đó chọn ngay tim này bằng `QHEDIT` để sửa. Không nên tự vẽ đối tượng trên layer plugin quản lý. Nếu đã thay đường, các ô/lô cũ cần tạo lại bằng `QHLAND` và `QHLOT` sau khi xác nhận.

## 7. Lỗi thường gặp

| Thông báo | Nguyên nhân có thể | Cách giải quyết |
| --- | --- | --- |
| `The string is missing the terminator: "` | Script V1 dùng UTF-8 không BOM | Dùng script ASCII mới, hoặc lưu V1 thành UTF-8 **with BOM** |
| `dotnet is not recognized` | Chưa có .NET SDK hoặc chưa có PATH | Cài SDK/C# build tools, mở PowerShell mới |
| `AutoCAD installation folder was not found` | AutoCAD cài nơi khác | Chỉ định `-AcadDir 'đường dẫn thực tế'` |
| `Missing AutoCAD reference DLL` | Sai đường dẫn hoặc cài đặt AutoCAD không đầy đủ | Kiểm tra 3 DLL Autodesk trong thư mục AutoCAD |
| `MSB3644` | Thiếu .NET Framework targeting pack | Cài Developer Pack 4.7 (CAD 2020) hoặc 4.8 (CAD 2021–2024) |
| `NU1301`, `NU1101` | Không truy cập/khôi phục được NuGet | Kiểm tra Internet, nguồn NuGet và proxy tổ chức |
| `CSxxxx` hoặc `MSBxxxx` | Lỗi mã nguồn/API hoặc toolchain khác | Gửi **toàn bộ log** để xác định và sửa đúng lỗi, không tự nhận build đã thành công |
| `Unknown command QHSETUP` | DLL chưa NETLOAD hoặc NETLOAD thất bại | Kiểm tra cửa sổ lệnh AutoCAD và đường dẫn plugin |
| AutoCAD chặn DLL | Đường dẫn không được tin cậy | Thêm đúng thư mục plugin vào **Trusted Locations** |
| Không thấy lớp đường hoặc diện tích sai | Đầu vào không đúng đơn vị/PLINE hoặc lỗi nút giao | Thử script mẫu, đọc cảnh báo QHBUILD, kiểm tra thủ công trong DWG |
| `QHLAND` báo chưa thiết lập ranh | Chỉ giao thông ý tưởng, chưa dùng `QHSETUP` | Chọn ranh thật trong QHSETUP, chạy QHBUILD rồi QHLAND |
| `QHLOT` từ chối chia | Ô có lỗ, mặt tiền không đủ bao chiều ngang, lô nhỏ hoặc quá phức tạp | Đổi cạnh mặt tiền, điều chỉnh chỉ tiêu hoặc chia thủ công rồi kiểm tra |
| AutoCAD vẫn dùng lệnh bản cũ | Đã NETLOAD DLL cũ trong tiến trình AutoCAD đang chạy | Đóng mọi phiên AutoCAD, mở lại rồi NETLOAD đúng DLL V1.3 |

## 8. Đối chiếu trước nghiệm thu

Hồ sơ chưa được coi là hoàn thành chỉ vì `BUILD SUCCEEDED`: cần chạy `ACCEPTANCE.md` trên AutoCAD thực, đo đúng R8/C6, xác minh rollback/undo, bảo toàn dữ liệu gốc và kiểm tra kết quả trên từng đời CAD. Không sử dụng trực tiếp cho hồ sơ quy hoạch chính thức trước khi kiểm tra chuyên môn.
