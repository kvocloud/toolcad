# CAD Planning Roads V2.0 — nhan o/lo doc lap, net cat CGXD, Excel co cong thuc

**V2.0: source patch tren V1.9; chua bien dich hoac nghiem thu NETLOAD tren AutoCAD Windows.**

- `QHSDDEXPORT`: xuat **o dat me va lo dat con** tren sheet `Bang SDD` theo thu tu me → con. Cot K:M an lan luot `CAD_KIND`, `CAD_USE_CODE`, `CAD_PARENT`; cot J `CAD_HANDLE` giu khoa lien ket CAD. Tinh tong o me bang `SUMIF` voi `CAD_KIND=BLOCK`, tong lo con bang `SUMIF` voi `CAD_KIND=LOT` **RIENG**, khong cong trung. Dien tich ha va ty le deu la cong thuc.
- Sheet `Tong hop SDD`: cot dien tich dung `SUMIFS` tham chieu thang sang `Bang SDD`; tong bang `SUM`, `ha` va `%` cung dung cong thuc. Excel duoc danh dau full recalc khi mo file. `QHSDDIMPORT` bo qua cac hang `LOT`, chi cap nhat chi tieu G/H/I cua o me; tuyet doi khong lay SUM area lo con lam tong o me.
- `QHLABELSCALE`: chon `ODat/LoDat/CaHai` va nhap duong kinh tung loai; lenh tat `QHSCALEO`, `QHSCALELO`. Phan loai **theo XData/link toi o/lo**, khong theo ten `sdd2` (vi o cay xanh/mat nuoc cung dung `sdd2`). `QHLABEL` chay lai se giu kich thuoc cua tung nhan da co.
- `QHMCGAN`: hai dau netcat duoc mirror hinh hoc theo truc local X de dau mui ten huong len; text ATTREF cua block nhom khong bi mirror. `QHMCFIX` cap nhat cac net cat nhom V18+ da chen tu ban cu ma khong thay doi chieu dai PLINE. Vi duong dau net cat theo muc dich the hien chi gioi xay dung, khi Setback >0, chieu dai PLINE = ROW + setback trai + setback phai; khi setback=0 thi bang ROW.
- `QHMCVE`: ngoai 2 vach chi gioi duong do con ve vach **CHỈ GIỚI XÂY DỰNG** ben ngoai theo 2 setback, va DIM thuc cho khoang lui moi ben; khi setback=0 thi khong ve net trung. Van giu font Arial, chieu cao 0.4m, day ket cau -0.60/-0.20m, khong hoa gio.

**Nghiem thu:** `V2.0_ACCEPTANCE_VI.md`. Sao luu DWG, dung AutoCAD dang chay va NETLOAD lai DLL build moi de tranh su dung DLL cu.

---

**V1.9: source patch tu V1.8. Chua bien dich AutoCAD 2020 hoac NETLOAD nghiem thu tren may Windows.**

- `QHTENLO`: click lien tuc `sdd` (o dat, ke ca o dung `sdd2` cho cay xanh/mat nuoc) hoac `sdd2` (lo dat), nhap tien to + so bat dau. Doi ma o me dong bo cac lien ket `ParentCode` cua lo, lo rong va dat noi bo; label giu vi tri/ty le.
- `QHMCGAN`: chuan hoa GOC XOAY TOAN BLOCK truoc khi chen, giu text SO cung chieu hai mui ten; `QHMCSCALE` sua duoc cac BLOCK nhom V1.8 cu. Nho kiem tra voi moi huong tim, boi layout va UCS cua ban ve co the khac nhau.
- `QHSTYLE` tao `QH_ARIAL` (font `arial.ttf`) va `QH_DIM_040` (text DIM 0.4 m, scale 1), khong thay `STANDARD` cua DWG. `QHMCVE` su dung style nay, nhan **CHỈ GIỚI ĐƯỜNG ĐỎ** day du/chu dung, DIM text 0.4m; xoa hoa gio khi ve lai mat cat.
- `QHROADS`/`QHEDIT` co 2 thong so moi: **chi gioi xay dung lui trai/phai** (0m mac dinh, doi ra phia lo dat tu CGDD). `QHBUILD` tao layer `QH_CHI_GIOI_XAY_DUNG`, chi ve cac phan khac voi CGDD, khong tinh vao dien tich dat giao thong. Mat cat co phan lo gioi giong nhau nhung khac setback duoc xep rieng.
- `QHCHITIEU`: chon o `QH_O_DAT`, nhap 3 chi tieu MDXD (%), so san/tang cao toi da, he so SDD; XData va Attribute block sdd cap nhat ngay. `-` de xoa gia tri, `.` de giu gia tri cu. Nhap mat do `70` de hieu `70%`.
- `QHSDDEXPORT`: tao .xlsx theo 9 cot `STT, Ky hieu, Chuc nang, Dien tich (m2), Dien tich (ha), Ty le (%), Mat do XD, So san toi da, He so SDD`, them cot J `CAD_HANDLE` AN de dong bo; hai sheet `Bang SDD` va `Tong hop SDD`. Tinh % theo tong dien tich O ME, khong cong trung lo con; road area trong QHAUDIT/QHEXPORT khac.
- `QHSDDIMPORT`: chon file .xlsx xuat boi lenh tren, nhap lai du lieu tu G,H,I (co the bo trong), doi chieu `CAD_HANDLE`, ma nhan va dien tich CAD; thay doi toan bo chi tieu trong mot transaction sau khi nguoi dung xac nhan. **Khong nhap truc tiep file .xls mau**. Neu code/ranh thay doi, xuat Excel moi.

`SuDungDat.xls` tham chieu co 4 sheet: `285HA`, `GON`, `SDD Tong_PA2`, `RutGon_PA2`. Truc tiep co ma CN.01, CX.01, MN.01 va chi tieu; mau cu luu mat do 70 (phan tram) va 0.7 (ty le) trong 2 sheet khac nhau, nen V1.9 su dung duy nhat **don vi % theo so 0-100**. Mot so o trong file mau co so 23 cho tai lieu chua hoan thien; plugin khong tu sao chep cac so nay.

Huong dan kiem thu: `V1.9_ACCEPTANCE_VI.md`.

---

## Lich su V1.8

**V1.8 (ma nguon; chua bien dich/NETLOAD tren Windows tai moi truong nay):**

- `QHLABEL` mac dinh **Both**: tu dong tao nhan cho ca `QH_O_DAT` va `QH_LO_DAT` (lo chua dat ten rieng van hien ma tu dong). `QHLABELSCALE` **cap nhat ngay tat ca block nhan dang co**: `sdd`, `sdd2` va cac ten nhan metric V1.6 cu. Cap nhat ca scale cua `AttributeReference`; khong can QHLABEL lai chi de scale.
- `QHTENLO`/`QHLOTNAME`: nhap **tien to** `CN.1.` va **so bat dau** `1`, sau do click **block nhan lo sdd2 lien tuc**, plugin dat `CN.1.1`, `CN.1.2`, `CN.1.3`... Enter dung. Trung ma se bo qua so da dung, khong de len ma lo khac. Nhap doi ma trong XData lo, ATTRIB hien thi va lien ket label; giu nguyen vi tri, scale va dien tich cua label.
- `QHMCGAN`: moi net cat moi la **MOT BlockReference** chua definition `QH_NETCAT_NHOM_V18_...`, trong do co **hai BlockReference netcat trai/phai goc mau DXF** va **mot LWPOLYLINE dung linetype `QH_NETCAT_DUT_V18`**, dai bang **dung lo gioi**. So `1-1`, `2-2`... duoc giu trong hai ATTDEF cua block cha; xoay text de doc xuoi, khong bi nguoc 180°.
- **Lenh moi `QHMCSCALE`**: nhap ty le dau net cat/text, cap nhat cac nhom net cat V1.8 da chen va cac lan chen tiep theo. Chi doi ScaleFactors cua hai block con + kich thuoc/vi tri chu; **KHONG scale PLINE dut / block cha**, nen chieu dai duong dut luon bang lo gioi.
- `QHMCVE`: thay duong vach + chu be rong tu do bang **5 doi tuong DIM that** cho cac phan he/mat/dai phan cach (bo qua thanh phan rong 0), giu DIM tong lo gioi. DIM text cao 0.45m (tong 0.55m), mui 0.26m/0.32m va DIMscale=1 tren tung doi tuong de khong bi anh huong boi DIMSTYLE co chu qua lon. Hai duong CGDD ghi day du `CHI GIOI DUONG DO` va xoay chu dung; ve hoa gio minh hoa 4 huong tren tim duong. Hoa gio minh hoa mac dinh B len tren, **khong thay the goc Bac ban do da kiem chung**.
- **Nang cap:** net cat V1.7 cu la cac entity rieng le, V1.8 chi nhom tu dong cac net cat **chen moi**; neu can thay net cat cu, xoa dung doi tuong cut cu sau khi sao luu DWG, roi chay `QHMCGAN` lai. Khong xoa tu dong ky hieu cu hay du lieu cua nguoi dung.

Kiem tra chi tiet bang `V1.8_ACCEPTANCE_VI.md`. Sao luu DWG, thoat AutoCAD truoc khi NETLOAD ban DLL moi.

---

## Lich su V1.7

**V1.7 (ma nguon, chua duoc build/NETLOAD tren AutoCAD trong moi truong nay):**

- `QHLA` -> `Lo`: khong can chon o me hay bam `Next`. Bam **lien tuc** vao cac vung PLINE khep kin; plugin tu nhan dien o me `QH_O_DAT` bao tron tung vung. `Enter` de ket thuc. Trong luc pick co the go `Pline` (chon mot duong) hoac `Nhieu` (chon nhieu PLINE). Khi sua ranh chon `SuaLo`/`SuaO`; do an toan du lieu, van can chi dinh doi tuong cu can sua.
- `QHTENLO` (alias `QHLOTNAME`): bam mot diem ben trong lo, nhap ma ten moi nhu `CN.1-L01`, cap nhat thuoc tinh QH_LO_DAT, label 2 truong va Excel. Ma khong duoc trung.
- Sau `QHLAND`, `QHLOT` va `QHLA`, dua `QH_O_DAT` len **draw order tren cung**, `QH_LO_DAT` va `QH_DAT_CHUA_CHIA` xuong duoi. `QH_DAT_CHUA_CHIA` duoc an khi pick QHLA (co the bat lai qua `QHDU`).
- `assets/block.dxf` da thay bang DXF moi nguoi dung gui, `INSUNITS=6` (met), nhung block `sdd`, `sdd2`, `VT` truc tiep. `QHLABEL` mac dinh chen `sdd/sdd2` **scale=1**. Chu y: duong kinh hinh tron `sdd` trong chinh DXF la **khoang 71.527 met**; su dung `QHLABELSCALE` neu muon ky hieu nho hon. Tren DWG co block `sdd` cu trung ten, AutoCAD se giu definition da co; thu tren DWG moi de kiem tra mau chinh xac.
- `QHMCGAN` chen **2 block dau net cat dung net goc tu mau `*U24`** co ATTDEF `SO` (so 1, 2, 3...) va net dut o giua, do dai theo tong be rong lo gioi giua hai chi gioi do. Mau DXF chua block cat **an danh `*U24`**, khong co named block `netcat`. `tools/prepare_netcat_from_user_dxf.py` cat nguyen 6 polyline va 2 ATTDEF thanh 2 block `QH_NETCAT_TRAI_V17`, `QH_NETCAT_PHAI_V17`, khong ve lai dau mau bang 2 net don gian. Trung tam net dut duoc plugin ve tu dong theo lo gioi.
- `QHMCVE` bo sung day cau tao ao duong o `-0.60m` so voi mat duong, day he `-0.20m` so voi mat he, vach chi gioi duong do hai ben va doi tuong `AlignedDimension` cho be rong lo gioi. Van la **mat cat y tuong**, khong thay ho so cau tao giao thong chinh thuc.

**Huong dan kiem thu V1.7:** xem `V1.7_ACCEPTANCE_VI.md`. Truoc khi NETLOAD, thoat AutoCAD cu va build lai DLL tren Windows. Sao luu DWG truoc khi thao tac.

---

## Lich su V1.6 (tham khao)

**V1.6 (mã nguồn, cần nghiệm thu thực tế AutoCAD):**

- L hai nhánh: nối cả bó vỉa và chỉ giới lưng bằng tứ giác đến giao điểm miter. Bản cũ dùng tam giác chạm mép đường tại hai đỉnh, khiến phần còn lại bị nhận diện thành ô đất OD-002. Nút T/X giữ nguyên; tim L thuộc một PLINE dùng cung AutoCAD native R8 + bề rộng phía bụng.
- QHROADS tự cấp tên N1, N2... cho tuyến mới và đặt chữ trên tim; QHNAME sửa tên, QHBUILD/QHSHIFT làm mới chữ theo vị trí tim.
- QHLA cho làm nhiều ô/lô bằng OneByOne + Next/Done hoặc SelectMany chọn cả tập PLINE khép kín. Vùng khớp ô hiện tại được dùng lại, vùng thực sự chồng lấn vẫn bị chặn. Đất chưa chia được ẩn khi chọn; QHDU Show/Hide mở lại để đối chiếu.
- Sửa thứ tự SetRejectMessage / AddAllowedClass ở QHLA SelectPline, QHMCGAN và QHNAME.
- QHLABEL Lots dùng ký hiệu 2 trường (tên lô, diện tích); Blocks xây dựng dùng 5 trường. DXF metric có INSUNITS=6, block đường kính 8m tại tỷ lệ chèn 1:1. Tên metric riêng tránh làm hỏng block sdd/sdd2 cũ; DXF gốc được giữ.
- QHMCVE bổ sung nét đứng tại các chỗ thay đổi cao độ bó vỉa và dải phân cách (0,18m và 0,15m). Đây vẫn là bản vẽ ý tưởng, chưa đủ cấu tạo thi công.

**Nâng cấp DWG:** hãy sao lưu DWG và xuất Excel trước khi chạy lại. QHBUILD không tự xóa ô đất OD-002 cũ; sau khi xác nhận nét giao thông đúng, chạy QHLAND → Replace để tính lại ô đất. Thao tác Replace xóa các ô/lô/nhãn cũ và phải gán lại chức năng. Thoát hẳn AutoCAD trước khi NETLOAD DLL mới.

**Bản vá V1.5 (cần nghiệm thu AutoCAD 2020):**

- Nút **2 nhánh chữ L**, kể cả **hai tim PLINE riêng gặp đầu**: lưng bó vỉa và lưng chỉ giới đều nối bằng cùng quy tắc miter vuông; bụng tiếp tục bo R8/vát C6. Nút T/X có 3/4 nhánh **không áp dụng bước nối lưng chữ L**. Tim L gấp trong một PLINE vẫn tự bo cung native; tim của hai tuyến riêng giữ nguyên danh tính từng tuyến.
- `QHLA` tạo ô đất, lô mới hoặc thay ranh ô/lô cũ: chọn **PickInside** để bấm trong vùng kín như BOUNDARY hoặc **SelectPline** để chọn PLINE khép kín. Khi sửa lô, kiểm tra chồng lấn và xử lý phần đất chưa chia trong phạm vi có thể biểu diễn bằng polygon không lỗ; bất thường thì rollback.
- `QHZONE` chấp nhận mã `CN.1` đến `CN.10` và mã `CX.1`, `MN.2` (dấu chấm ở giữa). Nhãn ô đất hiển thị **mã chức năng** đã gán.
- `QHLABEL` dùng **block sdd và sdd2 nguyên bản** trong `assets/block.dxf` (đã nhúng vào DLL); `QHLABELSCALE` chỉnh đường kính ký hiệu mặc định 8 m. Sơ đồ ánh xạ `sdd`: A=mã, B=mật độ, C=tầng, D=FAR, E=diện tích; `sdd2`: 1=mã, 2=diện tích. Sửa lỗi căn chữ có khả năng gây `eNotApplicable` ở block tự tạo cũ. Có thể dùng `EATTEDIT` chỉnh giá trị, sau đó `QHEXPORT` đọc lại.
- `QHROADS` hỏi **tên riêng từng tim**, lưu Unicode trong XData; `QHNAME` đổi tên sau đăng ký. `QHMCBANG` nhóm tuyến theo 5 thành phần bề rộng trái/phải/dải giữa. `QHMCGAN` chèn nét cắt sử dụng **block VT** từ DXF mẫu. `QHMCVE` vẽ sơ đồ các mặt cắt duy nhất theo kích thước đã khai báo ở tỷ lệ đơn vị mét; đây là **bản vẽ mặt cắt ý tưởng**, chưa phải trắc ngang kỹ thuật thi công.
- `QHEXPORT` có thêm sheet `Tuyen va mat cat` chứa mã mặt cắt, tên từng đường và 5 kích thước bề rộng.

**Giới hạn:** V1.5 chưa được NETLOAD và chạy AutoCAD trực tiếp trong môi trường tạo gói. Cần thử nhập block DXF và `QHLABEL`, phần bo/vát nút L, QHLA PickInside trên DWG thực tế. Không tự động thay đổi ô đất/lô thuộc người dùng khi không có xác nhận hoặc phát hiện hình học chồng lấn.

**Bản vá V1.4.1 — phân biệt hình học L với nút T/X:** `QHBUILD` tự phát hiện **một tuyến LWPOLYLINE hở tự gấp gần 90°** và tạo **cung ARC native trên chính tim PLINE** (không tạo tim mới). Với R bó vỉa phía bụng = 8 m, tim cách bó vỉa phía bụng = 3,5 m thì bán kính tim = 11,5 m. Biên bó vỉa và chỉ giới đỏ vẫn dựng từ **góc vuông thiết kế gốc**, để bụng bo R8/vát C6 và lưng nối miter vuông góc, không tạo khoảng hở; xử lý cả trường hợp toàn bộ đường chữ L nằm trong ranh (biên đường là lỗ trong polygon đất). Nút T/X **không tự bo tim**. `QHCLCURVE` là bí danh tương thích chạy `QHBUILD`; không cần dùng lệnh riêng. Metadata của tim cong được lưu trong XData, hỗ trợ chạy lại `QHBUILD`, `QHEDIT` và `QHSHIFT`. Trường hợp có cung ARC do người dùng vẽ sẵn, plugin giữ cung gốc và không tự sửa hình học L đó; cần tự kiểm tra.

**Các tính năng V1.4 tiếp tục được giữ:**

- `QHBUILD` dựng đường từ các dải chữ nhật **đầu phẳng + miter phía lưng** trên từng đoạn tim, tránh hở nét tại góc lưng của L; xử lý **bụng góc** R8/C6. Tim chữ L được bo tự động, tim nút T/X giữ nguyên.
- `QHCLCURVE`: bí danh tương thích, chỉ gọi lại `QHBUILD`; không cần một lượt bo tim độc lập.
- `QHSHIFT`: chọn tim, trái/phải theo chiều vẽ, nhập mét; dịch **nguyên tuyến theo một vector** rồi dựng lại tất cả các lớp đường trong cùng transaction. Không phải lệnh OFFSET song song từng nhánh của tuyến cong.
- `QHLOT`: nhập mặt tiền + chiều sâu, tự chia lô giữa, dồn phần dư sang lô góc; tùy chọn hai dãy áp lưng, tùy chọn đường nội bộ có bề rộng nhập tay. Vùng chưa chia được lưu riêng, không mất diện tích.
- `QHLABEL`: vẽ block attribute dạng **5 chỉ tiêu** (`LOT_CODE`, `DENSITY`, `FLOORS`, `AREA_M2`, `FAR`) hoặc **2 chỉ tiêu** cho đất cây xanh/mặt nước; chỉnh bằng `EATTEDIT`.
- Mẫu gốc người dùng gửi được đóng kèm tại `references/land-attribute-reference.png` để đối chiếu tỷ lệ đường tròn, đường ngăn và cỡ chữ khi nghiệm thu trên CAD.
- `QHEXPORT`: đọc các thuộc tính block để tổng hợp Excel; `QHAUDIT` cảnh báo khi diện tích attribute lệch diện tích hình học.

**Giới hạn cần hiểu trước:** tim L bo cong và bó vỉa bụng là cung đồng tâm nhưng **phía lưng vẫn là góc vuông**, do đó bó vỉa phía lưng không phải offset đồng tâm của toàn bộ tim cong. Đây là chủ đích theo bản vẽ người dùng yêu cầu. Chỉ tự bo khi PLINE có đỉnh rẽ 90° ±10°, các đoạn trước/sau đủ dài và không có nhánh T/X tại đỉnh. Lệnh không thiết kế tự động các làn rẽ tại nút T/X. Phải đo lại R8/C6 và góc lưng trong AutoCAD thực tế.

**Bản sửa build V1.3.1:** sửa lỗi biên dịch `CS0136` trong `LandCommands.cs` do các biến cục bộ `start`/`end` bị khai báo trùng tên trong cùng phương thức `FindFrontage`. Không thay đổi cách tính toán hình học của V1.3.

**Bản vá V1.3 (mã nguồn):** `QHROADS` hỗ trợ chọn `LINE` và `LWPOLYLINE` hở; `LINE` được chuyển thành **một** tim `LWPOLYLINE` có XData. `QHBUILD` sửa **chính tim đã đăng ký**, không tạo một tim thứ hai. Tim nằm tại `QH_TIM_DUONG_SACH` và chọn được bằng `QHEDIT`. Bo R8 và vát C6 nay chỉ nhắm các góc có **hai nhánh đường hướng vào phần bụng nút**; nút chữ T không bo mặt lưng. Khi có dải phân cách, plugin ngắt tại nút giao và tạo mũi tròn với **khoảng lùi 20 m mặc định**, chỉnh riêng tại `QHEDIT`. Bổ sung `QHLAND`, `QHZONE`, `QHLOT`, `QHLABEL`, `QHAUDIT`, `QHEXPORT`.

**Quan trọng:** V1.5 là **mã nguồn cần build và kiểm thử**, chưa phải DLL đã được chứng nhận chạy trên AutoCAD 2020–2024. Chức năng chia lô tự động vẫn yêu cầu ranh ô hợp lệ, không có lỗ và một cạnh mặt tiền thẳng đủ dài. Các vị trí R/C, mũi dải phân cách và lô góc cần kiểm tra trên DWG thực tế.

**Bản vá V1.2:** `QHBUILD` và `QHAREA` giờ hoạt động **ngay cả khi chưa có ranh quy hoạch**. Trong trường hợp đó, vùng đường không bị cắt theo ranh, diện tích chỉ là **diện tích sơ bộ theo toàn bộ các tuyến đã đăng ký**, không phải cơ cấu sử dụng đất cuối cùng. `QHSETUP` chấp nhận chọn LWPOLYLINE đang `Open`, đo khoảng cách hai đầu rồi hỏi có muốn **đóng bản sao** hay không. Không tự thay đổi ranh nguồn. Sau khi chốt ranh, chạy lại `QHSETUP` rồi `QHBUILD` để cắt theo ranh.

**Bản vá cài đặt V1.1:** `build.ps1` sử dụng ASCII để tránh lỗi đọc tiếng Việt trên Windows PowerShell 5.1, và truyền cùng đường dẫn AutoCAD vào cả `dotnet restore` và `dotnet build`. Xem hướng dẫn thực hành `INSTALL_WINDOWS_AUTOCAD_2020-2024.md`.

Mã nguồn thử nghiệm plugin AutoCAD Windows 2020–2024, viết bằng C#/.NET Framework, có giao diện WinForms và lõi hình học NetTopologySuite. Tham khảo hai ảnh người dùng cung cấp và đã đóng kèm trong `references/`: `road-network-reference.png` (mạng tim/bó vỉa/chỉ giới) và `road-section-reference.png` (hộp sửa mặt cắt).

**Trạng thái kiểm chứng:** Đã tạo mã nguồn và bộ self-test hình học, **chưa biên dịch hoặc chạy trực tiếp trong AutoCAD** do môi trường hiện tại không có AutoCAD/SDK và .NET build tools. Không sử dụng ngay trên bản vẽ sản xuất. Cần kiểm thử trên bản sao DWG trước khi ký nghiệm thu.

## Quy tắc mặt cắt

Tim đường là trục giữa. Nếu không có dải phân cách, bó vỉa trái/phải cách tim 3,5 m, chỉ giới đường đỏ cách tim 6,5 m mỗi bên.

Nếu có dải phân cách rộng `M` nằm giữa tim: hai mép dải phân cách ở `±M/2`; bó vỉa ngoài bên trái ở `M/2 + lòng đường trái`, bên phải ở `M/2 + lòng đường phải`. Chỉ giới đường đỏ ở ngoài mỗi bó vỉa thêm chiều rộng vỉa hè cùng phía. Chữ trái/phải được xác định theo chiều từ đỉnh đầu đến đỉnh cuối của tim polyline.

Giá trị mặc định:

| Thuộc tính | Giá trị |
| --- | ---: |
| Lòng đường trái | 3,5 m |
| Lòng đường phải | 3,5 m |
| Vỉa hè trái | 3 m |
| Vỉa hè phải | 3 m |
| Dải phân cách giữa | 0 m |
| Lộ giới mặc định | 13 m |
| Bo góc bó vỉa | R8 m |
| Vát góc chỉ giới đỏ | C6 m |
| Khoảng lùi đầu dải phân cách đến nút | 20 m |
| Ngưỡng nối đầu tim gần vuông góc | 1,5 m |

R8 và C6 là **thông số thiết kế**, cần kiểm tra thực địa/tiêu chuẩn và yêu cầu cơ quan quản lý trước khi sử dụng cho hồ sơ chính thức.

## Yêu cầu máy người dùng

- AutoCAD bản đầy đủ trên Windows 2020–2024 (không phải AutoCAD LT).
- Visual Studio 2019/2022 hoặc MSBuild có .NET Framework targeting pack.
- CAD 2020: build đích `net47` và tham chiếu DLL của CAD 2020.
- CAD 2021–2024: build đích `net48` và tham chiếu DLL của **đúng phiên bản CAD**.
- NuGet `NetTopologySuite` 2.6.0, khôi phục cùng dependencies trong output.
- Đơn vị hình học tính bằng mét; tim đường đầu vào là `LINE` hoặc `LWPOLYLINE` hở trong mặt phẳng XY. Plugin chuẩn hóa thành `LWPOLYLINE` trên layer tim chính. Ranh là `LWPOLYLINE` kín (hoặc `Open` rồi xác nhận đóng **bản sao**).

## Biên dịch trên Windows

Mở `Developer PowerShell for Visual Studio` tại thư mục gói này.

Ví dụ với AutoCAD 2024:

```powershell
.\build.ps1 -AcadVersion 2024
```

Với AutoCAD 2020, chạy `.\build.ps1 -AcadVersion 2020`. Nếu AutoCAD được cài ở vị trí khác, bổ sung `-AcadDir 'D:\AutoCAD2020'`. Phải có reference assemblies .NET Framework 4.7. Cần biên dịch và kiểm tra trên từng phiên bản đích vì Autodesk thay đổi phiên bản API giữa các đời CAD.

Kết quả nằm ở `src\CadRoads\bin\Release\net48\` hoặc `net47\`. Sao chép **toàn bộ các DLL phụ thuộc** cùng `QHPlanningRoads.dll` tới một thư mục thử nghiệm tin cậy, không chỉ riêng DLL chính. Trong AutoCAD gõ `NETLOAD` và chọn `QHPlanningRoads.dll`. AutoCAD có thể yêu cầu cấu hình `TRUSTEDPATHS` cho thư mục chứa plugin.

> Chưa có DLL đã build sẵn trong gói này. Mã nguồn cần biên dịch trên Windows có AutoCAD SDK/runtime phù hợp.

## Thao tác

1. **Tạo bản sao DWG** và xác minh tọa độ XY đang dùng mét. Không thao tác trên file đang được phê duyệt.
2. `QHSETUP` **tùy chọn ở giai đoạn ý tưởng**: chọn ranh quy hoạch. Nếu polyline hiện `Open`, plugin hiển thị khoảng cách giữa đầu-cuối và yêu cầu xác nhận `CloseCopy`; chỉ bản sao trên layer `QH_RANH_QUY_HOACH` được đóng. Nếu chưa muốn chốt ranh, bỏ qua hoàn toàn bước này.
3. `QHROADS`: quét/chọn các tim đường `LINE` hoặc `LWPOLYLINE` hở. Hộp mặt cắt mở ra, preset 13 m hoặc nhập mặt cắt riêng, chọn **nhóm đang chọn / tất cả tuyến cùng mặt cắt / tất cả tuyến đã đăng ký**, nhấn Lưu; **nhập tên riêng cho từng tuyến**. **LINE nguồn được thay bằng LWPOLYLINE**, không giữ hai tim chồng lên nhau. `QHNAME` đổi tên sau này.
4. `QHBUILD`: làm sạch bằng cách chỉnh trực tiếp hai đầu tim chính rồi dựng bó vỉa, chỉ giới đỏ, dải phân cách (nếu có) và vùng đường. **Nếu chưa có ranh**, tự tạo vùng tính toán tạm bao ngoài mạng đường và thông báo diện tích sơ bộ; **không vẽ ranh giả**. Nếu đã có ranh thì cắt đường theo ranh thật. Tim cũ đã có XData được chuyển sang layer tim sạch; các tim giả do bản cũ tạo, không có XData trên layer tim sạch, được dọn.
5. `QHEDIT`: chọn một tim đã đăng ký, sửa mặt cắt, chọn phạm vi ảnh hưởng rồi chạy lại `QHBUILD`.
6. `QHTOL`: sửa dung sai tự nối đầu tim gần vuông góc (m), sau đó dựng lại.
7. `QHAREA`: tính lại diện tích theo chỉ giới đỏ và diện tích lòng đường theo bó vỉa. Kết quả ghi rõ **đã cắt ranh** hoặc **sơ bộ chưa cắt ranh**.
8. `QHLAND`: **cần có ranh thật** từ `QHSETUP`, nhận diện tự động các ô đất còn lại sau khi trừ vùng đường theo chỉ giới đỏ. Nếu đã có ô/lô, bắt buộc xác nhận mới được thay.
9. `QHZONE`: chọn từng ô đất và gán mã chức năng như `ODT`, `CN.1`, `CN.10`, `CX.1` hoặc mã riêng không dấu; chức năng của lô con được cập nhật cùng ô mẹ.
10. `QHLOT`: chọn ô đất + cạnh mặt tiền thẳng, nhập mặt tiền mục tiêu (8 m), **chiều sâu mục tiêu (20 m)**, ngưỡng diện tích cảnh báo (80 m²), chọn **1 hoặc 2 dãy**. Nếu 2 dãy, có thể chọn dải đường nội bộ và nhập chiều rộng mặc định 6 m. Các lô giữa có bước mặt tiền mong muốn; phần bên trái/phải là **lô góc** không bắt buộc cùng mặt tiền. Vùng phía sau/giữa không đủ điều kiện được giữ trên `QH_DAT_CHUA_CHIA`, không tự tạo đường kết nối với mạng ngoài.
11. `QHLABEL`: chọn `Blocks`, `Lots` hoặc `Both`; import block **sdd/sdd2** từ DXF mẫu nhúng, tạo ATTRIB; chỉnh chỉ tiêu bằng `EATTEDIT` của AutoCAD; sau đó `QHEXPORT` lấy thông số từ block. Khi chạy lại, chỉ các nhãn cùng nhóm được thay, giữ giá trị phi diện tích của mã trùng. Dùng `QHLABELSCALE` đặt đường kính nhãn (m).
12. `QHAUDIT`: so diện tích ranh - đất đường - tổng ô, kiểm tra tổng lô/ô, lô vượt ô mẹ, trùng mã, lô và ô chồng lấn. Đây là **hậu kiểm hình học**, không phải kiểm tra toàn bộ quy chuẩn kiến trúc/quy hoạch.
13. `QHEXPORT`: xuất `.xlsx` với ba sheet **Danh sach lo**, **Tong hop chuc nang**, **Tuyen va mat cat**. Tổng cơ cấu chức năng chỉ tính các **ô mẹ**, tránh đếm thêm lô con. Có thể chèn bảng CAD.
14. `QHSHIFT`: dịch nguyên tim sang trái/phải theo chiều vẽ một khoảng chọn và tự dựng lại lớp đường. Với đường cong, đây là **tịnh tiến cứng**, không phải `OFFSET` hình học.
15. `QHBUILD` tự bo tim chữ L (một PLINE). `QHCLCURVE` là lệnh tương thích gọi `QHBUILD`, **không còn hỏi chọn tuyến**. Nút T/X không bo cong tim.
16. `QHLA`: [Block/Lot/EditBlock/EditLot], rồi [PickInside/SelectPline]. Chọn điểm trong vùng kín hoặc biên PLINE, chương trình kiểm tra ô mẹ, chồng lấn và đặt trên layer tương ứng. Khi `EditLot`, chọn lô cũ trước để giữ mã.
17. `QHMCBANG`: thống kê nhóm mặt cắt theo đúng 5 bề rộng; các tuyến chỉ khác R8/C6 nhưng bề rộng giống nhau dùng cùng ký hiệu mặt cắt.
18. `QHMCGAN`: chọn tim và vị trí cắt; vẽ nét cắt, hai ký hiệu `VT`, mã `MC-xx` trên `QH_NET_CAT`.
19. `QHMCVE`: chọn vị trí vẽ, xác nhận thay sơ đồ mặt cắt cũ plugin; vẽ các mặt cắt 1:1 theo bề rộng trên `QH_BAN_VE_MAT_CAT`.
20. `QHHELP`: hiện danh sách lệnh.

## Layer

| Layer | Nội dung |
| --- | --- |
| `QH_RANH_QUY_HOACH` | Bản sao ranh khu vực nghiên cứu |
| `QH_TIM_DUONG_SACH` | **Tim duy nhất**, chỉnh sửa được, có XData mặt cắt; không phải layer kết quả cần xóa |
| `QH_BO_VIA` | Bó vỉa ngoài cùng, bo góc theo R |
| `QH_CHI_GIOI_DUONG_DO` | Chỉ giới đường đỏ, vát góc theo C |
| `QH_DAI_PHAN_CACH` | Ranh dải phân cách nếu `M > 0` |
| `QH_VUNG_DAT_GIAO_THONG` | Đường bao vùng giao thông phục vụ thống kê, mặc định không in |
| `QH_O_DAT` | Ô đất còn lại sau trừ giao thông, có mã và loại đất |
| `QH_O_DAT_HOLE` | Biên các khoảng rỗng trong ô đất |
| `QH_LO_DAT` | Các lô sau chia, có mã/ô mẹ |
| `QH_NHAN_DAT` | Block attribute ký hiệu quy hoạch, có thể chỉnh bằng EATTEDIT |
| `QH_BANG_THONG_KE` | Bảng thống kê chèn lên bản CAD |
| `QH_DUONG_NOI_BO` | Dải đường nội bộ riêng do QHLOT đề xuất, chưa nối mạng đường chính |
| `QH_DAT_CHUA_CHIA` | Phần còn lại giữa/sau các dãy lô, được giữ để người thiết kế xử lý |
| `QH_NET_CAT` | Nét cắt và block ký hiệu `VT` theo tuyến |
| `QH_BAN_VE_MAT_CAT` | Sơ đồ mặt cắt theo bề rộng các tuyến cùng nhóm |

Khi chạy lại `QHBUILD`, plugin sửa tim chính và tạo lại **chỉ** các đối tượng giao thông trên 4 layer kết quả `QH_BO_VIA`, `QH_CHI_GIOI_DUONG_DO`, `QH_DAI_PHAN_CACH`, `QH_VUNG_DAT_GIAO_THONG`. Riêng trên `QH_TIM_DUONG_SACH`, plugin chỉ dọn **polyline không có XData** (tim kết quả thừa từ các bản cũ), và giữ tim có XData. Không vẽ dữ liệu khác trên các layer plugin quản lý. Bản `QHLAND` khi được đồng ý tạo lại sẽ xóa dữ liệu ô/lô/nhãn/bảng cũ trên 5 layer đất bên trên.

## Những giới hạn đã biết của bản V1

1. Chỉ hỗ trợ bản vẽ 2D planar, không xử lý nút giao khác cao độ, cầu vượt hoặc dữ liệu Civil 3D alignment trực tiếp.
2. Tim `LWPOLYLINE` chứa cung bulge được lấy mẫu theo dung sai 0,02 m cho bộ máy hình học. Đây là mô hình 2D xấp xỉ; cần đối chiếu với đường cong gốc khi lập hồ sơ pháp lý.
3. Bo R và vát C được áp dụng ở các góc khối đất quanh nút giao có hình học hợp lệ; các góc quá ngắn hoặc phức tạp sẽ được cảnh báo/giữ nguyên. **Không bảo đảm mọi nút giao nhiều nhánh đều tự xử lý đúng**.
4. Plugin tìm cách gom các đoạn bo thành polyline có cung `bulge` native nếu nhận dạng đủ điểm thuộc cung tròn; không nhận dạng được thì để đường đoạn gần đúng. Cần kiểm tra R bằng lệnh đo trong CAD.
5. Nếu mặt cắt hai tuyến tại cùng một nút có R/C khác nhau, bản V1 chọn giá trị lớn hơn tại nút; không có quy trình ưu tiên tuyến chính hoặc bán kính thiết kế riêng từng góc.
6. Nếu đường cong quá gắt làm đường offset tự giao, engine dừng và giữ kết quả cũ. Chỉnh tim/mặt cắt rồi chạy lại.
7. `QHROADS` làm thay đổi thực thể nguồn: `LINE` chuyển thành PLINE; `QHBUILD` sửa đầu tim, dọn tim thừa của bản cũ và thay các layer kết quả. **Không còn cam kết giữ nguyên hình học tim cũ**; hãy backup DWG. Mỗi lần chạy `QHBUILD`, hình học đường có thể thay đổi và làm ô/lô cũ hết hiệu lực: chạy lại `QHLAND`, `QHLOT`, `QHAUDIT` khi cần.
8. Không có preview transient, preset mặt cắt 30/42 m, phân lô cong/hình học phức tạp, kiểm tra chiều sâu cực tiểu theo mọi lát cắt, tự nhận biết cạnh đường thực tế, chỉ tiêu dân số hay tự động kiểm chuẩn mật độ xây dựng. Có thể sửa trực tiếp polyline ô/lô nhưng phải hậu kiểm.
9. Bộ tham số R/C/20 m và min diện tích/mặt tiền là **đầu vào thiết kế**, không tự coi là tiêu chuẩn pháp lý hoặc chứng nhận đạt quy hoạch.
10. `QHLAND` loại bỏ các mảnh rất nhỏ dưới 1 m²; sai số/diện tích bỏ qua sẽ được phát hiện tại `QHAUDIT`. Vùng ô đất có lỗ được biểu diễn bằng polyline ngoài và các polyline lỗ riêng.

## Kiểm thử và nâng cấp từ V1.2

1. **Đóng AutoCAD hoàn toàn trước khi nạp DLL bản mới**, vì .NET Assembly đã NETLOAD thường không thể hot-reload an toàn trong cùng tiến trình.
2. Lưu bản sao DWG dự án, build lại DLL từ V1.3 và nạp bằng `NETLOAD` theo `INSTALL_WINDOWS_AUTOCAD_2020-2024.md`.
3. Trên bản sao DWG đã có QHROADS V1.2, chạy `QHBUILD` một lần: tim nguồn có XData được chuyển sang layer `QH_TIM_DUONG_SACH`, tim sạch kết quả cũ không có XData được dọn. Thử `QHEDIT` chọn **chính tim** trên layer này.
4. Trước khi chia lô bắt buộc đã chạy `QHSETUP` với ranh thật. Sau khi sửa tim và dựng lại đường, làm mới ô/lô theo xác nhận rồi chạy `QHAUDIT`.

- Self-test C# độc lập AutoCAD: `tests/RoadGeometrySelfTest/`.
- Build và chạy trên máy Windows có môi trường .NET phù hợp:

```powershell
dotnet run --project .\tests\RoadGeometrySelfTest\RoadGeometrySelfTest.csproj
```

- Sau đó thực hiện checklist `ACCEPTANCE.md` trên bản DWG thử. **Không nghiệm thu chỉ dựa vào self-test**.

### Sinh bản vẽ thử ngay trong AutoCAD

Mở một DWG trống, nhập `SCRIPT`, chọn một trong hai file:

- `tests/CAD-Scripts/test_cross.scr`: ranh 100 × 100 m, hai đường chữ X.
- `tests/CAD-Scripts/test_t_gap.scr`: ranh 100 × 100 m, tim nhánh chữ T còn hở 1 m.
- `tests/CAD-Scripts/test_l_bend.scr`: ranh 100 × 100 m, **một tim PLINE tự gấp góc L 90°**; dùng để kiểm tra `QHBUILD` tự bo tim, bụng R8/C6, lưng góc vuông, chạy lại lệnh lần hai.
- `tests/CAD-Scripts/test_l_at_t_junction.scr`: cùng góc L nhưng có một nhánh thứ ba tiếp vào đúng đỉnh; kiểm tra `QHBUILD` **không tạo cung tim** tại nút T.
- `tests/CAD-Scripts/test_two_routes_l.scr`: hai tuyến PLINE riêng gặp tại một góc L 90°, kiểm tra **cả hai đường bao lưng** bằng góc vuông.

Sau khi chạy script: Có thể **bỏ qua QHSETUP**, chạy `QHROADS` chọn 2 tim đường, `QHBUILD` và `QHAREA` để xem diện tích sơ bộ. Sau đó chạy `QHSETUP` chọn hình vuông rồi `QHBUILD` lại để xem diện tích đã cắt theo ranh. Không chạy script trên bản vẽ dự án thật.
