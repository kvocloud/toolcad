using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using NetTopologySuite.Geometries;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CadPolyline = Autodesk.AutoCAD.DatabaseServices.Polyline;

namespace QHPlanningRoads
{
    internal sealed class RoadSectionGroup
    {
        public string Id;
        public string Key;
        public RoadProfile Profile;
        public List<RoadInput> Roads = new List<RoadInput>();
    }

    internal static class RoadSections
    {
        internal const string MarkLayer = "QH_NET_CAT";
        internal const string DrawingLayer = "QH_BAN_VE_MAT_CAT";
        // The actual supplied cut symbol is an anonymous dynamic block *U24
        // containing two ends (six polylines + two editable ATTDEF values).
        // The packaging script extracts its two original heads into named
        // blocks so that the central dashed line can vary by ROW length.
        internal const string CutLeftName = "QH_NETCAT_TRAI_V17";
        internal const string CutRightName = "QH_NETCAT_PHAI_V17";
        internal const string CutGroupedPrefix = "QH_NETCAT_NHOM_V18_";
        internal const string CutDashType = "QH_NETCAT_DUT_V18";
        internal static double CutSymbolScale = 1.0;

        internal static void EnsureCutDashType(Database db, Transaction tr)
        {
            var table = (LinetypeTable)tr.GetObject(db.LinetypeTableId, OpenMode.ForRead);
            if (table.Has(CutDashType)) return;
            table.UpgradeOpen();
            var record = new LinetypeTableRecord {
                Name = CutDashType, Comments = "QH net cat dashed polyline",
                PatternLength = 0.65, NumDashes = 2
            };
            record.SetDashLengthAt(0, 0.38);
            record.SetDashLengthAt(1, -0.27);
            table.Add(record); tr.AddNewlyCreatedDBObject(record, true);
        }

        private static AttributeDefinition SourceCutNumber(
            Transaction tr, BlockTableRecord child)
        {
            foreach (ObjectId id in child)
            {
                var ad = tr.GetObject(id, OpenMode.ForRead) as AttributeDefinition;
                if (ad != null && ad.Tag == "SO") return ad;
            }
            throw new InvalidOperationException("Block netcat thieu ATTDEF SO.");
        }

        private static Point3d CutLabelPosition(double anchor, AttributeDefinition source,
            double scale)
        {
            return new Point3d(anchor + source.Position.X * scale,
                -source.Position.Y * scale, 0);
        }

        private static void AppendCutNumber(Transaction tr, BlockTableRecord def,
            AttributeDefinition source, double anchor, string tag, double scale)
        {
            var ad = new AttributeDefinition {
                Tag = tag, Prompt = "So mat cat", TextString = "1",
                Position = CutLabelPosition(anchor, source, scale),
                Height = Math.Max(0.1, source.Height * scale),
                Rotation = 0,
                Layer = "0"
            };
            def.AppendEntity(ad); tr.AddNewlyCreatedDBObject(ad, true);
        }

        // One AutoCAD BLOCK containing exactly two original DXF cut-head
        // INSERTs and ONE dashed LWPOLYLINE between them. Its outer ATTDEFs
        // expose numbers that are readable and editable with EATTEDIT.
        internal static void AddCombinedCut(Database db, Transaction tr,
            BlockTableRecord model, Point3d center, double rotation,
            double rowWidth, string number)
        {
            if (rowWidth <= 0.1) throw new ArgumentException("Lo gioi khong hop le.");
            EnsureCutDashType(db, tr);
            var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
            var leftDef = (BlockTableRecord)tr.GetObject(bt[CutLeftName], OpenMode.ForRead);
            var rightDef = (BlockTableRecord)tr.GetObject(bt[CutRightName], OpenMode.ForRead);
            var leftNumber = SourceCutNumber(tr, leftDef);
            var rightNumber = SourceCutNumber(tr, rightDef);
            bt.UpgradeOpen();
            var def = new BlockTableRecord {
                Name = CutGroupedPrefix + Guid.NewGuid().ToString("N").ToUpperInvariant(),
                Origin = Point3d.Origin
            };
            bt.Add(def); tr.AddNewlyCreatedDBObject(def, true);
            double leftX = -rowWidth / 2, rightX = rowWidth / 2;
            // Source heads *U24 point toward -Y; user's reference points +Y.
            // Mirror JUST the source head geometry and mirror the external
            // number anchor separately. Keep the actual digits unmirrored.
            var leftRef = new BlockReference(new Point3d(leftX,0,0), leftDef.ObjectId) {
                Layer = "0", ScaleFactors = new Scale3d(CutSymbolScale, -CutSymbolScale, CutSymbolScale)
            };
            def.AppendEntity(leftRef); tr.AddNewlyCreatedDBObject(leftRef, true);
            var connector = new CadPolyline(2) {
                Layer = "0", Linetype = CutDashType, LinetypeScale = 1.0
            };
            connector.AddVertexAt(0, new Point2d(leftX,0),0,0,0);
            connector.AddVertexAt(1, new Point2d(rightX,0),0,0,0);
            def.AppendEntity(connector); tr.AddNewlyCreatedDBObject(connector, true);
            var rightRef = new BlockReference(new Point3d(rightX,0,0), rightDef.ObjectId) {
                Layer = "0", ScaleFactors = new Scale3d(CutSymbolScale, -CutSymbolScale, CutSymbolScale)
            };
            def.AppendEntity(rightRef); tr.AddNewlyCreatedDBObject(rightRef, true);
            AppendCutNumber(tr, def, leftNumber, leftX, "SO_TRAI", CutSymbolScale);
            AppendCutNumber(tr, def, rightNumber, rightX, "SO_PHAI", CutSymbolScale);

            // The two original DXF arrows and their numbers must rotate as
            // ONE unit. Previously only numbers were flipped 180 degrees,
            // making them opposite the arrow direction in the user's DWG.
            var grouped = new BlockReference(center, def.ObjectId) {
                Layer = MarkLayer, Rotation = UprightAngle(rotation)
            };
            model.UpgradeOpen(); model.AppendEntity(grouped);
            tr.AddNewlyCreatedDBObject(grouped, true);
            foreach (ObjectId id in def)
            {
                var ad = tr.GetObject(id, OpenMode.ForRead) as AttributeDefinition;
                if (ad == null || ad.Constant) continue;
                var ar = new AttributeReference();
                ar.SetAttributeFromBlock(ad, grouped.BlockTransform);
                ar.TextString = number;
                // SetAttributeFromBlock already includes the grouped rotation;
                // a second independent 180-degree flip causes reversed text.
                grouped.AttributeCollection.AppendAttribute(ar);
                tr.AddNewlyCreatedDBObject(ar, true);
            }
        }

        private static double UprightAngle(double angle)
        {
            while (angle > Math.PI) angle -= 2 * Math.PI;
            while (angle < -Math.PI) angle += 2 * Math.PI;
            if (angle > Math.PI/2) angle -= Math.PI;
            if (angle < -Math.PI/2) angle += Math.PI;
            return angle;
        }

        // QHMCSCALE changes only the two nested head references, never the
        // dashed polyline or the outer grouped BLOCK scale. Thus the exact
        // source-to-source connector length ALWAYS equals the road ROW.
        internal static int RescaleCombinedCuts(Database db, Transaction tr, double scale)
        {
            var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
            int updated = 0;
            foreach (ObjectId id in bt)
            {
                var def = (BlockTableRecord)tr.GetObject(id, OpenMode.ForRead);
                if (!def.Name.StartsWith(CutGroupedPrefix, StringComparison.OrdinalIgnoreCase))
                    continue;
                double half = 0;
                foreach (ObjectId entId in def)
                {
                    var p = tr.GetObject(entId, OpenMode.ForRead) as CadPolyline;
                    if (p != null && p.NumberOfVertices == 2)
                    {
                        half = Math.Abs(p.GetPoint2dAt(0).X);
                        break;
                    }
                }
                if (half <= 0.01) continue;
                def.UpgradeOpen();
                foreach (ObjectId entId in def)
                {
                    var obj = tr.GetObject(entId, OpenMode.ForRead);
                    var child = obj as BlockReference;
                    if (child != null)
                    {
                        child.UpgradeOpen();
                        child.ScaleFactors = new Scale3d(scale, -scale, scale);
                    }
                    var ad = obj as AttributeDefinition;
                    if (ad != null && (ad.Tag == "SO_TRAI" || ad.Tag == "SO_PHAI"))
                    {
                        var sourceName = ad.Tag == "SO_TRAI" ? CutLeftName : CutRightName;
                        var source = (BlockTableRecord)tr.GetObject(bt[sourceName], OpenMode.ForRead);
                        var original = SourceCutNumber(tr, source);
                        double anchor = ad.Tag == "SO_TRAI" ? -half : half;
                        ad.UpgradeOpen();
                        ad.Position = CutLabelPosition(anchor, original, scale);
                        ad.Height = Math.Max(0.1, original.Height * scale);
                    }
                }
                updated++;
            }
            // Refresh the actual visible attribute references after changing
            // their definitions; do not overwrite the user's number text.
            foreach (ObjectId id in CadBridge.GetModelSpace(db, tr))
            {
                if (id.IsErased) continue;
                var grouped = tr.GetObject(id, OpenMode.ForRead) as BlockReference;
                if (grouped == null) continue;
                var def = (BlockTableRecord)tr.GetObject(grouped.BlockTableRecord, OpenMode.ForRead);
                if (!def.Name.StartsWith(CutGroupedPrefix, StringComparison.OrdinalIgnoreCase))
                    continue;
                grouped.UpgradeOpen();
                grouped.Rotation = UprightAngle(grouped.Rotation);
                var ads = new Dictionary<string, AttributeDefinition>(StringComparer.OrdinalIgnoreCase);
                foreach (ObjectId defId in def)
                {
                    var a = tr.GetObject(defId, OpenMode.ForRead) as AttributeDefinition;
                    if (a != null) ads[a.Tag] = a;
                }
                foreach (ObjectId attId in grouped.AttributeCollection)
                {
                    var ar = tr.GetObject(attId, OpenMode.ForRead) as AttributeReference;
                    AttributeDefinition source;
                    if (ar == null || !ads.TryGetValue(ar.Tag, out source)) continue;
                    string number = ar.TextString;
                    ar.UpgradeOpen();
                    ar.SetAttributeFromBlock(source, grouped.BlockTransform);
                    ar.TextString = number;
                    // Readable number and upward arrow share one transform.
                }
            }
            return updated;
        }

        internal static void AddCutEnd(Database db, Transaction tr,
            BlockTableRecord ms, Point3d at, double rotation,
            string number, bool right)
        {
            var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
            var definition = (BlockTableRecord)tr.GetObject(
                bt[right ? CutRightName : CutLeftName], OpenMode.ForRead);
            var mark = new BlockReference(at, definition.ObjectId) {
                Layer = MarkLayer, Rotation = rotation
            };
            ms.UpgradeOpen();
            ms.AppendEntity(mark); tr.AddNewlyCreatedDBObject(mark, true);
            foreach (ObjectId id in definition)
            {
                var ad = tr.GetObject(id, OpenMode.ForRead) as AttributeDefinition;
                if (ad == null || ad.Constant) continue;
                var ar = new AttributeReference();
                ar.SetAttributeFromBlock(ad, mark.BlockTransform);
                ar.TextString = number;
                mark.AttributeCollection.AppendAttribute(ar);
                tr.AddNewlyCreatedDBObject(ar, true);
            }
        }

        internal static void DrawCutDashes(Transaction tr, BlockTableRecord ms,
            Point3d first, Point3d last)
        {
            Vector3d vector = last - first;
            double length = vector.Length;
            if (length < 0.01) return;
            var axis = vector.GetNormal();
            // Physical dashes guarantee exact ROW span even when a client's
            // acad.lin doesn't contain HIDDEN/DASHED.
            for (double t = 0; t < length - 0.0001; t += 0.65)
            {
                double to = Math.Min(length, t + 0.38);
                Add(tr, ms, new Line(first + axis * t, first + axis * to), MarkLayer);
            }
        }

        // Width geometry is the grouping key. Intersection radius/chamfer
        // and node median setbacks do not change the typical cross-section.
        internal static string WidthKey(RoadProfile p)
        {
            return p.WidthSignature();
        }

        internal static List<RoadSectionGroup> Group(IList<RoadInput> roads)
        {
            return roads.GroupBy(r => WidthKey(r.Profile))
                .OrderBy(g => g.Key, StringComparer.Ordinal)
                .Select((g, i) => new RoadSectionGroup {
                    Id = "MC-" + (i + 1).ToString("00"), Key = g.Key,
                    Profile = g.First().Profile.Copy(), Roads = g.ToList()
                }).ToList();
        }

        internal static void EnsureLayers(Database db, Transaction tr)
        {
            var table = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            AddLayer(tr, table, MarkLayer, 1);
            AddLayer(tr, table, DrawingLayer, 7);
        }

        private static void AddLayer(Transaction tr, LayerTable table, string name, short color)
        {
            if (table.Has(name)) return;
            table.UpgradeOpen();
            var layer = new LayerTableRecord { Name = name,
                Color = Color.FromColorIndex(ColorMethod.ByAci, color) };
            table.Add(layer); tr.AddNewlyCreatedDBObject(layer, true);
        }

        internal static void Add(Transaction tr, BlockTableRecord ms, Entity entity, string layer)
        {
            entity.Layer = layer;
            ms.AppendEntity(entity); tr.AddNewlyCreatedDBObject(entity, true);
        }

        internal static void DrawText(Transaction tr, BlockTableRecord ms, Point3d point,
            string value, double height, string layer)
        {
            Add(tr, ms, new DBText { Position = point, Height = height,
                TextStyleId = CadStyles.Text(ms.Database, tr),
                TextString = value ?? "" }, layer);
        }

        internal static void DrawLine(Transaction tr, BlockTableRecord ms, double x1, double y1,
            double x2, double y2, string layer)
        {
            Add(tr, ms, new Line(new Point3d(x1,y1,0), new Point3d(x2,y2,0)), layer);
        }

        internal static void DrawVerticalText(Transaction tr, BlockTableRecord ms,
            double x, double y, string value, double height, string layer)
        {
            Add(tr, ms, new DBText {
                Position = new Point3d(x,y,0),
                Height = height, TextString = value,
                TextStyleId = CadStyles.Text(ms.Database, tr),
                Rotation = Math.PI/2
            }, layer);
        }

        // A symbolic compass rose centered precisely over the road centerline;
        // B=N, D=E, N=S, T=W. Orientation is schematic (not georeferenced).
        internal static void DrawCompassRose(Transaction tr, BlockTableRecord ms,
            double cx, double cy)
        {
            const double radius = 0.48;
            Add(tr, ms, new Circle(new Point3d(cx,cy,0), Vector3d.ZAxis,
                radius), DrawingLayer);
            DrawLine(tr, ms, cx - .80, cy, cx + .80, cy, DrawingLayer);
            DrawLine(tr, ms, cx, cy - .80, cx, cy + .80, DrawingLayer);
            DrawLine(tr, ms, cx-.47, cy-.47, cx+.47, cy+.47, DrawingLayer);
            DrawLine(tr, ms, cx-.47, cy+.47, cx+.47, cy-.47, DrawingLayer);
            var north = new CadPolyline(3) { Closed = true, Layer = DrawingLayer };
            north.AddVertexAt(0, new Point2d(cx,cy+.85),0,0,0);
            north.AddVertexAt(1, new Point2d(cx-.16,cy+.37),0,0,0);
            north.AddVertexAt(2, new Point2d(cx+.16,cy+.37),0,0,0);
            Add(tr, ms, north, DrawingLayer);
            DrawText(tr, ms, new Point3d(cx-.12,cy+1.07,0), "B", .33, DrawingLayer);
            DrawText(tr, ms, new Point3d(cx+.96,cy-.10,0), "D", .27, DrawingLayer);
            DrawText(tr, ms, new Point3d(cx-.12,cy-1.20,0), "N", .27, DrawingLayer);
            DrawText(tr, ms, new Point3d(cx-1.15,cy-.10,0), "T", .27, DrawingLayer);
        }

        internal static Point3d ClosestOnAxis(IList<Coordinate> pts, Point3d pick,
            out Vector3d tangent)
        {
            double best = double.MaxValue;
            Point3d closest = pick;
            tangent = Vector3d.XAxis;
            for (int i = 0; i < pts.Count - 1; i++)
            {
                var a = pts[i]; var b = pts[i + 1];
                double vx = b.X - a.X, vy = b.Y - a.Y;
                double len2 = vx * vx + vy * vy;
                if (len2 < 1e-8) continue;
                double t = ((pick.X - a.X) * vx + (pick.Y - a.Y) * vy) / len2;
                t = Math.Max(0, Math.Min(1, t));
                double x = a.X + t * vx, y = a.Y + t * vy;
                double distance2 = (pick.X - x) * (pick.X - x) + (pick.Y - y) * (pick.Y - y);
                if (distance2 >= best) continue;
                best = distance2;
                closest = new Point3d(x, y, 0);
                tangent = new Vector3d(vx, vy, 0).GetNormal();
            }
            return closest;
        }

        internal static void DrawCrossSection(Database db, Transaction tr,
            RoadSectionGroup group, Point3d basePoint)
        {
            var ms = CadBridge.GetModelSpace(db, tr);
            ms.UpgradeOpen();
            ObjectId qhDim = CadStyles.Dimension(db, tr);
            var p = group.Profile;
            double x = basePoint.X, y = basePoint.Y;
            int sectionNo;
            if (!int.TryParse(group.Id.Substring(3), out sectionNo)) sectionNo = 1;
            string routeNames = string.Join(", ", group.Roads
                .Select(r => r.Profile.RoadName)
                .Where(n => !string.IsNullOrWhiteSpace(n)).Distinct().ToArray());
            if (routeNames.Length > 120) routeNames = routeNames.Substring(0,120) + "...";
            DrawText(tr, ms, new Point3d(x, y + 5.2, 0),
                "MAT CAT " + sectionNo + "-" + sectionNo
                    + "  |  LO GIOI " + p.RightOfWay.ToString("0.##") + " m",
                1.0, DrawingLayer);
            DrawText(tr, ms, new Point3d(x, y + 3.8, 0),
                string.IsNullOrWhiteSpace(routeNames) ? "TUYEN CHUA DAT TEN" : routeNames,
                0.6, DrawingLayer);

            double[] widths = { p.SidewalkLeft, p.LaneLeft, p.Median,
                p.LaneRight, p.SidewalkRight };
            string[] names = { "VH-T", "LD-T", "PC", "LD-P", "VH-P" };
            // Level diagram inspired by the submitted 14m DXF section:
            // sidewalk +0.18m, carriageway 0, median +0.15m, curb steps.
            double[] levels = { 0.18, 0.0, 0.15, 0.0, 0.18 };
            double pos = x;
            double precedingSurfaceLevel = double.NaN;
            var boundaries = new List<double> { pos };
            for (int i = 0; i < widths.Length; i++)
            {
                double width = widths[i];
                if (width < 0.001) { boundaries.Add(pos); continue; }
                // Draw the VERTICAL face of every curb and median transition.
                // Previous code drew the flat carriageway but stopped the
                // vertical line at the lower side, leaving missing risers.
                if (!double.IsNaN(precedingSurfaceLevel)
                    && Math.Abs(precedingSurfaceLevel - levels[i]) > 0.0001)
                    DrawLine(tr, ms, pos, y + precedingSurfaceLevel,
                        pos, y + levels[i], DrawingLayer);
                DrawLine(tr, ms, pos, y + levels[i], pos + width, y + levels[i], DrawingLayer);
                DrawLine(tr, ms, pos, y - 0.35, pos, y + levels[i], DrawingLayer);
                // Bottom of structures: asphalt 0.60m below road finished
                // level, sidewalk 0.20m below sidewalk finished level.
                bool sidewalk = i == 0 || i == 4;
                bool carriageway = i == 1 || i == 3;
                if (sidewalk || carriageway)
                {
                    double bottom = y + levels[i] - (sidewalk ? 0.20 : 0.60);
                    DrawLine(tr, ms, pos, bottom, pos + width, bottom, DrawingLayer);
                    DrawLine(tr, ms, pos, bottom, pos, y + levels[i], DrawingLayer);
                    DrawLine(tr, ms, pos + width, bottom, pos + width, y + levels[i], DrawingLayer);
                }
                if (width >= 1.8)
                    DrawText(tr, ms, new Point3d(pos + Math.Max(0.1, width / 2 - 0.4),
                        y + 1.1, 0), names[i], 0.38, DrawingLayer);
                pos += width;
                precedingSurfaceLevel = levels[i];
                boundaries.Add(pos);
            }
            DrawLine(tr, ms, pos, y - 0.35, pos, y + 0.18, DrawingLayer);
            DrawLine(tr, ms, x, y - 0.35, pos, y - 0.35, DrawingLayer);
            // All five component widths use real editable AutoCAD DIM entities,
            // rather than manual dimension lines and DBTEXT values.
            for (int i = 0; i < widths.Length; i++)
            {
                if (widths[i] <= 0.01) continue;
                double xx = boundaries[i];
                var segmentDim = new AlignedDimension {
                    XLine1Point = new Point3d(xx, y + levels[i],0),
                    XLine2Point = new Point3d(xx + widths[i],y + levels[i],0),
                    DimLinePoint = new Point3d(xx + widths[i]/2, y - 1.5,0),
                    DimensionStyle = qhDim,
                    DimensionText = widths[i].ToString("0.##") + " m",
                    Dimtxt = CadStyles.AnnotationHeight,
                    Dimasz = 0.26,
                    Dimscale = 1.0,
                    Dimtad = 1
                };
                Add(tr, ms, segmentDim, DrawingLayer);
            }
            // Two red-line boundaries extend through the whole section.
            DrawLine(tr, ms, x, y + 2.3, x, y - 2.35, DrawingLayer);
            DrawLine(tr, ms, pos, y + 2.3, pos, y - 2.35, DrawingLayer);
            DrawVerticalText(tr, ms, x - 0.8, y - 2.1,
                "CHỈ GIỚI ĐƯỜNG ĐỎ", CadStyles.AnnotationHeight, DrawingLayer);
            DrawVerticalText(tr, ms, pos + 0.4, y - 2.1,
                "CHỈ GIỚI ĐƯỜNG ĐỎ", CadStyles.AnnotationHeight, DrawingLayer);
            // Building boundaries are measured OUTWARD from the red lines,
            // towards the adjoining parcels. They are not extra pavement.
            if (p.BuildingSetbackLeft > 0.0001)
            {
                double buildLeft = x - p.BuildingSetbackLeft;
                DrawLine(tr, ms, buildLeft, y + 2.3, buildLeft, y - 2.35, DrawingLayer);
                DrawVerticalText(tr, ms, buildLeft - 0.5, y - 2.1,
                    "CHỈ GIỚI XÂY DỰNG", CadStyles.AnnotationHeight, DrawingLayer);
                var leftDim = new AlignedDimension {
                    XLine1Point = new Point3d(buildLeft, y, 0),
                    XLine2Point = new Point3d(x, y, 0),
                    DimLinePoint = new Point3d((buildLeft + x)/2, y - 2.45, 0),
                    DimensionStyle = qhDim, DimensionText = p.BuildingSetbackLeft.ToString("0.##") + " m",
                    Dimtxt = CadStyles.AnnotationHeight, Dimasz = .26, Dimscale = 1.0, Dimtad = 1
                };
                Add(tr, ms, leftDim, DrawingLayer);
            }
            if (p.BuildingSetbackRight > 0.0001)
            {
                double buildRight = pos + p.BuildingSetbackRight;
                DrawLine(tr, ms, buildRight, y + 2.3, buildRight, y - 2.35, DrawingLayer);
                DrawVerticalText(tr, ms, buildRight + 0.4, y - 2.1,
                    "CHỈ GIỚI XÂY DỰNG", CadStyles.AnnotationHeight, DrawingLayer);
                var rightDim = new AlignedDimension {
                    XLine1Point = new Point3d(pos, y, 0),
                    XLine2Point = new Point3d(buildRight, y, 0),
                    DimLinePoint = new Point3d((pos + buildRight)/2, y - 2.45, 0),
                    DimensionStyle = qhDim, DimensionText = p.BuildingSetbackRight.ToString("0.##") + " m",
                    Dimtxt = CadStyles.AnnotationHeight, Dimasz = .26, Dimscale = 1.0, Dimtad = 1
                };
                Add(tr, ms, rightDim, DrawingLayer);
            }
            // True AutoCAD DIM: editable and associative to the stated
            // 1:1 horizontal geometry, independent of segmented inner widths.
            var overall = new AlignedDimension {
                XLine1Point = new Point3d(x, y, 0),
                XLine2Point = new Point3d(pos, y, 0),
                DimLinePoint = new Point3d((x + pos)/2, y - 3.2, 0),
                DimensionStyle = qhDim,
                DimensionText = p.RightOfWay.ToString("0.##") + " m",
                Dimtxt = CadStyles.AnnotationHeight,
                Dimasz = 0.32,
                Dimscale = 1.0,
                Dimtad = 1
            };
            Add(tr, ms, overall, DrawingLayer);
            DrawText(tr, ms, new Point3d(x, y - 4.6, 0),
                "KET CAU: LONG DUONG -0.60m; HE -0.20m | MAT CAT Y TUONG",
                CadStyles.AnnotationHeight, DrawingLayer);
        }
    }

    public sealed partial class Commands
    {
        [CommandMethod("QHMCBANG")]
        public void ShowRoadSectionGroups()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                var grouped = RoadSections.Group(CadBridge.RegisteredRoads(doc.Database,
                    tr, Settings.CurveTolerance));
                foreach (var group in grouped)
                    doc.Editor.WriteMessage("\n" + group.Id + " | "
                        + group.Profile.RightOfWay.ToString("0.##") + "m | "
                        + group.Roads.Count + " tuyến | "
                        + string.Join(", ", group.Roads.Select(r => r.RoadCode).ToArray()));
                doc.Editor.WriteMessage("\nTổng " + grouped.Count + " mặt cắt theo 5 thành phần bề rộng. ");
            }
        }

        [CommandMethod("QHMCGAN")]
        public void PlaceSectionMarker()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            var opt = new PromptEntityOptions("\nChọn tim đường cần gán nét cắt: ");
            opt.SetRejectMessage("\nChỉ chọn tim đường LWPOLYLINE.");
            opt.AddAllowedClass(typeof(CadPolyline), true);
            var selected = ed.GetEntity(opt);
            if (selected.Status != PromptStatus.OK) return;
            var point = ed.GetPoint("\nChọn vị trí nét cắt gần tim tuyến: ");
            if (point.Status != PromptStatus.OK) return;
            try
            {
                string handle;
                RoadInput selectedRoad;
                RoadSectionGroup group;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var poly = (CadPolyline)tr.GetObject(selected.ObjectId, OpenMode.ForRead);
                    if (CadBridge.ReadProfile(poly) == null)
                        throw new ArgumentException("Tim chưa đăng ký bằng QHROADS.");
                    handle = poly.Handle.ToString();
                    var roads = CadBridge.RegisteredRoads(doc.Database, tr, Settings.CurveTolerance);
                    selectedRoad = roads.FirstOrDefault(r => r.Handle == handle);
                    if (selectedRoad == null) throw new ArgumentException("Không tìm thấy tim trong danh sách.");
                    group = RoadSections.Group(roads).First(g => g.Roads.Any(r => r.Handle == handle));
                }
                LandLabelBlocks.EnsureDefinitions(doc.Database);
                Vector3d tangent;
                Point3d center;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var poly = (CadPolyline)tr.GetObject(selected.ObjectId, OpenMode.ForRead);
                    center = RoadSections.ClosestOnAxis(CadBridge.ToCoordinates(poly,
                        Settings.CurveTolerance), point.Value, out tangent);
                }
                Vector3d normal = new Vector3d(-tangent.Y, tangent.X, 0);
                // If the section declares building setbacks, show the whole
                // distance between BUILDING lines rather than stopping at CGDD.
                Point3d left = center + normal * (selectedRoad.Profile.RedLeft
                    + selectedRoad.Profile.BuildingSetbackLeft);
                Point3d right = center - normal * (selectedRoad.Profile.RedRight
                    + selectedRoad.Profile.BuildingSetbackRight);
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    RoadSections.EnsureLayers(doc.Database, tr);
                    var ms = CadBridge.GetModelSpace(doc.Database, tr);
                    ms.UpgradeOpen();
                    int sectionNo;
                    if (!int.TryParse(group.Id.Substring(3), out sectionNo)) sectionNo = 1;
                    string number = sectionNo.ToString();
                    double cutAngle = Math.Atan2(right.Y - left.Y, right.X - left.X);
                    Point3d cutCenter = new Point3d(
                        (left.X + right.X) / 2, (left.Y + right.Y) / 2, 0);
                    RoadSections.AddCombinedCut(doc.Database, tr, ms, cutCenter,
                        cutAngle, left.DistanceTo(right), number);
                    tr.Commit();
                }
                ed.WriteMessage("\nDa chen 1 block NETCAT gom 2 dau + 1 PLINE dut: "
                    + group.Id + " cho tuyen "
                    + selectedRoad.RoadCode + " / lộ giới "
                    + selectedRoad.Profile.RightOfWay.ToString("0.##") + " m."
                    + " Khoang cach net cat (CGXD neu co): "
                    + (selectedRoad.Profile.RightOfWay + selectedRoad.Profile.BuildingSetbackLeft
                        + selectedRoad.Profile.BuildingSetbackRight).ToString("0.##") + " m.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        [CommandMethod("QHMCSCALE")]
        public void RescaleSectionCutHeads()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            var prompt = new PromptDoubleOptions(
                "\nTi le kich thuoc dau net cat/text <"
                + RoadSections.CutSymbolScale.ToString("0.##") + ">: ") {
                DefaultValue = RoadSections.CutSymbolScale,
                UseDefaultValue = true,
                AllowNegative = false,
                AllowZero = false
            };
            var answer = ed.GetDouble(prompt);
            if (answer.Status != PromptStatus.OK) return;
            if (answer.Value < 0.1 || answer.Value > 20)
            { ed.WriteMessage("\nTi le tu 0.1 den 20."); return; }
            try
            {
                int count;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    count = RoadSections.RescaleCombinedCuts(doc.Database, tr, answer.Value);
                    tr.Commit();
                }
                RoadSections.CutSymbolScale = answer.Value;
                ed.WriteMessage("\nDa cap nhat " + count
                    + " net cat group. PLINE dut giu nguyen chieu dai da chen (CGDD/CGXD).");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        [CommandMethod("QHMCFIX")]
        public void FixExistingSectionCutOrientation()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            try
            {
                int count;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    count = RoadSections.RescaleCombinedCuts(doc.Database, tr,
                        RoadSections.CutSymbolScale);
                    tr.Commit();
                }
                doc.Editor.WriteMessage("\nQHMCFIX: đa chuan hoa huong mui ten/so cho "
                    + count + " block net cat nhom (v18+). Khong doi chieu dai net dut.");
            }
            catch (System.Exception ex) { Report(doc.Editor, ex); }
        }

        [CommandMethod("QHMCVE")]
        public void DrawTypicalSections()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            var point = ed.GetPoint("\nChọn góc trái trên nơi vẽ DANH SÁCH mặt cắt: ");
            if (point.Status != PromptStatus.OK) return;
            try
            {
                List<RoadSectionGroup> groups;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                    groups = RoadSections.Group(CadBridge.RegisteredRoads(doc.Database,
                        tr, Settings.CurveTolerance));
                if (groups.Count == 0) throw new ArgumentException("Chưa có đường QHROADS.");
                if (!Confirm(ed,
                    "\nThay các hình mặt cắt plugin đã vẽ trên QH_BAN_VE_MAT_CAT? [Replace/Cancel] <Cancel>: ",
                    "Replace", "Cancel")) return;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    RoadSections.EnsureLayers(doc.Database, tr);
                    LandStore.ClearManaged(doc.Database, tr, RoadSections.DrawingLayer);
                    for (int i = 0; i < groups.Count; i++)
                        RoadSections.DrawCrossSection(doc.Database, tr, groups[i],
                            new Point3d(point.Value.X, point.Value.Y - i * 17.0, 0));
                    tr.Commit();
                }
                ed.WriteMessage("\nQHMCVE: đã vẽ " + groups.Count
                    + " mặt cắt duy nhất, giữ tỷ lệ bề rộng 1:1 theo mét. "
                    + "Cao độ là SƠ ĐỒ Ý TƯỞNG, chưa dùng thi công.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }
    }
}
