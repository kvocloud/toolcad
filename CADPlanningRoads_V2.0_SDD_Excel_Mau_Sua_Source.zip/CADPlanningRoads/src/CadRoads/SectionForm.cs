using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace QHPlanningRoads
{
    internal enum EditScope { Selected, SameSection, All }

    // Hop sua mat cat theo hinh tham khao: 3 + 7 + 3 = 13 m.
    internal sealed class SectionForm : Form
    {
        private readonly List<TextBox> fields = new List<TextBox>();
        private readonly Label widthLabel = new Label();
        private readonly Panel preview = new Panel();
        private readonly RadioButton selected = new RadioButton();
        private readonly RadioButton same = new RadioButton();
        private readonly RadioButton all = new RadioButton();
        public RoadProfile ResultProfile { get; private set; }
        public EditScope Scope { get; private set; }

        public SectionForm(RoadProfile initial, int selectedCount)
        {
            Text = "QH ROAD - Sửa mặt cắt tuyến đường";
            Width = 540; Height = 700; MinimumSize = new Size(540, 700);
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            Font = new Font("Segoe UI", 9f);
            ResultProfile = initial.Copy();

            var info = new Label { Text = "Lòng đường + dải phân cách + vỉa hè. Đơn vị: mét (m).",
                Left = 20, Top = 15, Width = 490, Height = 22 };
            Controls.Add(info);

            var preset = new Button { Text = "Mặt cắt 13 m (3 + 7 + 3)", Left = 20, Top = 45, Width = 232, Height = 30 };
            preset.Click += (s, e) => FillFields(new RoadProfile());
            Controls.Add(preset);

            preview.SetBounds(20, 89, 480, 96);
            preview.BackColor = Color.FromArgb(242, 243, 246);
            preview.BorderStyle = BorderStyle.FixedSingle;
            preview.Paint += DrawSection;
            Controls.Add(preview);

            string[] labels = {
                "Lòng đường bên trái", "Lòng đường bên phải",
                "Vỉa hè bên trái", "Vỉa hè bên phải", "Dải phân cách giữa",
                "Bán kính bo bó vỉa R", "Chiều dài vát chỉ giới C",
                "Lùi mũi dải giữa tại nút giao",
                "Chỉ giới xây dựng lùi trái", "Chỉ giới xây dựng lùi phải"
            };
            double[] values = { initial.LaneLeft, initial.LaneRight, initial.SidewalkLeft,
                initial.SidewalkRight, initial.Median, initial.CurbRadius, initial.RedChamfer,
                initial.MedianSetback, initial.BuildingSetbackLeft,
                initial.BuildingSetbackRight };
            for (int i = 0; i < labels.Length; i++)
            {
                int col = i % 2, row = i / 2;
                int left = 20 + col * 250, top = 200 + row * 65;
                Controls.Add(new Label { Text = labels[i] + " (m)", Left = left, Top = top,
                    Width = 235, Height = 19 });
                var box = new TextBox { Left = left, Top = top + 21, Width = 220,
                    Text = values[i].ToString("0.###", CultureInfo.InvariantCulture) };
                box.TextChanged += (s, e) => UpdateWidth();
                fields.Add(box); Controls.Add(box);
            }
            widthLabel.Left = 20; widthLabel.Top = 526; widthLabel.Width = 480;
            widthLabel.Height = 25; widthLabel.Font = new Font(Font, FontStyle.Bold);
            Controls.Add(widthLabel);

            selected.Text = "Chỉ " + selectedCount + " tuyến đang chọn";
            same.Text = "Tất cả tuyến có cùng mặt cắt hiện tại";
            all.Text = "Tất cả tuyến đã đăng ký";
            selected.SetBounds(20, 555, 150, 22);
            same.SetBounds(175, 555, 260, 22);
            all.SetBounds(20, 583, 270, 22);
            selected.Checked = true;
            Controls.Add(selected); Controls.Add(same); Controls.Add(all);

            var save = new Button { Text = "Lưu thông số", Left = 280, Top = 613,
                Width = 115, Height = 32, DialogResult = DialogResult.None };
            save.Click += Save;
            var cancel = new Button { Text = "Hủy", Left = 405, Top = 613,
                Width = 95, Height = 32, DialogResult = DialogResult.Cancel };
            Controls.Add(save); Controls.Add(cancel);
            CancelButton = cancel;
            UpdateWidth();
        }

        private void FillFields(RoadProfile p)
        {
            double[] values = { p.LaneLeft, p.LaneRight, p.SidewalkLeft, p.SidewalkRight,
                p.Median, p.CurbRadius, p.RedChamfer, p.MedianSetback,
                p.BuildingSetbackLeft, p.BuildingSetbackRight };
            for (int i = 0; i < values.Length; i++)
                fields[i].Text = values[i].ToString("0.###", CultureInfo.InvariantCulture);
            UpdateWidth();
        }

        private double Read(int index)
        {
            double value;
            string s = fields[index].Text.Trim().Replace(',', '.');
            if (!double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                throw new ArgumentException("Thông số không phải số tại trường: " + (index + 1));
            return value;
        }

        private RoadProfile ReadProfile()
        {
            var p = new RoadProfile
            {
                LaneLeft = Read(0), LaneRight = Read(1), SidewalkLeft = Read(2),
                SidewalkRight = Read(3), Median = Read(4), CurbRadius = Read(5),
                RedChamfer = Read(6), MedianSetback = Read(7),
                BuildingSetbackLeft = Read(8), BuildingSetbackRight = Read(9)
            };
            p.Validate();
            return p;
        }

        private void UpdateWidth()
        {
            try
            {
                var p = ReadProfile();
                widthLabel.ForeColor = Color.DarkGreen;
                widthLabel.Text = "Lộ giới: " + p.RightOfWay.ToString("0.###")
                    + " m  |  Lòng đường: " + (p.LaneLeft + p.LaneRight).ToString("0.###")
                    + " m  |  Dải giữa: " + p.Median.ToString("0.###") + " m";
            }
            catch
            {
                widthLabel.ForeColor = Color.DarkRed;
                widthLabel.Text = "Kiểm tra lại các giá trị đã nhập.";
            }
            preview.Invalidate();
        }

        private void DrawSection(object sender, PaintEventArgs e)
        {
            try
            {
                var p = ReadProfile();
                float scale = (preview.ClientSize.Width - 30f) / (float)p.RightOfWay;
                float left = 15f, top = 27f, height = 30f;
                float[] widths = { (float)p.SidewalkLeft, (float)p.LaneLeft,
                    (float)p.Median, (float)p.LaneRight, (float)p.SidewalkRight };
                Brush[] brushes = { Brushes.SandyBrown, Brushes.DimGray, Brushes.ForestGreen,
                    Brushes.DimGray, Brushes.SandyBrown };
                using (var pen = new Pen(Color.Black, 1f))
                {
                    for (int i = 0; i < widths.Length; i++)
                    {
                        float w = widths[i] * scale;
                        if (w < .1f) continue;
                        e.Graphics.FillRectangle(brushes[i], left, top, w, height);
                        e.Graphics.DrawRectangle(pen, left, top, w, height);
                        left += w;
                    }
                }
                var centerX = 15f + (float)p.RedLeft * scale;
                using (var dash = new Pen(Color.Red, 1.5f))
                {
                    dash.DashPattern = new float[] { 4, 3 };
                    e.Graphics.DrawLine(dash, centerX, 17f, centerX, 68f);
                }
                using (var font = new Font("Segoe UI", 8f))
                {
                    e.Graphics.DrawString("Vỉa hè", font, Brushes.Black, 15, 7);
                    e.Graphics.DrawString("Lòng đường", font, Brushes.Black, 156, 7);
                    e.Graphics.DrawString("Vỉa hè", font, Brushes.Black, 407, 7);
                    e.Graphics.DrawString(p.RightOfWay.ToString("0.##") + " m (lộ giới)", font,
                        Brushes.Black, 180, 69);
                }
            }
            catch { /* Thong so dang nhap do: an preview cho den khi hop le. */ }
        }

        private void Save(object sender, EventArgs e)
        {
            try
            {
                ResultProfile = ReadProfile();
                Scope = all.Checked ? EditScope.All : same.Checked ? EditScope.SameSection : EditScope.Selected;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Mặt cắt không hợp lệ"); }
        }
    }
}
