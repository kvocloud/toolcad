using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CadPolyline = Autodesk.AutoCAD.DatabaseServices.Polyline;
using NtsGeometry = NetTopologySuite.Geometries.Geometry;
using NetTopologySuite.Geometries;

namespace QHPlanningRoads
{
    internal static class CadBridge
    {
        internal const string RegApp = "QH_ROAD_SECTION";
        internal const string BoundaryLayer = "QH_RANH_QUY_HOACH";
        internal const string CleanLayer = "QH_TIM_DUONG_SACH";
        internal const string CurbLayer = "QH_BO_VIA";
        internal const string RedLayer = "QH_CHI_GIOI_DUONG_DO";
        internal const string BuildingLayer = "QH_CHI_GIOI_XAY_DUNG";
        internal const string MedianLayer = "QH_DAI_PHAN_CACH";
        internal const string RoadSurfaceLayer = "QH_VUNG_DAT_GIAO_THONG";
        // CleanLayer is now the authoritative EDITABLE road centerline layer,
        // not an output layer. QHBUILD must never make a duplicate centerline.
        internal static readonly string[] OutputLayers = { CurbLayer, RedLayer, BuildingLayer, MedianLayer, RoadSurfaceLayer };

        internal static void EnsureLayers(Database db, Transaction tr)
        {
            var table = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            MakeLayer(db, tr, table, BoundaryLayer, 1, false);
            MakeLayer(db, tr, table, CleanLayer, 2, true);
            MakeLayer(db, tr, table, CurbLayer, 7, false);
            MakeLayer(db, tr, table, RedLayer, 5, false);
            MakeLayer(db, tr, table, BuildingLayer, 6, false);
            MakeLayer(db, tr, table, MedianLayer, 3, false);
            MakeLayer(db, tr, table, RoadSurfaceLayer, 8, false);
        }

        private static void MakeLayer(Database db, Transaction tr, LayerTable table, string name, short color, bool center)
        {
            if (table.Has(name)) return;
            table.UpgradeOpen();
            var l = new LayerTableRecord { Name = name,
                Color = Color.FromColorIndex(ColorMethod.ByAci, color) };
            if (name == RoadSurfaceLayer) l.IsPlottable = false;
            if (center)
            {
                try { db.LoadLineTypeFile("CENTER", "acad.lin"); }
                catch { /* Van ve duoc voi Continuous neu file acad.lin khong co. */ }
                var lt = (LinetypeTable)tr.GetObject(db.LinetypeTableId, OpenMode.ForRead);
                if (lt.Has("CENTER")) l.LinetypeObjectId = lt["CENTER"];
            }
            table.Add(l); tr.AddNewlyCreatedDBObject(l, true);
        }

        internal static CadPolyline ReadBoundary(Database db, Transaction tr)
        {
            var found = TryReadBoundary(db, tr);
            if (found == null) throw new InvalidOperationException("Chưa thiết lập ranh: chạy QHSETUP.");
            return found;
        }

        internal static CadPolyline TryReadBoundary(Database db, Transaction tr)
        {
            var ms = GetModelSpace(db, tr);
            CadPolyline found = null;
            foreach (ObjectId id in ms)
            {
                var p = tr.GetObject(id, OpenMode.ForRead) as CadPolyline;
                if (p != null && p.Layer == BoundaryLayer)
                {
                    if (found != null) throw new InvalidOperationException("Có nhiều ranh quy hoạch. Chạy QHSETUP để chọn lại.");
                    found = p;
                }
            }
            return found;
        }

        internal static Polygon ToPolygon(CadPolyline poly, double curveTolerance, bool closeOpenCopy = false)
        {
            if ((!poly.Closed && !closeOpenCopy) || poly.NumberOfVertices < 3)
                throw new ArgumentException("Ranh giới phải là polyline khép kín.");
            var pts = ToCoordinates(poly, curveTolerance);
            // Imported/open contours often repeat their first vertex as their last.
            // Remove that duplicate before explicitly creating the closed NTS ring.
            if (pts.Count > 1 && pts[0].Distance(pts[pts.Count - 1]) < 0.000001)
                pts.RemoveAt(pts.Count - 1);
            if (pts.Count < 3) throw new ArgumentException("Ranh giới có quá ít điểm.");
            pts.Add(new Coordinate(pts[0]));
            var polygon = new GeometryFactory().CreatePolygon(pts.ToArray());
            if (!polygon.IsValid || polygon.Area <= 0)
                throw new ArgumentException("Ranh giới tự cắt hoặc không có diện tích.");
            return polygon;
        }

        internal static List<Coordinate> ToCoordinates(CadPolyline p, double error)
        {
            if (Math.Abs(p.Normal.Z - 1) > 0.00001 || Math.Abs(p.Normal.X) > 0.00001
                || Math.Abs(p.Normal.Y) > 0.00001)
                throw new ArgumentException("Polyline phải nằm trên mặt phẳng XY (Normal 0,0,1).");
            var points = new List<Coordinate>();
            int segments = p.Closed ? p.NumberOfVertices : p.NumberOfVertices - 1;
            for (int i = 0; i < segments; i++)
            {
                Point2d start = p.GetPoint2dAt(i);
                Point2d end = p.GetPoint2dAt((i + 1) % p.NumberOfVertices);
                double bulge = p.GetBulgeAt(i);
                if (points.Count == 0) points.Add(new Coordinate(start.X, start.Y));
                if (Math.Abs(bulge) < 1e-10)
                {
                    if (!p.Closed || i < segments - 1) points.Add(new Coordinate(end.X, end.Y));
                    continue;
                }
                double dx = end.X - start.X, dy = end.Y - start.Y;
                double chord = Math.Sqrt(dx * dx + dy * dy);
                if (chord < 1e-10) continue;
                double sweep = 4 * Math.Atan(bulge);
                double radius = Math.Abs(chord / (2 * Math.Sin(sweep / 2)));
                double h = chord / (2 * Math.Tan(sweep / 2));
                double cx = (start.X + end.X) / 2 - dy / chord * h;
                double cy = (start.Y + end.Y) / 2 + dx / chord * h;
                double firstAngle = Math.Atan2(start.Y - cy, start.X - cx);
                double e = Math.Min(Math.Max(error, 0.001), radius * 0.25);
                double maxStep = 2 * Math.Acos(Math.Max(-1, 1 - e / radius));
                int count = Math.Max(2, Math.Min(1000, (int)Math.Ceiling(Math.Abs(sweep) / maxStep)));
                for (int j = 1; j <= count; j++)
                {
                    if (p.Closed && i == segments - 1 && j == count) continue;
                    double a = firstAngle + sweep * j / count;
                    points.Add(j == count ? new Coordinate(end.X, end.Y)
                        : new Coordinate(cx + radius * Math.Cos(a), cy + radius * Math.Sin(a)));
                }
            }
            if (!p.Closed && points.Count == 1 && p.NumberOfVertices > 1)
            {
                Point2d last = p.GetPoint2dAt(p.NumberOfVertices - 1);
                points.Add(new Coordinate(last.X, last.Y));
            }
            // Khong lap lai diem dau voi closed polygon; NTS ToPolygon se tu dong dong ring.
            return points;
        }

        internal static List<RoadInput> RegisteredRoads(Database db, Transaction tr, double tolerance)
        {
            var result = new List<RoadInput>();
            foreach (ObjectId id in GetModelSpace(db, tr))
            {
                var p = tr.GetObject(id, OpenMode.ForRead) as CadPolyline;
                if (p == null || p.Closed || p.IsErased || IsGeneratedLayer(p.Layer)) continue;
                var profile = ReadProfile(p);
                if (profile == null) continue;
                bool manualArcs;
                var designPoints = ToDesignCenterline(p, profile, tolerance, out manualArcs);
                result.Add(new RoadInput { Handle = p.Handle.ToString(),
                    RoadCode = string.IsNullOrWhiteSpace(profile.RoadName)
                        ? "RD-" + p.Handle : profile.RoadName,
                    Profile = profile, Points = designPoints, HasUnmanagedArcs = manualArcs });
            }
            return result;
        }

        // On the second QHBUILD, recover original SHARP L vertices from the
        // native bulge arcs created by our last QHBUILD. Without this step,
        // offsetting a curved tim also rounds the OUTSIDE/back curb and redline.
        private static List<Coordinate> ToDesignCenterline(CadPolyline p, RoadProfile profile,
            double tolerance, out bool hasUnmanagedArcs)
        {
            bool hasArcs = false;
            for (int i = 0; i < p.NumberOfVertices - 1; i++)
                if (Math.Abs(p.GetBulgeAt(i)) > 1e-8) { hasArcs = true; break; }
            hasUnmanagedArcs = hasArcs && !profile.ManagedLCurves;
            if (!hasArcs) return ToCoordinates(p, tolerance);
            // Migration of V1.4 QHCLCURVE fillets: before V1.4.1 they had no
            // XData marker. Only accept a complete series of 90-degree arcs
            // whose exact radius matches the configured inside curb + R8.
            bool legacyMigration = !profile.ManagedLCurves;

            var sharp = new List<Coordinate>();
            bool invalid = false;
            for (int i = 0; i < p.NumberOfVertices; i++)
            {
                Point2d current = p.GetPoint2dAt(i);
                double bulge = p.GetBulgeAt(i);
                if (Math.Abs(bulge) < 1e-8)
                {
                    sharp.Add(new Coordinate(current.X, current.Y));
                    continue;
                }
                // [previous]--[arc entry/bulge]--[arc exit]--[next]
                if (i < 1 || i + 2 >= p.NumberOfVertices
                    || Math.Abs(p.GetBulgeAt(i - 1)) > 1e-8
                    || Math.Abs(p.GetBulgeAt(i + 1)) > 1e-8)
                { invalid = true; break; }
                Point2d prev = p.GetPoint2dAt(i - 1);
                Point2d exit = p.GetPoint2dAt(i + 1);
                Point2d next = p.GetPoint2dAt(i + 2);
                double ux = current.X - prev.X, uy = current.Y - prev.Y;
                double vx = next.X - exit.X, vy = next.Y - exit.Y;
                double lenA = Math.Sqrt(ux * ux + uy * uy), lenB = Math.Sqrt(vx * vx + vy * vy);
                double determinant = ux * vy - uy * vx;
                if (lenA < 1e-8 || lenB < 1e-8 || Math.Abs(determinant) < 1e-5 * lenA * lenB)
                { invalid = true; break; }
                double t = ((exit.X - prev.X) * vy - (exit.Y - prev.Y) * vx) / determinant;
                double x = prev.X + ux * t, y = prev.Y + uy * t;
                var vertex = new Coordinate(x, y);
                double entryDist = vertex.Distance(new Coordinate(current.X, current.Y));
                double exitDist = vertex.Distance(new Coordinate(exit.X, exit.Y));
                double bend = Math.Acos(Math.Max(-1, Math.Min(1,
                    (ux * vx + uy * vy) / (lenA * lenB))));
                double expectedBulge = Math.Sign(determinant) * Math.Tan(bend / 4.0);
                double chord = current.GetDistanceTo(exit);
                double sweep = 4 * Math.Atan(bulge);
                double actualRadius = Math.Abs(chord / (2 * Math.Sin(sweep / 2.0)));
                double innerWidth = determinant > 0 ? profile.CurbLeft : profile.CurbRight;
                double requiredRadius = profile.CurbRadius + innerWidth;
                if (Math.Abs(bend - Math.PI / 2) > Math.PI / 18
                    || Math.Abs(entryDist - exitDist) > 0.01
                    || Math.Abs(bulge - expectedBulge) > 0.001
                    || (legacyMigration && Math.Abs(actualRadius - requiredRadius) > 0.03)
                    || t < 1.0 || entryDist < 0.001 || exitDist < 0.001)
                { invalid = true; break; }
                sharp.Add(vertex);
                i++; // arc exit is replaced by the original design vertex
            }
            if (!invalid)
            {
                if (legacyMigration) profile.ManagedLCurves = true;
                hasUnmanagedArcs = false;
                return sharp;
            }
            // A user may have edited native arcs. Preserve their source geometry
            // instead of accidentally removing them while re-establishing tim.
            hasUnmanagedArcs = true;
            return ToCoordinates(p, tolerance);
        }

        internal static RoadProfile ReadProfile(CadPolyline p)
        {
            using (var data = p.GetXDataForApplication(RegApp))
            {
                if (data == null) return null;
                var array = data.AsArray();
                foreach (var value in array)
                    if (value.TypeCode == (int)DxfCode.ExtendedDataAsciiString)
                        return RoadProfile.Parse(value.Value as string);
            }
            return null;
        }

        internal static void SaveProfile(Database db, Transaction tr, CadPolyline p, RoadProfile section)
        {
            var apps = (RegAppTable)tr.GetObject(db.RegAppTableId, OpenMode.ForRead);
            if (!apps.Has(RegApp))
            {
                apps.UpgradeOpen();
                var app = new RegAppTableRecord { Name = RegApp };
                apps.Add(app); tr.AddNewlyCreatedDBObject(app, true);
            }
            if (!p.IsWriteEnabled) p.UpgradeOpen();
            using (var data = new ResultBuffer(
                new TypedValue((int)DxfCode.ExtendedDataRegAppName, RegApp),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString, section.Serialize())))
                p.XData = data;
        }

        internal static void ReplaceBoundary(Database db, Transaction tr, CadPolyline selected,
            bool closeOpenCopy = false)
        {
            var ms = GetModelSpace(db, tr);
            // Tao ban sao truoc khi xoa ranh cu (nguoi dung co the chon chinh ranh do).
            var copy = (CadPolyline)selected.Clone();
            if (closeOpenCopy && !copy.Closed)
            {
                // Closing the copy adds a STRAIGHT last-to-first segment. The source
                // polyline and its previous last-vertex bulge remain untouched.
                copy.SetBulgeAt(copy.NumberOfVertices - 1, 0);
                copy.Closed = true;
            }
            var old = new List<ObjectId>();
            foreach (ObjectId id in ms)
            {
                var p = tr.GetObject(id, OpenMode.ForRead) as CadPolyline;
                if (p != null && p.Layer == BoundaryLayer) old.Add(id);
            }
            // Chỉ xóa bản sao trên layer do plugin quản lý.
            foreach (var id in old) tr.GetObject(id, OpenMode.ForWrite).Erase();
            copy.Layer = BoundaryLayer;
            ms.UpgradeOpen();
            ms.AppendEntity(copy); tr.AddNewlyCreatedDBObject(copy, true);
        }

        internal static void ReplaceGenerated(Database db, Transaction tr, BuildResult build,
            Polygon site, double boundaryStrip)
        {
            var ms = GetModelSpace(db, tr);
            var obsolete = new List<ObjectId>();
            foreach (ObjectId id in ms)
            {
                var e = tr.GetObject(id, OpenMode.ForRead) as Entity;
                if (e == null) continue;
                if (IsGeneratedLayer(e.Layer)) obsolete.Add(id);
                else if (e.Layer == CleanLayer)
                {
                    // Legacy V1/V1.2 created centerline duplicates without XData.
                    // Delete only those legacy generated objects on our own layer.
                    var p = e as CadPolyline;
                    if (p != null && ReadProfile(p) == null) obsolete.Add(id);
                }
            }
            foreach (ObjectId id in obsolete) tr.GetObject(id, OpenMode.ForWrite).Erase();
            ms.UpgradeOpen();
            // Bo duong tren ranh site duoc loai bo, chi the hien phan ranh tiep giap lo dat.
            NtsGeometry nearBorder = site.Boundary.Buffer(boundaryStrip);
            var curbRadii = build.CleanedRoads.Select(r => r.Profile.CurbRadius)
                .Where(r => r > 0).Distinct().ToList();
            AddGeometryLinework(ms, tr, build.Curb.Boundary.Difference(nearBorder), CurbLayer, curbRadii);
            AddGeometryLinework(ms, tr, build.RedLine.Boundary.Difference(nearBorder), RedLayer, null);
            if (build.BuildingLine != null && !build.BuildingLine.IsEmpty)
            {
                // Do not double-draw the same red line when the setback is 0.
                var changed = build.BuildingLine.Boundary
                    .Difference(build.RedLine.Boundary.Buffer(0.005));
                AddGeometryLinework(ms, tr, changed.Difference(nearBorder), BuildingLayer, null);
            }
            if (build.Median != null && !build.Median.IsEmpty)
                AddGeometryLinework(ms, tr, build.Median.Boundary.Difference(nearBorder), MedianLayer, null);
            // Duong bao khoi dat giao thong de tham khao / thong ke tiep theo.
            // Neu vung co lo thung, cac ring ben trong duoc ve rieng; thong ke dung Geometry.Area.
            AddGeometryLinework(ms, tr, build.RedLine.Boundary, RoadSurfaceLayer, null);
        }

        internal static void UpdateAuthoritativeCenterlines(Database db, Transaction tr,
            IList<RoadInput> cleaned, IList<CenterlineCurve> lCurves = null)
        {
            var byHandle = cleaned.ToDictionary(r => r.Handle, r => r,
                StringComparer.OrdinalIgnoreCase);
            int updated = 0;
            foreach (ObjectId id in GetModelSpace(db, tr))
            {
                var p = tr.GetObject(id, OpenMode.ForRead) as CadPolyline;
                if (p == null || p.IsErased || p.Closed) continue;
                RoadInput r;
                if (!byHandle.TryGetValue(p.Handle.ToString(), out r)) continue;
                if (ReadProfile(p) == null) continue;
                p.UpgradeOpen();
                p.Layer = CleanLayer;
                var existingProfile = ReadProfile(p);
                var ownCurves = lCurves == null ? new List<CenterlineCurve>()
                    : lCurves.Where(c => string.Equals(c.Handle, r.Handle,
                        StringComparison.OrdinalIgnoreCase)).OrderBy(c => c.VertexIndex).ToList();
                if (!r.HasUnmanagedArcs && (ownCurves.Count > 0 || existingProfile.ManagedLCurves))
                {
                    // Rewrite THIS SAME PLINE, preserving its entity handle;
                    // use sharp design vertices and exact AutoCAD ARC bulges.
                    var positions = new List<Point2d>();
                    var bulges = new List<double>();
                    for (int k = 0; k < r.Points.Count; k++)
                    {
                        var plan = ownCurves.FirstOrDefault(c => c.VertexIndex == k);
                        if (plan == null)
                        {
                            positions.Add(new Point2d(r.Points[k].X, r.Points[k].Y));
                            bulges.Add(0);
                        }
                        else
                        {
                            positions.Add(new Point2d(plan.Entry.X, plan.Entry.Y));
                            bulges.Add(plan.Bulge);
                            positions.Add(new Point2d(plan.Exit.X, plan.Exit.Y));
                            bulges.Add(0);
                        }
                    }
                    if (positions.Count < 2)
                        throw new InvalidOperationException("Tim đường bo L còn ít hơn 2 đỉnh.");
                    // Keep ObjectId/handle stable: no cloned centerline is added.
                    for (int k = p.NumberOfVertices - 1; k >= 2; k--) p.RemoveVertexAt(k);
                    p.SetPointAt(0, positions[0]); p.SetBulgeAt(0, bulges[0]);
                    p.SetPointAt(1, positions[1]); p.SetBulgeAt(1, bulges[1]);
                    for (int k = 2; k < positions.Count; k++)
                        p.AddVertexAt(k, positions[k], bulges[k], 0, 0);
                    existingProfile.ManagedLCurves = ownCurves.Count > 0;
                    SaveProfile(db, tr, p, existingProfile);
                    updated++;
                    continue;
                }
                // Change only endpoints; do not destroy original native bulge arcs
                // by writing the tessellated geometry used inside the NTS engine.
                var first = r.Points[0]; var last = r.Points[r.Points.Count - 1];
                p.SetPointAt(0, new Point2d(first.X, first.Y));
                p.SetPointAt(p.NumberOfVertices - 1, new Point2d(last.X, last.Y));
                for (int i = p.NumberOfVertices - 1; i > 0; i--)
                {
                    if (p.NumberOfVertices <= 2) break;
                    if (p.GetPoint2dAt(i).GetDistanceTo(p.GetPoint2dAt(i - 1)) < 0.000001
                        && Math.Abs(p.GetBulgeAt(i - 1)) < 1e-10)
                        p.RemoveVertexAt(i);
                }
                updated++;
            }
            if (updated != cleaned.Count)
                throw new InvalidOperationException("Không cập nhật đủ tim đường. Hãy thử QHROADS lại.");
        }

        private static void AddGeometryLinework(BlockTableRecord ms, Transaction tr, NtsGeometry geom,
            string layer, IList<double> arcRadii)
        {
            var line = geom as LineString;
            if (line != null)
            {
                var coords = line.Coordinates;
                if (coords.Length < 2) return;
                bool closed = coords[0].Distance(coords[coords.Length - 1]) < 0.000001;
                AddPolyline(ms, tr, coords.ToList(), layer, closed, arcRadii);
                return;
            }
            for (int i = 0; i < geom.NumGeometries; i++)
                if (!Object.ReferenceEquals(geom, geom.GetGeometryN(i)))
                    AddGeometryLinework(ms, tr, geom.GetGeometryN(i), layer, arcRadii);
        }

        private static void AddPolyline(BlockTableRecord ms, Transaction tr, IList<Coordinate> points,
            string layer, bool closed, IList<double> arcRadii)
        {
            int count = points.Count;
            if (closed && count > 1 && points[0].Distance(points[count - 1]) < 1e-7) count--;
            if (count < 2) return;
            var compact = CompactCircularArcs(points.Take(count).ToList(), arcRadii);
            var p = new CadPolyline(compact.Count) { Layer = layer };
            for (int i = 0; i < compact.Count; i++)
                p.AddVertexAt(i, new Point2d(compact[i].Point.X, compact[i].Point.Y),
                    compact[i].Bulge, 0, 0);
            p.Closed = closed;
            ms.AppendEntity(p); tr.AddNewlyCreatedDBObject(p, true);
        }

        private sealed class VertexData
        {
            public Coordinate Point;
            public double Bulge;
        }

        // Chuyen cac day diem tessellation gan cung R8 ve cung ARC native bang bulge.
        // Chi thao tac khi fit tron trong 1cm va R khop cau hinh; phan con lai giu pline thang.
        private static List<VertexData> CompactCircularArcs(IList<Coordinate> points, IList<double> radii)
        {
            var result = new List<VertexData>();
            if (radii == null || radii.Count == 0)
            {
                foreach (var pt in points) result.Add(new VertexData { Point = pt });
                return result;
            }
            int index = 0;
            while (index < points.Count)
            {
                int end;
                double bulge;
                if (TryCircularRun(points, index, radii, out end, out bulge))
                {
                    result.Add(new VertexData { Point = points[index], Bulge = bulge });
                    index = end;
                }
                else
                {
                    result.Add(new VertexData { Point = points[index] });
                    index++;
                }
            }
            return result;
        }

        private static bool TryCircularRun(IList<Coordinate> pts, int begin, IList<double> radii,
            out int end, out double bulge)
        {
            end = begin; bulge = 0;
            if (begin + 3 >= pts.Count) return false; // >=4 diem moi gop ARC.
            var a = pts[begin]; var b = pts[begin + 1]; var c = pts[begin + 2];
            double determinant = 2 * (a.X * (b.Y - c.Y) + b.X * (c.Y - a.Y) + c.X * (a.Y - b.Y));
            if (Math.Abs(determinant) < 1e-9) return false;
            double a2 = a.X * a.X + a.Y * a.Y;
            double b2 = b.X * b.X + b.Y * b.Y;
            double c2 = c.X * c.X + c.Y * c.Y;
            double cx = (a2 * (b.Y - c.Y) + b2 * (c.Y - a.Y) + c2 * (a.Y - b.Y)) / determinant;
            double cy = (a2 * (c.X - b.X) + b2 * (a.X - c.X) + c2 * (b.X - a.X)) / determinant;
            double radius = Math.Sqrt((a.X - cx) * (a.X - cx) + (a.Y - cy) * (a.Y - cy));
            if (!radii.Any(r => Math.Abs(r - radius) < 0.02)) return false;
            int direction = determinant > 0 ? 1 : -1;
            double sweep = 0;
            int last = begin;
            for (int k = begin + 1; k < pts.Count; k++)
            {
                var current = pts[k]; var prev = pts[k - 1];
                double dr = Math.Sqrt((current.X - cx) * (current.X - cx)
                    + (current.Y - cy) * (current.Y - cy));
                if (Math.Abs(dr - radius) > 0.015) break;
                double vx = prev.X - cx, vy = prev.Y - cy;
                double wx = current.X - cx, wy = current.Y - cy;
                double step = Math.Atan2(vx * wy - vy * wx, vx * wx + vy * wy);
                if (step * direction <= 0 || Math.Abs(step) > Math.PI / 4
                    || Math.Abs(sweep + step) > Math.PI + 0.001) break;
                sweep += step;
                last = k;
            }
            if (last - begin < 3 || Math.Abs(sweep) < 0.05) return false;
            end = last;
            bulge = Math.Tan(sweep / 4.0);
            return true;
        }

        internal static BlockTableRecord GetModelSpace(Database db, Transaction tr)
        {
            var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
            return (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead);
        }

        internal static bool IsPluginOwnedLayer(string s) { return s == BoundaryLayer || OutputLayers.Contains(s); }
        private static bool IsGeneratedLayer(string s) { return OutputLayers.Contains(s); }
    }
}
