using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using NetTopologySuite.Geometries;
using NetTopologySuite.Operation.Union;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CadPolyline = Autodesk.AutoCAD.DatabaseServices.Polyline;
using NtsPolygon = NetTopologySuite.Geometries.Polygon;

namespace QHPlanningRoads
{
    public sealed partial class Commands
    {
        [CommandMethod("QHDU")]
        public void ToggleUnallocatedLandVisibility()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var opt = new PromptKeywordOptions(
                "\nHiển thị ô QH_DAT_CHUA_CHIA để kiểm tra? [Show/Hide] <Hide>: ");
            opt.Keywords.Add("Show");
            opt.Keywords.Add("Hide");
            opt.Keywords.Default = "Hide";
            var selected = doc.Editor.GetKeywords(opt);
            if (selected.Status != PromptStatus.OK) return;
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                LandStore.SetRemainderVisible(doc.Database, tr, selected.StringResult == "Show");
                tr.Commit();
            }
            doc.Editor.WriteMessage(selected.StringResult == "Show"
                ? "\nĐã hiện các vùng còn lại để hậu kiểm."
                : "\nĐã ẩn vùng còn lại; dữ liệu vẫn được giữ để QHAUDIT/QHEXPORT.");
        }

        // Manually define a block or lot by clicking INSIDE a bounded area
        // (Editor.TraceBoundary, like BOUNDARY) or selecting an existing PLINE.
        // EditLot replaces only its selected child, keeping code and parent.
        [CommandMethod("QHLA")]
        public void AddManualLandBoundary()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            var kind = new PromptKeywordOptions(
                "\nChon che do [Lo/O/SuaLo/SuaO] <Lo>: ");
            foreach (string k in new[] { "Lo", "O", "SuaLo", "SuaO" })
                kind.Keywords.Add(k);
            kind.Keywords.Default = "Lo";
            var chosen = ed.GetKeywords(kind);
            if (chosen.Status != PromptStatus.OK) return;
            string mode = chosen.StringResult == "O" ? "Block"
                : chosen.StringResult == "SuaO" ? "EditBlock"
                : chosen.StringResult == "SuaLo" ? "EditLot" : "Lot";
            // The remainder polygons are bookkeeping, not new editable lots.
            // Hide them during manual picking so they do not mask QH_O_DAT.
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                LandStore.SetRemainderVisible(doc.Database, tr, false);
                LandStore.PromoteBlockDrawOrder(doc.Database, tr);
                tr.Commit();
            }
            // For new lots infer the parent QH_O_DAT polygon automatically
            // from each clicked closed region. No need to select it, even
            // when consecutive picks belong to DIFFERENT land blocks.
            ObjectId selectedParent = ObjectId.Null;
            ed.WriteMessage("\nQHLA: Bam lien tiep trong vung kin. Enter de ket thuc."
                + " Go Pline de chon mot net; Nhieu de chon nhieu net.");
            while (true)
            {
                var pickOptions = new PromptPointOptions(
                    "\nBam TRONG vung kin [Pline/Nhieu] <Enter=Ket thuc>: ");
                pickOptions.AllowNone = true;
                pickOptions.Keywords.Add("Pline");
                pickOptions.Keywords.Add("Nhieu");
                var point = ed.GetPoint(pickOptions);
                if (point.Status == PromptStatus.None
                    || point.Status == PromptStatus.Cancel) break;
                if (point.Status == PromptStatus.Keyword)
                {
                    if (point.StringResult == "Pline")
                    {
                        NtsPolygon one = SelectManualPline(doc);
                        if (one != null)
                            ProcessOneManualLandBoundary(doc, mode, one, selectedParent);
                    }
                    else if (point.StringResult == "Nhieu")
                        ProcessManyManualPolylines(doc, mode, selectedParent);
                    continue;
                }
                if (point.Status != PromptStatus.OK) break;
                try
                {
                    NtsPolygon area = TraceManualPolygon(doc, point.Value);
                    ProcessOneManualLandBoundary(doc, mode, area, selectedParent);
                }
                catch (System.Exception ex) { Report(ed, ex); }
            }
            ed.WriteMessage("\nQHLA ket thuc. Chay QHAUDIT va QHLABEL khi can.");
        }

        private static void ProcessManyManualPolylines(
            Autodesk.AutoCAD.ApplicationServices.Document doc, string mode, ObjectId parentId)
        {
            var ed = doc.Editor;
            var filter = new SelectionFilter(new[] {
                new TypedValue((int)DxfCode.Start, "LWPOLYLINE")
            });
            var selection = ed.GetSelection(new PromptSelectionOptions {
                MessageForAdding = "\nChon nhieu PLINE KHEP KIN: "
            }, filter);
            if (selection.Status != PromptStatus.OK) return;
            if (!Confirm(ed, "\nTao/sua " + selection.Value.Count
                + " vung? [Co/Khong] <Khong>: ", "Co", "Khong")) return;
            foreach (ObjectId id in selection.Value.GetObjectIds())
            {
                try
                {
                    NtsPolygon area;
                    using (var tr = doc.Database.TransactionManager.StartTransaction())
                    {
                        var poly = (CadPolyline)tr.GetObject(id, OpenMode.ForRead);
                        if (!poly.Closed)
                            throw new ArgumentException("Bo qua PLINE mo: " + poly.Handle);
                        area = CadBridge.ToPolygon(poly, Settings.CurveTolerance);
                    }
                    ProcessOneManualLandBoundary(doc, mode, area, parentId);
                }
                catch (System.Exception ex) { Report(ed, ex); }
            }
        }

        private static bool ProcessOneManualLandBoundary(
            Autodesk.AutoCAD.ApplicationServices.Document doc, string mode,
            NtsPolygon selectedArea, ObjectId chosenParentId)
        {
            var ed = doc.Editor;
            bool isLot = mode == "Lot" || mode == "EditLot";
            bool edit = mode == "EditLot" || mode == "EditBlock";
            ObjectId existingId = ObjectId.Null;
            ObjectId parentId = chosenParentId;
            LandMetadata metadata = null;
            try
            {
                if (edit)
                {
                    existingId = PickManagedLand(ed, isLot ? LandStore.LotLayer : LandStore.BlockLayer,
                        "\nChọn " + (isLot ? "lô" : "ô") + " cần THAY RANH: ");
                    if (existingId == ObjectId.Null) return false;
                }
                NtsPolygon area = selectedArea ?? PickManualPolygon(doc);
                if (area == null) return false;
                NtsPolygon parent = null;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    if (edit)
                    {
                        var original = (CadPolyline)tr.GetObject(existingId, OpenMode.ForRead);
                        metadata = LandStore.Read(original);
                    }
                    if (isLot)
                    {
                        CadPolyline parentPoly = null;
                        if (edit)
                        {
                            foreach (var b in LandStore.Polylines(doc.Database, tr, LandStore.BlockLayer))
                            {
                                var d = LandStore.Read(b);
                                if (d != null && d.Code == metadata.ParentCode) { parentPoly = b; break; }
                            }
                        }
                        else if (parentId != ObjectId.Null)
                            parentPoly = (CadPolyline)tr.GetObject(parentId, OpenMode.ForRead);
                        else
                        {
                            // Pick the tightest polygon that contains the
                            // entire proposed lot, not just its centroid.
                            double leastArea = double.PositiveInfinity;
                            foreach (var b in LandStore.Polylines(
                                doc.Database, tr, LandStore.BlockLayer))
                            {
                                var bm = LandStore.Read(b);
                                if (bm == null) continue;
                                var shape = LandStore.ReconstructBlock(
                                    doc.Database, tr, b, Settings.CurveTolerance);
                                if (area.Difference(shape).Area > 0.05
                                    || shape.Area >= leastArea) continue;
                                leastArea = shape.Area;
                                parentPoly = b;
                            }
                        }
                        if (parentPoly == null) throw new ArgumentException("Không tìm thấy ô đất mẹ của lô.");
                        parent = LandStore.ReconstructBlock(doc.Database, tr, parentPoly, Settings.CurveTolerance);
                        if (area.Difference(parent).Area > 0.05)
                            throw new ArgumentException("Ranh lô vượt quá ô đất mẹ. Chỉnh lại PLINE/điểm pick.");
                        if (!edit)
                        {
                            var pm = LandStore.Read(parentPoly);
                            metadata = new LandMetadata { Kind = "LOT", ParentCode = pm.Code,
                                UseCode = pm.UseCode, Code = NextManualCode(doc.Database, tr, pm.Code + "-LM") };
                        }
                        foreach (var lot in LandStore.Polylines(doc.Database, tr, LandStore.LotLayer))
                        {
                            if (lot.ObjectId == existingId) continue;
                            var d = LandStore.Read(lot);
                            if (d == null || d.ParentCode != metadata.ParentCode) continue;
                            var other = CadBridge.ToPolygon(lot, Settings.CurveTolerance);
                            if (area.Intersection(other).Area > 0.05)
                                throw new ArgumentException("Ranh mới chồng lấn lô " + d.Code
                                    + ". Không tự xóa lô khác.");
                        }
                        foreach (var road in LandStore.Polylines(doc.Database, tr, LandStore.AccessRoadLayer))
                        {
                            var d = LandStore.Read(road);
                            if (d != null && d.ParentCode == metadata.ParentCode
                                && area.Intersection(CadBridge.ToPolygon(road, Settings.CurveTolerance)).Area > 0.05)
                                throw new ArgumentException("Ranh lô chồng lên đường nội bộ " + d.Code + ".");
                        }
                    }
                    else
                    {
                        var bnd = CadBridge.TryReadBoundary(doc.Database, tr);
                        if (bnd != null && area.Difference(CadBridge.ToPolygon(bnd, Settings.CurveTolerance)).Area > 0.05)
                            throw new ArgumentException("Ranh ô đất vượt ranh quy hoạch.");
                        var roads = CadBridge.RegisteredRoads(doc.Database, tr, Settings.CurveTolerance);
                        if (roads.Count > 0)
                        {
                            var design = new RoadGeometry().Build(bnd == null ? null
                                : CadBridge.ToPolygon(bnd, Settings.CurveTolerance), roads, Settings);
                            if (area.Intersection(design.RedLine).Area > 0.05)
                                throw new ArgumentException("Ranh ô đất chồng lấn hành lang đường đỏ.");
                        }
                        foreach (var block in LandStore.Polylines(doc.Database, tr, LandStore.BlockLayer))
                        {
                            if (block.ObjectId == existingId) continue;
                            var blockShape = LandStore.ReconstructBlock(doc.Database,
                                tr, block, Settings.CurveTolerance);
                            if (area.Intersection(blockShape).Area <= 0.05) continue;
                            // Re-picking an automatically identified QH_O_DAT is
                            // legal: reuse its metadata and replace its geometry.
                            if (!edit && area.SymmetricDifference(blockShape).Area < 0.05)
                            {
                                existingId = block.ObjectId;
                                metadata = LandStore.Read(block);
                                edit = true;
                                continue;
                            }
                            throw new ArgumentException("Vùng pick giao ô " +
                                (LandStore.Read(block) ?? new LandMetadata()).Code +
                                ". Nếu là ô cũ, dùng EditBlock; nếu cần chia nhỏ, tách ranh ô trước.");
                        }
                        if (!edit && metadata == null)
                            metadata = new LandMetadata { Kind = "BLOCK", ParentCode = "",
                                Code = NextManualCode(doc.Database, tr, "OD-M"), UseCode = "CHUA_GAN" };
                    }
                }
                if (mode == "EditBlock" && !Confirm(ed,
                    "\nĐổi ranh ô có thể làm lô cũ sai chỉ tiêu. Giữ nguyên lô và kiểm tra QHAUDIT? [Keep/Cancel] <Cancel>: ",
                    "Keep", "Cancel")) return false;

                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    LandStore.EnsureLayers(doc.Database, tr);
                    // Keep an unallocated remainder matched to the parent when
                    // a manually drawn lot replaces an automatic lot.
                    if (isLot)
                        ReplaceRemaindersForManualLot(doc.Database, tr, area, metadata,
                            edit ? existingId : ObjectId.Null, parent);
                    if (edit)
                        tr.GetObject(existingId, OpenMode.ForWrite).Erase();
                    LandStore.AddPolygon(doc.Database, tr, area,
                        isLot ? LandStore.LotLayer : LandStore.BlockLayer, metadata);
                    LandStore.PromoteBlockDrawOrder(doc.Database, tr);
                    LandLabelBlocks.ClearForCodes(doc.Database, tr,
                        new HashSet<string>(StringComparer.OrdinalIgnoreCase) { metadata.Code });
                    tr.Commit();
                }
                ed.WriteMessage("\nDa " + (edit ? "sua " : "tao ")
                    + metadata.Code + " (" + area.Area.ToString("N2")
                    + " m2). Tiep tuc bam, Enter de ket thuc.");
                return true;
            }
            catch (System.Exception ex) { Report(ed, ex); return true; }
        }

        private static NtsPolygon PickManualPolygon(Autodesk.AutoCAD.ApplicationServices.Document doc)
        {
            var ed = doc.Editor;
            var mode = new PromptKeywordOptions(
                "\nLấy ranh theo [PickInside/SelectPline] <PickInside>: ");
            mode.Keywords.Add("PickInside"); mode.Keywords.Add("SelectPline");
            mode.Keywords.Default = "PickInside";
            var selectedMode = ed.GetKeywords(mode);
            if (selectedMode.Status != PromptStatus.OK) return null;
            if (selectedMode.StringResult == "SelectPline") return SelectManualPline(doc);
            var seed = ed.GetPoint("\nBấm một điểm NẰM TRONG vùng khép kín (kiểu BOUNDARY): ");
            return seed.Status == PromptStatus.OK ? TraceManualPolygon(doc, seed.Value) : null;
        }

        private static NtsPolygon SelectManualPline(Autodesk.AutoCAD.ApplicationServices.Document doc)
        {
                var ed = doc.Editor;
                var opt = new PromptEntityOptions("\nChon PLINE khép kín: ");
                opt.SetRejectMessage("\nChỉ chọn LWPOLYLINE.");
                opt.AddAllowedClass(typeof(CadPolyline), true);
                var entity = ed.GetEntity(opt);
                if (entity.Status != PromptStatus.OK) return null;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var poly = (CadPolyline)tr.GetObject(entity.ObjectId, OpenMode.ForRead);
                    if (poly.Closed) return CadBridge.ToPolygon(poly, Settings.CurveTolerance);
                    double gap = poly.GetPoint2dAt(0).GetDistanceTo(
                        poly.GetPoint2dAt(poly.NumberOfVertices - 1));
                    if (gap > Settings.SnapTolerance || !Confirm(ed,
                        "\nPLINE đang Open; đóng bản sao bằng đoạn cuối-đầu? [CloseCopy/Cancel] <Cancel>: ",
                        "CloseCopy", "Cancel")) return null;
                    return CadBridge.ToPolygon(poly, Settings.CurveTolerance, true);
                }
        }

        private static NtsPolygon TraceManualPolygon(
            Autodesk.AutoCAD.ApplicationServices.Document doc, Point3d point)
        {
            var traced = doc.Editor.TraceBoundary(point, false);
            if (traced == null || traced.Count == 0)
                throw new ArgumentException("Không trace được vùng kín tại điểm pick. Hãy chọn SelectPline.");
            try
            {
                foreach (DBObject obj in traced)
                {
                    var poly = obj as CadPolyline;
                    if (poly == null || poly.NumberOfVertices < 3) continue;
                    return CadBridge.ToPolygon(poly, Settings.CurveTolerance, !poly.Closed);
                }
            }
            finally
            {
                foreach (DBObject obj in traced) obj.Dispose();
            }
            throw new ArgumentException("TraceBoundary không trả về LWPOLYLINE hợp lệ. Dùng SelectPline.");
        }

        private static ObjectId PickManagedLand(Editor ed, string layer, string prompt)
        {
            var opt = new PromptEntityOptions(prompt);
            opt.SetRejectMessage("\nChỉ chọn ô/lô LWPOLYLINE do plugin quản lý.");
            opt.AddAllowedClass(typeof(CadPolyline), true);
            var selected = ed.GetEntity(opt);
            if (selected.Status != PromptStatus.OK) return ObjectId.Null;
            using (var tr = ed.Document.Database.TransactionManager.StartTransaction())
            {
                var poly = (CadPolyline)tr.GetObject(selected.ObjectId, OpenMode.ForRead);
                var meta = LandStore.Read(poly);
                if (poly.Layer != layer || meta == null
                    || (layer == LandStore.LotLayer && meta.Kind != "LOT")
                    || (layer == LandStore.BlockLayer && meta.Kind != "BLOCK"))
                    throw new ArgumentException("Đối tượng chọn không phải ô/lô có metadata của plugin.");
            }
            return selected.ObjectId;
        }

        private static string NextManualCode(Database db, Transaction tr, string prefix)
        {
            var codes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string layer in new[] { LandStore.BlockLayer, LandStore.LotLayer,
                LandStore.RemainderLayer, LandStore.AccessRoadLayer })
                foreach (var poly in LandStore.Polylines(db, tr, layer))
                {
                    var meta = LandStore.Read(poly);
                    if (meta != null) codes.Add(meta.Code);
                }
            for (int i = 1; i < 100000; i++)
            {
                string candidate = prefix + i.ToString("000");
                if (!codes.Contains(candidate)) return candidate;
            }
            throw new InvalidOperationException("Không còn mã ô/lô thủ công.");
        }

        private static void ReplaceRemaindersForManualLot(Database db, Transaction tr,
            NtsPolygon newArea, LandMetadata meta, ObjectId originalId,
            NtsPolygon parent)
        {
            // Recompute unallocated land as parent minus ALL accepted child lots
            // and access roads. This also makes the FIRST hand-drawn lot pass
            // QHAUDIT rather than reporting the untouched remainder as missing.
            var occupied = new List<Geometry> { newArea };
            foreach (var lot in LandStore.Polylines(db, tr, LandStore.LotLayer))
            {
                if (lot.ObjectId == originalId) continue;
                var data = LandStore.Read(lot);
                if (data != null && data.ParentCode == meta.ParentCode)
                    occupied.Add(CadBridge.ToPolygon(lot, 0.02));
            }
            foreach (var road in LandStore.Polylines(db, tr, LandStore.AccessRoadLayer))
            {
                var data = LandStore.Read(road);
                if (data != null && data.ParentCode == meta.ParentCode)
                    occupied.Add(CadBridge.ToPolygon(road, 0.02));
            }
            foreach (var rem in LandStore.Polylines(db, tr, LandStore.RemainderLayer))
            {
                var d = LandStore.Read(rem);
                if (d == null || d.ParentCode != meta.ParentCode) continue;
                rem.UpgradeOpen(); rem.Erase();
            }
            Geometry leftover = parent.Difference(UnaryUnionOp.Union(occupied));
            int index = 1;
            foreach (var part in ExtractPolygons(leftover))
            {
                if (part.Area < 0.001) continue;
                if (part.NumInteriorRings > 0)
                    throw new InvalidOperationException("Đất dư tạo lỗ khép kín: phần mềm không tự làm mất lỗ. "
                        + "Hãy vẽ ranh mới chạm một cạnh ô đất hoặc chia ô trước khi gán lô.");
                LandStore.AddPolygon(db, tr, part, LandStore.RemainderLayer,
                    new LandMetadata { Kind = "REMAINDER", ParentCode = meta.ParentCode,
                        Code = meta.ParentCode + "-DU-M" + (index++).ToString("000"),
                        UseCode = "CHUA_CHIA" });
            }
        }

        private static IEnumerable<NtsPolygon> ExtractPolygons(Geometry g)
        {
            if (g is NtsPolygon) { yield return (NtsPolygon)g; yield break; }
            for (int i = 0; i < g.NumGeometries; i++)
                if (g.GetGeometryN(i) is NtsPolygon) yield return (NtsPolygon)g.GetGeometryN(i);
        }
    }
}
