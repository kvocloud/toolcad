using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;

namespace QHPlanningRoads
{
    internal sealed class LandImportRow
    {
        public string Code;
        public string Handle;
        public string Area;
        public string Density;
        public string Floors;
        public string Far;
        public int ExcelRow;
    }

    // Only reads the CAD-generated .xlsx sheet. No COM, Excel installation or
    // formulas/macros are executed. This also reads Excel's shared-string form.
    internal static class ExcelReader
    {
        private static readonly XNamespace Ns =
            "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

        internal static List<LandImportRow> ReadLandIndicators(string filename)
        {
            var result = new List<LandImportRow>();
            using (var file = File.OpenRead(filename))
            using (var zip = new ZipArchive(file, ZipArchiveMode.Read))
            {
                var book = Load(zip, "xl/workbook.xml");
                var rels = Load(zip, "xl/_rels/workbook.xml.rels");
                XNamespace bookRel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
                var sheet = book.Descendants(Ns + "sheet").FirstOrDefault(s =>
                    string.Equals((string)s.Attribute("name"), "Bang SDD", StringComparison.OrdinalIgnoreCase));
                if (sheet == null) throw new ArgumentException(
                    "File chua co sheet 'Bang SDD' do QHSDDEXPORT tao.");
                string relId = (string)sheet.Attribute(bookRel + "id");
                var rel = rels.Descendants().FirstOrDefault(r => (string)r.Attribute("Id") == relId);
                if (rel == null) throw new ArgumentException("Loi lien ket worksheet trong XLSX.");
                string target = ((string)rel.Attribute("Target") ?? "").Replace('\\', '/');
                string worksheet = target.StartsWith("/", StringComparison.Ordinal)
                    ? target.TrimStart('/') : "xl/" + target;
                var cellsDoc = Load(zip, worksheet);
                var strings = new List<string>();
                var shared = zip.GetEntry("xl/sharedStrings.xml");
                if (shared != null)
                {
                    using (var reader = shared.Open())
                    {
                        var stringsDoc = XDocument.Load(reader);
                        strings = stringsDoc.Descendants(Ns + "si")
                            .Select(si => string.Concat(si.Descendants(Ns + "t").Select(t => t.Value)))
                            .ToList();
                    }
                }
                var rows = cellsDoc.Descendants(Ns + "sheetData").Elements(Ns + "row").ToList();
                if (rows.Count < 2) throw new ArgumentException("Bang SDD chua co du lieu.");
                // Old V2.0: header is row 1; XLS template layout: header is row 2.
                // Recognize both to avoid breaking previously exported workbooks.
                var headerRow = rows.FirstOrDefault(r => string.Equals(
                    Get(Fields(r, strings), "J"), "CAD_HANDLE",
                    StringComparison.OrdinalIgnoreCase));
                if (headerRow == null)
                    throw new ArgumentException("Cot J CAD_HANDLE da bi xoa/doi ten. Khong nhap de tranh gan nham o dat.");
                int headerLine = (int?)headerRow.Attribute("r") ?? 0;
                foreach (var row in rows.Where(r => ((int?)r.Attribute("r") ?? 0) > headerLine))
                {
                    var values = Fields(row, strings);
                    // V2.0 exports nested lot rows for reporting. Indicators
                    // belong to the parent block, not to each child lot.
                    if (string.Equals(Get(values, "K"), "LOT", StringComparison.OrdinalIgnoreCase))
                        continue;
                    string handle = Get(values, "J");
                    if (string.IsNullOrWhiteSpace(handle)) continue; // TOTAL / notes
                    int line = (int?)row.Attribute("r") ?? 0;
                    result.Add(new LandImportRow {
                        ExcelRow = line, Code = Get(values, "B"),
                        Area = Get(values, "D"), Handle = handle,
                        Density = Get(values, "G"), Floors = Get(values, "H"),
                        Far = Get(values, "I")
                    });
                }
            }
            if (result.Count == 0) throw new ArgumentException("Bang SDD khong co ma CAD_HANDLE hop le.");
            if (result.Select(r => r.Handle).Distinct(StringComparer.OrdinalIgnoreCase).Count() != result.Count)
                throw new ArgumentException("CAD_HANDLE trung lap trong Excel. Khong nhap.");
            return result;
        }

        private static XDocument Load(ZipArchive zip, string name)
        {
            var entry = zip.GetEntry(name);
            if (entry == null) throw new ArgumentException("XLSX thieu thanh phan " + name);
            if (entry.Length > 25 * 1024 * 1024)
                throw new ArgumentException("Worksheet qua lon de nhap an toan.");
            using (var input = entry.Open()) return XDocument.Load(input);
        }

        private static Dictionary<string, string> Fields(XElement row, IList<string> shared)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var cell in row.Elements(Ns + "c"))
            {
                string addr = (string)cell.Attribute("r") ?? "";
                string col = new string(addr.TakeWhile(char.IsLetter).ToArray()).ToUpperInvariant();
                string type = (string)cell.Attribute("t") ?? "";
                string value;
                if (type == "inlineStr")
                    value = string.Concat(cell.Descendants(Ns + "t").Select(x => x.Value));
                else
                {
                    value = (string)cell.Element(Ns + "v") ?? "";
                    int index;
                    if (type == "s" && int.TryParse(value, NumberStyles.Integer,
                        CultureInfo.InvariantCulture, out index) && index >= 0 && index < shared.Count)
                        value = shared[index];
                }
                if (col.Length > 0) dict[col] = value.Trim();
            }
            return dict;
        }

        private static string Get(IDictionary<string, string> values, string key)
        {
            string result;
            return values.TryGetValue(key, out result) ? result : "";
        }
    }
}
