using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CadPolyline = Autodesk.AutoCAD.DatabaseServices.Polyline;

namespace QHPlanningRoads
{
    public sealed partial class Commands
    {
        // QHTENLO accepts BOTH land-block sdd and lot sdd2 (including a
        // simple-use block displayed using sdd2). Each click increments.
        [CommandMethod("QHTENLO")]
        public void RenameLotVietnamese()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            var prefixPrompt = new PromptStringOptions(
                "\nNhap tien to ten lo, vi du CN.1. : ") { AllowSpaces = false };
            var prefixAnswer = ed.GetString(prefixPrompt);
            if (prefixAnswer.Status != PromptStatus.OK) return;
            string prefix = (prefixAnswer.StringResult ?? "").Trim().ToUpperInvariant();
            if (prefix.Length == 0 || prefix.Length > 45
                || prefix.Any(c => !(c >= 'A' && c <= 'Z')
                    && !(c >= '0' && c <= '9') && c != '_' && c != '-' && c != '.'))
            {
                ed.WriteMessage("\nTien to phai la A-Z, so, _, -, . (khong dau).");
                return;
            }
            var numberOptions = new PromptIntegerOptions("\nSo thu tu bat dau <1>: ") {
                DefaultValue = 1, UseDefaultValue = true
            };
            var numberAnswer = ed.GetInteger(numberOptions);
            if (numberAnswer.Status != PromptStatus.OK) return;
            int next = numberAnswer.Value;
            if (next < 1) { ed.WriteMessage("\nSo bat dau phai >= 1."); return; }
            int processed = 0;
            ed.WriteMessage("\nClick lien tuc BLOCK NHAN O DAT (sdd) hoac LO (sdd2). Enter de ket thuc.");
            while (true)
            {
                var pick = new PromptEntityOptions(
                    "\nClick block nhan o/lo tiep theo <Enter=Ket thuc>: ") {
                        AllowNone = true
                    };
                pick.SetRejectMessage("\nChi chon BLOCK ky hieu dat sdd/sdd2.");
                pick.AddAllowedClass(typeof(BlockReference), true);
                var selected = ed.GetEntity(pick);
                if (selected.Status == PromptStatus.None || selected.Status == PromptStatus.Cancel)
                    break;
                if (selected.Status != PromptStatus.OK) break;
                try
                {
                    string newName;
                    using (var tr = doc.Database.TransactionManager.StartTransaction())
                    {
                        var label = (BlockReference)tr.GetObject(selected.ObjectId, OpenMode.ForRead);
                        string previousCode = LandLabelBlocks.LinkedCode(label);
                        if (string.IsNullOrWhiteSpace(previousCode))
                            throw new ArgumentException("Block khong co lien ket voi lo dat.");
                        CadPolyline polygon = null;
                        string polygonKind = "";
                        var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                        foreach (string layer in new[] { LandStore.LotLayer, LandStore.BlockLayer,
                            LandStore.RemainderLayer, LandStore.AccessRoadLayer })
                            foreach (var poly in LandStore.Polylines(doc.Database, tr, layer))
                            {
                                var meta = LandStore.Read(poly);
                                if (meta == null) continue;
                                if (!string.IsNullOrWhiteSpace(meta.Code)) used.Add(meta.Code);
                                if ((layer == LandStore.LotLayer || layer == LandStore.BlockLayer)
                                    && meta.Code == previousCode)
                                {
                                    polygon = poly;
                                    polygonKind = meta.Kind;
                                }
                            }
                        if (polygon == null || (polygonKind != "LOT" && polygonKind != "BLOCK"))
                            throw new ArgumentException("Nhan chon khong lien ket o/lo dat do plugin quan ly.");
                        var existingMeta = LandStore.Read(polygon);
                        // When rerunning the command, consume only unused
                        // numbers; never overwrite a different lot's code.
                        while (used.Contains(prefix + next))
                        {
                            if (next >= 99999999)
                                throw new ArgumentException("Het so thu tu hop le.");
                            next++;
                        }
                        newName = prefix + next;
                        if (newName.Length > 50)
                            throw new ArgumentException("Ma lo qua 50 ky tu.");
                        string oldCode = existingMeta.Code;
                        polygon.UpgradeOpen();
                        existingMeta.Code = newName;
                        LandStore.Save(doc.Database, tr, polygon, existingMeta);
                        // Renaming a parent block must update child ParentCode,
                        // otherwise QHLOT/QHAUDIT no longer find its holes/lots.
                        if (polygonKind == "BLOCK")
                            foreach (string layer in new[] { LandStore.HoleLayer,
                                LandStore.LotLayer, LandStore.RemainderLayer, LandStore.AccessRoadLayer })
                                foreach (var child in LandStore.Polylines(doc.Database, tr, layer))
                                {
                                    var childMeta = LandStore.Read(child);
                                    if (childMeta == null || childMeta.ParentCode != oldCode) continue;
                                    childMeta.ParentCode = newName;
                                    child.UpgradeOpen();
                                    LandStore.Save(doc.Database, tr, child, childMeta);
                                }
                        LandLabelBlocks.RenameExistingLabel(doc.Database, tr, label, newName);
                        tr.Commit();
                    }
                    next++;
                    processed++;
                    ed.WriteMessage("\nDa dat ten: " + newName + ". Click o/lo tiep theo...");
                }
                catch (System.Exception ex) { Report(ed, ex); }
            }
            ed.WriteMessage("\nQHTENLO hoan thanh " + processed
                + " o/lo. QHEXPORT su dung cac ma moi.");
        }

        [CommandMethod("QHLOTNAME")]
        public void RenameLotAlias() { RenameLotVietnamese(); }
    }
}
