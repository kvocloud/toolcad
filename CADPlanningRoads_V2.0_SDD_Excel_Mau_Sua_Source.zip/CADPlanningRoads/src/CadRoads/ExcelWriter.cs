using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace QHPlanningRoads
{
    // Minimal XLSX writer: typed numeric cells, UTF-8 labels, no Excel/COM install.
    // This keeps the AutoCAD 2020 net47 plugin free of another NuGet dependency.
    internal static class ExcelWriter
    {
        // Spreadsheet formulas are stored as OOXML <f> with a numerical cache.
        // Excel recalculates on open, including after the user edits CAD values.
        internal sealed class FormulaCell
        {
            public readonly string Expression;
            public readonly double CachedValue;
            public FormulaCell(string expression, double cachedValue)
            {
                Expression = (expression ?? "").TrimStart('=');
                CachedValue = cachedValue;
            }
        }

        private sealed class Sheet
        {
            public string Name;
            public IList<object[]> Rows;
        }

        public static void Write(string file, IList<object[]> lotRows, IList<object[]> zoneRows,
            IList<object[]> roadRows = null)
        {
            var sheets = new List<Sheet> {
                new Sheet { Name = "Danh sach lo", Rows = lotRows },
                new Sheet { Name = "Tong hop chuc nang", Rows = zoneRows }
            };
            if (roadRows != null && roadRows.Count > 0)
                sheets.Add(new Sheet { Name = "Tuyen va mat cat", Rows = roadRows });
            WriteSheets(file, sheets);
        }

        public static void WriteLandUse(string file, IList<object[]> detail,
            IList<object[]> summary)
        {
            WriteSheets(file, new List<Sheet> {
                new Sheet { Name = "Bang SDD", Rows = detail },
                new Sheet { Name = "Tong hop SDD", Rows = summary }
            });
        }

        private static void WriteSheets(string file, IList<Sheet> sheets)
        {
            var folder = Path.GetDirectoryName(Path.GetFullPath(file));
            if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
            using (var stream = new FileStream(file, FileMode.Create, FileAccess.Write, FileShare.None))
            using (var archive = new ZipArchive(stream, ZipArchiveMode.Create))
            {
                const string packageRel = "http://schemas.openxmlformats.org/package/2006/relationships";
                const string main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
                const string relDocument = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
                const string ct = "http://schemas.openxmlformats.org/package/2006/content-types";

                var contentTypes = new XElement(XName.Get("Types", ct),
                    new XElement(XName.Get("Default", ct), new XAttribute("Extension", "rels"),
                        new XAttribute("ContentType", "application/vnd.openxmlformats-package.relationships+xml")),
                    new XElement(XName.Get("Default", ct), new XAttribute("Extension", "xml"),
                        new XAttribute("ContentType", "application/xml")),
                    new XElement(XName.Get("Override", ct), new XAttribute("PartName", "/xl/workbook.xml"),
                        new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml")),
                    new XElement(XName.Get("Override", ct), new XAttribute("PartName", "/xl/styles.xml"),
                        new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml")));
                for (int i = 0; i < sheets.Count; i++)
                    contentTypes.Add(new XElement(XName.Get("Override", ct),
                        new XAttribute("PartName", "/xl/worksheets/sheet" + (i + 1) + ".xml"),
                        new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")));
                WritePart(archive, "[Content_Types].xml", new XDocument(contentTypes));

                WritePart(archive, "_rels/.rels", new XDocument(new XElement(XName.Get("Relationships", packageRel),
                    new XElement(XName.Get("Relationship", packageRel), new XAttribute("Id", "rId1"),
                        new XAttribute("Type", relDocument + "/officeDocument"),
                        new XAttribute("Target", "xl/workbook.xml")))));

                var workbook = new XElement(XName.Get("workbook", main),
                    new XAttribute(XNamespace.Xmlns + "r", relDocument),
                    new XElement(XName.Get("sheets", main)));
                var rels = new XElement(XName.Get("Relationships", packageRel));
                for (int i = 0; i < sheets.Count; i++)
                {
                    ((XElement)workbook.FirstNode).Add(new XElement(XName.Get("sheet", main),
                        new XAttribute("name", sheets[i].Name), new XAttribute("sheetId", i + 1),
                        new XAttribute(XName.Get("id", relDocument), "rId" + (i + 1))));
                    rels.Add(new XElement(XName.Get("Relationship", packageRel),
                        new XAttribute("Id", "rId" + (i + 1)),
                        new XAttribute("Type", relDocument + "/worksheet"),
                        new XAttribute("Target", "worksheets/sheet" + (i + 1) + ".xml")));
                    WritePart(archive, "xl/worksheets/sheet" + (i + 1) + ".xml",
                        Worksheet(sheets[i].Rows, main, sheets[i].Name));
                }
                workbook.Add(new XElement(XName.Get("calcPr", main),
                    new XAttribute("calcId", 0), new XAttribute("calcMode", "auto"),
                    new XAttribute("fullCalcOnLoad", 1), new XAttribute("forceFullCalc", 1)));
                rels.Add(new XElement(XName.Get("Relationship", packageRel),
                    new XAttribute("Id", "rId" + (sheets.Count + 1)),
                    new XAttribute("Type", relDocument + "/styles"),
                    new XAttribute("Target", "styles.xml")));
                WritePart(archive, "xl/workbook.xml", new XDocument(workbook));
                WritePart(archive, "xl/_rels/workbook.xml.rels", new XDocument(rels));
                WritePart(archive, "xl/styles.xml", Styles(main));
            }
        }

        private static XDocument Worksheet(IList<object[]> rows, string ns, string name)
        {
            XNamespace main = ns;
            bool landTable = name == "Bang SDD" || name == "Tong hop SDD";
            var sheetData = new XElement(main + "sheetData");
            for (int r = 0; r < rows.Count; r++)
            {
                var row = new XElement(main + "row", new XAttribute("r", r + 1),
                    new XAttribute("ht", landTable && r == 0 ? 38
                        : landTable && (r == 1 || r == 2) ? 39 : r == 0 ? 32 : 22),
                    new XAttribute("customHeight", "1"));
                for (int col = 0; col < rows[r].Length; col++)
                {
                    var value = rows[r][col];
                    if (value == null) continue;
                    var cell = new XElement(main + "c",
                        new XAttribute("r", Column(col) + (r + 1)));
                    if (landTable)
                    {
                        int style = r == 0 ? 3 : r == 1 || r == 2 ? 4
                            : r == 3 ? 5 : 0;
                        if (r >= 4 && name == "Bang SDD" && rows[r].Length > 10
                            && string.Equals(rows[r][10] as string, "BLOCK",
                                StringComparison.OrdinalIgnoreCase)) style = 6;
                        if (r >= 4 && rows[r].Length > 1
                            && (rows[r][1] as string ?? "").StartsWith("TỔNG",
                                StringComparison.OrdinalIgnoreCase)) style = 5;
                        if (style != 0) cell.Add(new XAttribute("s", style));
                    }
                    else if (r == 0) cell.Add(new XAttribute("s", 1));
                    if (value is FormulaCell)
                    {
                        var formula = (FormulaCell)value;
                        if (cell.Attribute("s") == null) cell.Add(new XAttribute("s", 2));
                        cell.Add(new XElement(main + "f", formula.Expression));
                        cell.Add(new XElement(main + "v",
                            formula.CachedValue.ToString("R", CultureInfo.InvariantCulture)));
                    }
                    else if (value is int || value is long || value is double || value is float || value is decimal)
                    {
                        if (r > 0 && cell.Attribute("s") == null)
                            cell.Add(new XAttribute("s", 2));
                        cell.Add(new XElement(main + "v",
                            Convert.ToString(value, CultureInfo.InvariantCulture)));
                    }
                    else
                    {
                        cell.Add(new XAttribute("t", "inlineStr"));
                        cell.Add(new XElement(main + "is",
                            new XElement(main + "t", value.ToString())));
                    }
                    row.Add(cell);
                }
                sheetData.Add(row);
            }
            var widths = landTable
                ? new[] { 10d, 24, 49, 22, 20, 17, 19, 20, 22, 21 }
                : new[] { 17d, 20, 20, 25, 18, 20, 18, 18, 20, 20 };
            var cols = new XElement(main + "cols");
            int ncols = rows.Count > 0 ? rows.Max(x => x.Length) : 0;
            for (int c = 0; c < ncols; c++)
            {
                var column = new XElement(main + "col", new XAttribute("min", c+1),
                    new XAttribute("max", c+1), new XAttribute("width", widths[Math.Min(c, widths.Length-1)]),
                    new XAttribute("customWidth", "1"));
                if (landTable && c >= 9)
                    column.Add(new XAttribute("hidden", "1")); // sync keys + row kind + use-code
                cols.Add(column);
            }
            var views = new XElement(main + "sheetViews",
                new XElement(main + "sheetView", new XAttribute("workbookViewId", 0),
                    new XElement(main + "pane", new XAttribute("ySplit", landTable ? 4 : 1),
                        new XAttribute("topLeftCell", landTable ? "A5" : "A2"),
                        new XAttribute("activePane", "bottomLeft"),
                        new XAttribute("state", "frozen"))));
            var worksheet = new XElement(main + "worksheet", views, cols, sheetData);
            if (landTable)
            {
                var merges = new[] { "A1:I1", "A2:A3", "B2:B3", "C2:C3",
                    "D2:F2", "G2:G3", "H2:H3", "I2:I3", "A4:C4" };
                worksheet.Add(new XElement(main + "mergeCells",
                    new XAttribute("count", merges.Length),
                    merges.Select(m => new XElement(main + "mergeCell", new XAttribute("ref", m)))));
            }
            return new XDocument(worksheet);
        }

        private static XDocument Styles(string ns)
        {
            XNamespace main = ns;
            return new XDocument(new XElement(main + "styleSheet",
                new XElement(main + "fonts", new XAttribute("count", 4),
                    new XElement(main + "font", new XElement(main + "sz", new XAttribute("val", 10)),
                        new XElement(main + "name", new XAttribute("val", "Arial"))),
                    new XElement(main + "font", new XElement(main + "b"),
                        new XElement(main + "color", new XAttribute("rgb", "FFFFFFFF")),
                        new XElement(main + "sz", new XAttribute("val", 10)),
                        new XElement(main + "name", new XAttribute("val", "Arial"))),
                    new XElement(main + "font", new XElement(main + "b"),
                        new XElement(main + "color", new XAttribute("rgb", "FFFFFFFF")),
                        new XElement(main + "sz", new XAttribute("val", 15)),
                        new XElement(main + "name", new XAttribute("val", "Arial"))),
                    new XElement(main + "font", new XElement(main + "b"),
                        new XElement(main + "color", new XAttribute("rgb", "FF19375D")),
                        new XElement(main + "sz", new XAttribute("val", 10)),
                        new XElement(main + "name", new XAttribute("val", "Arial")))),
                new XElement(main + "fills", new XAttribute("count", 4),
                    new XElement(main + "fill", new XElement(main + "patternFill", new XAttribute("patternType", "none"))),
                    new XElement(main + "fill", new XElement(main + "patternFill", new XAttribute("patternType", "gray125"))),
                    new XElement(main + "fill", new XElement(main + "patternFill", new XAttribute("patternType", "solid"),
                        new XElement(main + "fgColor", new XAttribute("rgb", "FF203963")),
                        new XElement(main + "bgColor", new XAttribute("indexed", 64)))),
                    new XElement(main + "fill", new XElement(main + "patternFill", new XAttribute("patternType", "solid"),
                        new XElement(main + "fgColor", new XAttribute("rgb", "FFDDEBF7")),
                        new XElement(main + "bgColor", new XAttribute("indexed", 64))))),
                new XElement(main + "borders", new XAttribute("count", 1),
                    new XElement(main + "border", new XElement(main + "left"), new XElement(main + "right"),
                        new XElement(main + "top"), new XElement(main + "bottom"), new XElement(main + "diagonal"))),
                new XElement(main + "cellStyleXfs", new XAttribute("count", 1),
                    new XElement(main + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 0),
                        new XAttribute("fillId", 0), new XAttribute("borderId", 0))),
                new XElement(main + "cellXfs", new XAttribute("count", 7),
                    new XElement(main + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 0),
                        new XAttribute("fillId", 0), new XAttribute("borderId", 0), new XAttribute("xfId", 0)),
                    new XElement(main + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 1),
                        new XAttribute("fillId", 2), new XAttribute("borderId", 0), new XAttribute("xfId", 0),
                        new XAttribute("applyFill", 1), new XAttribute("applyFont", 1),
                        new XElement(main + "alignment", new XAttribute("horizontal", "center"),
                            new XAttribute("vertical", "center"), new XAttribute("wrapText", 1))),
                    new XElement(main + "xf", new XAttribute("numFmtId", 4), new XAttribute("fontId", 0),
                        new XAttribute("fillId", 0), new XAttribute("borderId", 0),
                        new XAttribute("xfId", 0), new XAttribute("applyNumberFormat", 1)),
                    new XElement(main + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 2),
                        new XAttribute("fillId", 2), new XAttribute("borderId", 0), new XAttribute("xfId", 0),
                        new XAttribute("applyFill", 1), new XAttribute("applyFont", 1),
                        new XElement(main + "alignment", new XAttribute("horizontal", "center"),
                            new XAttribute("vertical", "center"))),
                    new XElement(main + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 1),
                        new XAttribute("fillId", 2), new XAttribute("borderId", 0), new XAttribute("xfId", 0),
                        new XAttribute("applyFill", 1), new XAttribute("applyFont", 1),
                        new XElement(main + "alignment", new XAttribute("horizontal", "center"),
                            new XAttribute("vertical", "center"), new XAttribute("wrapText", 1))),
                    new XElement(main + "xf", new XAttribute("numFmtId", 4), new XAttribute("fontId", 3),
                        new XAttribute("fillId", 3), new XAttribute("borderId", 0), new XAttribute("xfId", 0),
                        new XAttribute("applyFill", 1), new XAttribute("applyFont", 1),
                        new XAttribute("applyNumberFormat", 1)),
                    new XElement(main + "xf", new XAttribute("numFmtId", 4), new XAttribute("fontId", 3),
                        new XAttribute("fillId", 0), new XAttribute("borderId", 0), new XAttribute("xfId", 0),
                        new XAttribute("applyFont", 1), new XAttribute("applyNumberFormat", 1)))));
        }

        private static string Column(int i)
        {
            string result = "";
            for (i++; i > 0; i = (i - 1) / 26)
                result = (char)('A' + (i - 1) % 26) + result;
            return result;
        }

        private static void WritePart(ZipArchive archive, string name, XDocument xml)
        {
            var entry = archive.CreateEntry(name, CompressionLevel.Optimal);
            using (var output = new StreamWriter(entry.Open(), new UTF8Encoding(false)))
                xml.Save(output);
        }
    }
}
