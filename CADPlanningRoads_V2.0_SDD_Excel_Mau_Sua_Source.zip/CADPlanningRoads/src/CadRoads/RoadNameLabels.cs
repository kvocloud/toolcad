using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using NetTopologySuite.Geometries;

namespace QHPlanningRoads
{
    // One editable centerline and one managed text annotation per registered road.
    // Text can always be regenerated from RoadProfile.RoadName (XData).
    internal static class RoadNameLabels
    {
        internal const string Layer = "QH_TEN_TUYEN_DUONG";

        internal static void Refresh(Database db, double tolerance)
        {
            using (var tr = db.TransactionManager.StartTransaction())
            {
                Rebuild(db, tr, tolerance);
                tr.Commit();
            }
        }

        internal static void Rebuild(Database db, Transaction tr, double tolerance)
        {
            var layers = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            if (!layers.Has(Layer))
            {
                layers.UpgradeOpen();
                var layer = new LayerTableRecord {
                    Name = Layer, Color = Color.FromColorIndex(ColorMethod.ByAci, 2)
                };
                layers.Add(layer); tr.AddNewlyCreatedDBObject(layer, true);
            }
            var ms = CadBridge.GetModelSpace(db, tr);
            // The planning geometry stores sharp vertices for correct curb
            // offsets. Place annotations on the REAL rendered PLINE,
            // including the native AutoCAD bulge arc at an L turn.
            var plotted = new Dictionary<string, List<Coordinate>>(
                StringComparer.OrdinalIgnoreCase);
            foreach (ObjectId id in ms)
            {
                var p = tr.GetObject(id, OpenMode.ForRead) as Polyline;
                if (p == null || p.Closed || CadBridge.ReadProfile(p) == null) continue;
                plotted[p.Handle.ToString()] = CadBridge.ToCoordinates(p, tolerance);
            }
            var registered = CadBridge.RegisteredRoads(db, tr, tolerance);
            // Clear only AFTER reading source roads, since erased model-space
            // entities can remain in BTR enumerations until transaction commit.
            LandStore.ClearManaged(db, tr, Layer);
            foreach (var road in registered)
            {
                string name = road.Profile.RoadName;
                List<Coordinate> points;
                if (string.IsNullOrWhiteSpace(name)
                    || !plotted.TryGetValue(road.Handle, out points) || points.Count < 2)
                    continue;
                double total = 0;
                for (int i = 0; i < points.Count - 1; i++)
                    total += points[i].Distance(points[i + 1]);
                if (total < 0.01) continue;
                double left = total / 2;
                for (int i = 0; i < points.Count - 1; i++)
                {
                    Coordinate a = points[i], b = points[i + 1];
                    double length = a.Distance(b);
                    if (length < 0.001) continue;
                    if (left > length && i < points.Count - 2) { left -= length; continue; }
                    double t = Math.Min(1, Math.Max(0, left / length));
                    double angle = Math.Atan2(b.Y - a.Y, b.X - a.X);
                    if (angle > Math.PI / 2 || angle < -Math.PI / 2) angle += Math.PI;
                    const double height = 1.35;
                    double cx = a.X + (b.X - a.X) * t;
                    double cy = a.Y + (b.Y - a.Y) * t;
                    // Keep text centered horizontally without using a non-applicable
                    // DBText.AlignmentPoint setter in older AutoCAD versions.
                    double startX = cx - Math.Cos(angle) * name.Length * height * 0.29;
                    double startY = cy - Math.Sin(angle) * name.Length * height * 0.29;
                    var text = new DBText {
                        Layer = Layer, Position = new Point3d(startX,startY,0),
                        Rotation = angle, Height = height, TextString = name
                    };
                    ms.UpgradeOpen();
                    ms.AppendEntity(text); tr.AddNewlyCreatedDBObject(text, true);
                    break;
                }
            }
        }
    }
}
