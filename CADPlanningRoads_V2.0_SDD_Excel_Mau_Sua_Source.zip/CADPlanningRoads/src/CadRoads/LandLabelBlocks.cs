using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;

namespace QHPlanningRoads
{
    // CAD-09 V2: true ATTRIB/ATTDEF symbols. EATTEDIT changes are read by
    // QHEXPORT. The invisible LINK_CODE binds the symbol to its land polygon.
    internal static class LandLabelBlocks
    {
        // Exact names from the user's replacement DXF, now INSUNITS=6 (metres).
        private const string BuildName = "sdd";
        private const string SimpleName = "sdd2";
        private const string LegacyBuildName = "QH_SYMBOL_BUILD_V2";
        private const string LegacySimpleName = "QH_SYMBOL_SIMPLE_V2";
        private const string LinkApp = "QH_LABEL_LINK";
        private const string ResourceName = "QHPlanningRoads.TemplateBlocks.dxf";
        // Original metric block circle diameter. At default, INSERT scale=1.
        internal static double BlockSymbolDiameterMeters = 71.52708859851714;
        internal static double LotSymbolDiameterMeters = 35.76354429925857;
        private const double NativeDiameterMeters = 71.52708859851714;

        public static bool SimpleUse(string use)
        {
            string s = (use ?? "").ToUpperInvariant();
            return s == "CX" || s.StartsWith("CX.") || s == "CXCV" || s == "CAYXANH" || s == "PARK"
                || s == "MN" || s.StartsWith("MN.") || s == "MATNUOC" || s == "WATER" || s == "HO";
        }

        // Import the ACTUAL user-supplied sdd/sdd2/VT block definitions from
        // an embedded DXF resource. This is done BEFORE opening the QHLABEL
        // transaction because WblockCloneObjects owns its own DB mutation.
        public static void EnsureDefinitions(Database db)
        {
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                if (bt.Has(BuildName) && bt.Has(SimpleName) && bt.Has("VT")
                    && bt.Has(RoadSections.CutLeftName) && bt.Has(RoadSections.CutRightName)) return;
            }
            string dxfPath = Path.Combine(Path.GetTempPath(),
                "qh_blocks_" + Guid.NewGuid().ToString("N") + ".dxf");
            string logPath = Path.ChangeExtension(dxfPath, ".log");
            try
            {
                using (var source = Assembly.GetExecutingAssembly().GetManifestResourceStream(ResourceName))
                {
                    if (source == null) throw new InvalidOperationException(
                        "Thiếu resource block.dxf trong DLL. Hãy build lại toàn bộ source mới.");
                    using (var output = File.Create(dxfPath)) source.CopyTo(output);
                }
                using (var template = new Database(false, true))
                {
                    template.DxfIn(dxfPath, logPath);
                    var ids = new ObjectIdCollection();
                    using (var tr = template.TransactionManager.StartTransaction())
                    {
                        var src = (BlockTable)tr.GetObject(template.BlockTableId, OpenMode.ForRead);
                        foreach (string name in new[] { "VT", BuildName, SimpleName,
                            RoadSections.CutLeftName, RoadSections.CutRightName })
                            if (src.Has(name)) ids.Add(src[name]);
                    }
                    if (ids.Count != 5)
                        throw new InvalidOperationException(
                            "block.dxf phai co VT, sdd, sdd2 va 2 block net cat tu mau *U24.");
                    db.WblockCloneObjects(ids, db.BlockTableId, new IdMapping(),
                        DuplicateRecordCloning.Ignore, false);
                }
            }
            finally
            {
                try { if (File.Exists(dxfPath)) File.Delete(dxfPath); } catch { }
                try { if (File.Exists(logPath)) File.Delete(logPath); } catch { }
            }
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                if (!bt.Has(BuildName) || !bt.Has(SimpleName) || !bt.Has("VT")
                    || !bt.Has(RoadSections.CutLeftName) || !bt.Has(RoadSections.CutRightName))
                    throw new InvalidOperationException("Khong import du sdd/sdd2/VT/netcat tu DXF met.");
            }
        }

        private static void Create(Database db, Transaction tr, BlockTable table,
            string name, bool simple)
        {
            table.UpgradeOpen();
            var def = new BlockTableRecord { Name = name, Origin = Point3d.Origin };
            table.Add(def); tr.AddNewlyCreatedDBObject(def, true);
            double radius = simple ? 5.1 : 6.8;
            AddShape(tr, def, new Circle(Point3d.Origin, Vector3d.ZAxis, radius));
            if (simple)
            {
                AddShape(tr, def, new Line(new Point3d(-5, 0, 0), new Point3d(5, 0, 0)));
                AddAttribute(tr, def, "LOT_CODE", new Point3d(0, 2.1, 0), 1.55, false);
                AddAttribute(tr, def, "AREA_M2", new Point3d(0, -2.0, 0), 1.2, false);
            }
            else
            {
                AddShape(tr, def, new Line(new Point3d(-6.4, 2.0, 0), new Point3d(6.4, 2.0, 0)));
                AddShape(tr, def, new Line(new Point3d(-6.6, -0.8, 0), new Point3d(6.6, -0.8, 0)));
                AddShape(tr, def, new Line(new Point3d(-5.8, -3.4, 0), new Point3d(5.8, -3.4, 0)));
                AddShape(tr, def, new Line(new Point3d(0, 2.0, 0), new Point3d(0, -0.8, 0)));
                AddAttribute(tr, def, "LOT_CODE", new Point3d(0, 4.2, 0), 1.55, false);
                AddAttribute(tr, def, "DENSITY", new Point3d(-3, 0.55, 0), 1.4, false);
                AddAttribute(tr, def, "FLOORS", new Point3d(3, 0.55, 0), 1.4, false);
                AddAttribute(tr, def, "AREA_M2", new Point3d(0, -2.1, 0), 1.2, false);
                AddAttribute(tr, def, "FAR", new Point3d(0, -4.9, 0), 1.5, false);
            }
            AddAttribute(tr, def, "LINK_CODE", new Point3d(0, 0, 0), 0.1, true);
        }

        private static void AddShape(Transaction tr, BlockTableRecord def, Entity shape)
        {
            def.AppendEntity(shape);
            tr.AddNewlyCreatedDBObject(shape, true);
        }

        private static void AddAttribute(Transaction tr, BlockTableRecord def, string tag,
            Point3d position, double height, bool hidden)
        {
            var ad = new AttributeDefinition {
                Tag = tag, Prompt = tag, TextString = "-", Position = position,
                Height = height, Justify = AttachmentPoint.MiddleCenter,
                Invisible = hidden,
                LockPositionInBlock = true
            };
            // Set justification FIRST. AlignmentPoint is not applicable for
            // default BaseLeft and caused eNotApplicable in earlier versions.
            ad.AlignmentPoint = position;
            AddShape(tr, def, ad);
        }

        public static Dictionary<string, Dictionary<string, string>> ReadAll(Database db, Transaction tr)
        {
            var result = new Dictionary<string, Dictionary<string, string>>(
                StringComparer.OrdinalIgnoreCase);
            foreach (ObjectId id in CadBridge.GetModelSpace(db, tr))
            {
                if (id.IsErased) continue;
                var block = tr.GetObject(id, OpenMode.ForRead) as BlockReference;
                if (block == null || block.Layer != LandStore.LabelLayer) continue;
                var record = (BlockTableRecord)tr.GetObject(block.BlockTableRecord, OpenMode.ForRead);
                if (record.Name != BuildName && record.Name != SimpleName
                    && record.Name != "QH_SDD_METRIC_V16"
                    && record.Name != "QH_SDD2_METRIC_V16"
                    && record.Name != LegacyBuildName && record.Name != LegacySimpleName) continue;
                var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (ObjectId attId in block.AttributeCollection)
                {
                    var att = tr.GetObject(attId, OpenMode.ForRead) as AttributeReference;
                    if (att != null) values[CanonicalTag(record.Name, att.Tag)] = att.TextString;
                }
                string link;
                if (!values.TryGetValue("LINK_CODE", out link) || string.IsNullOrWhiteSpace(link))
                    link = ReadLink(block);
                if (!string.IsNullOrWhiteSpace(link))
                    result[link] = values;
            }
            return result;
        }

        public static void ClearForCodes(Database db, Transaction tr, ISet<string> codes)
        {
            foreach (ObjectId id in CadBridge.GetModelSpace(db, tr))
            {
                if (id.IsErased) continue;
                var block = tr.GetObject(id, OpenMode.ForRead) as BlockReference;
                if (block == null || block.IsErased || block.Layer != LandStore.LabelLayer) continue;
                string link = ReadLink(block);
                if (string.IsNullOrWhiteSpace(link))
                {
                    foreach (ObjectId attributeId in block.AttributeCollection)
                    {
                        var a = tr.GetObject(attributeId, OpenMode.ForRead) as AttributeReference;
                        if (a != null && a.Tag == "LINK_CODE") { link = a.TextString; break; }
                    }
                }
                if (string.IsNullOrWhiteSpace(link) || !codes.Contains(link)) continue;
                block.UpgradeOpen(); block.Erase();
            }
        }

        internal static Dictionary<string, double> ReadExistingDiameters(Database db, Transaction tr)
        {
            var result = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            foreach (ObjectId id in CadBridge.GetModelSpace(db, tr))
            {
                if (id.IsErased) continue;
                var br = tr.GetObject(id, OpenMode.ForRead) as BlockReference;
                if (br == null || br.Layer != LandStore.LabelLayer) continue;
                string code = ReadLink(br);
                if (string.IsNullOrWhiteSpace(code))
                    foreach (ObjectId attrId in br.AttributeCollection)
                    {
                        var attr = tr.GetObject(attrId, OpenMode.ForRead) as AttributeReference;
                        if (attr != null && attr.Tag == "LINK_CODE")
                        { code = attr.TextString; break; }
                    }
                if (string.IsNullOrWhiteSpace(code)) continue;
                var def = (BlockTableRecord)tr.GetObject(br.BlockTableRecord, OpenMode.ForRead);
                double native = def.Name == BuildName || def.Name == SimpleName
                    ? NativeDiameterMeters
                    : def.Name == "QH_SDD_METRIC_V16" || def.Name == "QH_SDD2_METRIC_V16"
                        ? 8.0 : def.Name == LegacyBuildName ? 13.6
                        : def.Name == LegacySimpleName ? 10.2 : 0;
                if (native > 0) result[code] = Math.Abs(br.ScaleFactors.X) * native;
            }
            return result;
        }

        public static void Insert(Database db, Transaction tr, LandMetadata meta,
            Point3d center, double area, Dictionary<string, string> old,
            double? existingDiameterMeters = null)
        {
            var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
            // Lots always use the two-field sdd2 (lot name + area).
            // Blocks use the five-field sdd, except non-building uses.
            bool simple = meta.Kind == "LOT" || SimpleUse(meta.UseCode)
                || meta.Kind == "ROAD" || meta.Kind == "REMAINDER";
            string name = simple ? SimpleName : BuildName;
            var def = (BlockTableRecord)tr.GetObject(bt[name], OpenMode.ForRead);
            var br = new BlockReference(center, bt[name]) {
                Layer = LandStore.LabelLayer,
                // The source file itself is in metres and the native
                // sdd circle diameter is 71.5270886 drawing metres.
                ScaleFactors = new Scale3d((existingDiameterMeters ?? (meta.Kind == "LOT"
                    ? LotSymbolDiameterMeters : BlockSymbolDiameterMeters)) / NativeDiameterMeters)
            };
            var ms = CadBridge.GetModelSpace(db, tr);
            ms.UpgradeOpen(); ms.AppendEntity(br); tr.AddNewlyCreatedDBObject(br, true);
            SaveLink(db, tr, br, meta.Code);
            foreach (ObjectId id in def)
            {
                var ad = tr.GetObject(id, OpenMode.ForRead) as AttributeDefinition;
                if (ad == null || ad.Constant) continue;
                var ar = new AttributeReference();
                try { ar.SetAttributeFromBlock(ad, br.BlockTransform); }
                catch (System.Exception ex)
                {
                    ar.Dispose();
                    throw new InvalidOperationException("Không thể tạo thuộc tính của block "
                        + name + ", tag " + ad.Tag + ": " + ex.Message, ex);
                }
                ar.TextString = ValueFor(CanonicalTag(name, ad.Tag), meta, area, old);
                br.AttributeCollection.AppendAttribute(ar);
                tr.AddNewlyCreatedDBObject(ar, true);
            }
        }

        // Distinguish labels by their linked LAND METADATA rather than by the
        // sdd/sdd2 definition. An MN/CX *BLOCK* also legitimately uses sdd2.
        // Rebuild ATTREF geometry after rescaling; changing ScaleFactors alone
        // does not reliably move all attribute text in older AutoCAD versions.
        internal static int RescaleAll(Database db, Transaction tr,
            double diameterMeters, bool lotsOnly)
        {
            int count = 0;
            var eligible = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var poly in LandStore.Polylines(db, tr,
                lotsOnly ? LandStore.LotLayer : LandStore.BlockLayer))
            {
                var meta = LandStore.Read(poly);
                if (meta != null && meta.Kind == (lotsOnly ? "LOT" : "BLOCK"))
                    eligible.Add(meta.Code);
            }
            foreach (ObjectId id in CadBridge.GetModelSpace(db, tr))
            {
                if (id.IsErased) continue;
                var br = tr.GetObject(id, OpenMode.ForRead) as BlockReference;
                if (br == null || br.Layer != LandStore.LabelLayer) continue;
                string linkedCode = ReadLink(br);
                if (string.IsNullOrWhiteSpace(linkedCode))
                    foreach (ObjectId attId in br.AttributeCollection)
                    {
                        var att = tr.GetObject(attId, OpenMode.ForRead) as AttributeReference;
                        if (att != null && att.Tag == "LINK_CODE")
                        { linkedCode = att.TextString; break; }
                    }
                if (string.IsNullOrWhiteSpace(linkedCode) || !eligible.Contains(linkedCode)) continue;
                var def = (BlockTableRecord)tr.GetObject(br.BlockTableRecord, OpenMode.ForRead);
                double native;
                if (def.Name == BuildName || def.Name == SimpleName)
                    native = NativeDiameterMeters;
                else if (def.Name == "QH_SDD_METRIC_V16"
                    || def.Name == "QH_SDD2_METRIC_V16") native = 8.0;
                else if (def.Name == LegacyBuildName) native = 13.6;
                else if (def.Name == LegacySimpleName) native = 10.2;
                else continue;
                double factor = diameterMeters / native;
                var byTag = new Dictionary<string, AttributeDefinition>(
                    StringComparer.OrdinalIgnoreCase);
                foreach (ObjectId defId in def)
                {
                    var ad = tr.GetObject(defId, OpenMode.ForRead) as AttributeDefinition;
                    if (ad != null) byTag[ad.Tag] = ad;
                }
                br.UpgradeOpen();
                br.ScaleFactors = new Scale3d(factor);
                foreach (ObjectId attId in br.AttributeCollection)
                {
                    var ar = tr.GetObject(attId, OpenMode.ForWrite) as AttributeReference;
                    if (ar == null) continue;
                    AttributeDefinition source;
                    if (!byTag.TryGetValue(ar.Tag, out source)) continue;
                    string text = ar.TextString;
                    ar.SetAttributeFromBlock(source, br.BlockTransform);
                    ar.TextString = text;
                }
                count++;
            }
            return count;
        }

        // Update the existing sdd (block) OR sdd2 (lot/simple block) in place.
        // Keep position, chosen scale, and area; update the metadata link.
        internal static void RenameExistingLabel(
            Database db, Transaction tr, BlockReference label, string name)
        {
            if (label.Layer != LandStore.LabelLayer)
                throw new ArgumentException("Chon block nhan QH_NHAN_DAT.");
            var def = (BlockTableRecord)tr.GetObject(label.BlockTableRecord, OpenMode.ForRead);
            if (def.Name != SimpleName && def.Name != BuildName
                && def.Name != "QH_SDD2_METRIC_V16"
                && def.Name != "QH_SDD_METRIC_V16"
                && def.Name != LegacyBuildName && def.Name != LegacySimpleName)
                throw new ArgumentException("Chon block nhan dat sdd hoac sdd2.");
            bool changed = false;
            foreach (ObjectId attId in label.AttributeCollection)
            {
                var att = tr.GetObject(attId, OpenMode.ForRead) as AttributeReference;
                if (att == null || CanonicalTag(def.Name, att.Tag) != "LOT_CODE") continue;
                att.UpgradeOpen();
                att.TextString = name;
                changed = true;
            }
            if (!changed) throw new ArgumentException("Block nhan thieu thuoc tinh ten o/lo.");
            label.UpgradeOpen();
            SaveLink(db, tr, label, name);
        }

        internal static string LinkedCode(BlockReference label)
        {
            return ReadLink(label);
        }

        // Keep the five-attribute land-use symbol synchronized with polygon
        // XData. Simple sdd2 labels deliberately have only name and area.
        internal static int UpdateIndicators(Database db, Transaction tr,
            string code, LandMetadata meta)
        {
            int changed = 0;
            foreach (ObjectId id in CadBridge.GetModelSpace(db, tr))
            {
                if (id.IsErased) continue;
                var label = tr.GetObject(id, OpenMode.ForRead) as BlockReference;
                if (label == null || label.Layer != LandStore.LabelLayer
                    || !string.Equals(ReadLink(label), code, StringComparison.OrdinalIgnoreCase)) continue;
                var def = (BlockTableRecord)tr.GetObject(label.BlockTableRecord, OpenMode.ForRead);
                foreach (ObjectId aid in label.AttributeCollection)
                {
                    var att = tr.GetObject(aid, OpenMode.ForRead) as AttributeReference;
                    if (att == null) continue;
                    string key = CanonicalTag(def.Name, att.Tag);
                    string value = key == "DENSITY" ? meta.DensityPercent
                        : key == "FLOORS" ? meta.MaxFloors
                        : key == "FAR" ? meta.Far : null;
                    if (value == null) continue;
                    att.UpgradeOpen();
                    att.TextString = string.IsNullOrWhiteSpace(value) ? "-" : value;
                    changed++;
                }
            }
            return changed;
        }

        private static string CanonicalTag(string blockName, string tag)
        {
            if (blockName == BuildName || blockName == "QH_SDD_METRIC_V16")
                switch ((tag ?? "").ToUpperInvariant())
                {
                    case "A": return "LOT_CODE";
                    case "B": return "DENSITY";
                    case "C": return "FLOORS";
                    case "D": return "FAR";
                    case "E": return "AREA_M2";
                }
            if (blockName == SimpleName || blockName == "QH_SDD2_METRIC_V16")
            {
                if (tag == "1") return "LOT_CODE";
                if (tag == "2") return "AREA_M2";
            }
            return tag;
        }

        private static void SaveLink(Database db, Transaction tr, BlockReference block, string code)
        {
            var apps = (RegAppTable)tr.GetObject(db.RegAppTableId, OpenMode.ForRead);
            if (!apps.Has(LinkApp))
            {
                apps.UpgradeOpen();
                var app = new RegAppTableRecord { Name = LinkApp };
                apps.Add(app); tr.AddNewlyCreatedDBObject(app, true);
            }
            using (var data = new ResultBuffer(
                new TypedValue((int)DxfCode.ExtendedDataRegAppName, LinkApp),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString, code)))
                block.XData = data;
        }

        private static string ReadLink(BlockReference block)
        {
            using (var data = block.GetXDataForApplication(LinkApp))
            {
                if (data == null) return null;
                foreach (var value in data.AsArray())
                    if (value.TypeCode == (int)DxfCode.ExtendedDataAsciiString)
                        return value.Value as string;
            }
            return null;
        }

        private static string ValueFor(string tag, LandMetadata meta, double area,
            Dictionary<string, string> old)
        {
            if (tag == "LINK_CODE") return meta.Code;
            if (tag == "LOT_CODE") return meta.Kind == "BLOCK"
                && meta.Code.StartsWith("OD-", StringComparison.OrdinalIgnoreCase)
                && !string.IsNullOrWhiteSpace(meta.UseCode) && meta.UseCode != "CHUA_GAN"
                ? meta.UseCode : meta.Code;
            if (tag == "AREA_M2") return area.ToString("N2", CultureInfo.GetCultureInfo("vi-VN"));
            string prior;
            if (old != null && old.TryGetValue(tag, out prior) && !string.IsNullOrWhiteSpace(prior))
                return prior;
            if (tag == "DENSITY") return string.IsNullOrWhiteSpace(meta.DensityPercent) ? "-" : meta.DensityPercent;
            if (tag == "FLOORS") return string.IsNullOrWhiteSpace(meta.MaxFloors) ? "-" : meta.MaxFloors;
            if (tag == "FAR") return string.IsNullOrWhiteSpace(meta.Far) ? "-" : meta.Far;
            return "-";
        }

        public static string Get(Dictionary<string, Dictionary<string, string>> labels,
            string code, string tag, string fallback)
        {
            Dictionary<string, string> values;
            string result;
            if (labels.TryGetValue(code, out values) && values.TryGetValue(tag, out result)
                && !string.IsNullOrWhiteSpace(result)) return result;
            return fallback ?? "";
        }
    }
}
