using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace QHPlanningRoads
{
    // Dedicated 1:1 metre styles. Never change the user's current STANDARD
    // text or dimension style and never change existing unrelated entities.
    internal static class CadStyles
    {
        internal const string TextName = "QH_ARIAL";
        internal const string DimName = "QH_DIM_040";
        internal const double AnnotationHeight = 0.4;

        internal static ObjectId Text(Database db, Transaction tr)
        {
            var table = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            if (table.Has(TextName))
            {
                var existing = (TextStyleTableRecord)tr.GetObject(table[TextName], OpenMode.ForWrite);
                existing.FileName = "arial.ttf";
                existing.TextSize = 0;
                existing.XScale = 1.0;
                existing.IsVertical = false;
                return existing.ObjectId;
            }
            table.UpgradeOpen();
            var style = new TextStyleTableRecord {
                Name = TextName,
                FileName = "arial.ttf",
                TextSize = 0,
                XScale = 1.0,
                IsVertical = false
            };
            var id = table.Add(style);
            tr.AddNewlyCreatedDBObject(style, true);
            return id;
        }

        internal static ObjectId Dimension(Database db, Transaction tr)
        {
            ObjectId textId = Text(db, tr);
            var table = (DimStyleTable)tr.GetObject(db.DimStyleTableId, OpenMode.ForRead);
            if (table.Has(DimName))
            {
                var existing = (DimStyleTableRecord)tr.GetObject(table[DimName], OpenMode.ForWrite);
                existing.Dimtxsty = textId;
                existing.Dimtxt = AnnotationHeight;
                existing.Dimscale = 1.0;
                existing.Dimasz = 0.25;
                existing.Dimtad = 1;
                return existing.ObjectId;
            }
            table.UpgradeOpen();
            var style = new DimStyleTableRecord {
                Name = DimName,
                Dimtxsty = textId,
                Dimtxt = AnnotationHeight,
                Dimasz = 0.25,
                Dimscale = 1.0,
                Dimtad = 1,
                Dimgap = 0.15,
                Dimlfac = 1.0,
                Dimdec = 2
            };
            var id = table.Add(style);
            tr.AddNewlyCreatedDBObject(style, true);
            return id;
        }
    }

    public sealed partial class Commands
    {
        [CommandMethod("QHSTYLE")]
        public void CreatePlanningStyles()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            try
            {
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    CadStyles.Dimension(doc.Database, tr);
                    tr.Commit();
                }
                doc.Editor.WriteMessage("\nDa tao text style QH_ARIAL (Arial.ttf) va dim style QH_DIM_040 (chu 0.4m, dimscale 1). Khong thay doi style hien hanh.");
            }
            catch (System.Exception ex) { Report(doc.Editor, ex); }
        }
    }
}
