using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using NetTopologySuite.Geometries;
using CadPolyline = Autodesk.AutoCAD.DatabaseServices.Polyline;
using NtsPolygon = NetTopologySuite.Geometries.Polygon;

namespace QHPlanningRoads
{
    internal sealed class LandMetadata
    {
        public string Kind;       // BLOCK, HOLE, LOT
        public string Code;       // OD-001, OD-001-L01
        public string UseCode;    // ODT, CX, ...
        public string ParentCode; // Parent for holes and lots
        public string DensityPercent = "";
        public string MaxFloors = "";
        public string Far = "";
    }

    internal static class LandStore
    {
        internal const string RegApp = "QH_LAND_INFO";
        internal const string BlockLayer = "QH_O_DAT";
        internal const string HoleLayer = "QH_O_DAT_HOLE";
        internal const string LotLayer = "QH_LO_DAT";
        internal const string LabelLayer = "QH_NHAN_DAT";
        internal const string TableLayer = "QH_BANG_THONG_KE";
        internal const string AccessRoadLayer = "QH_DUONG_NOI_BO";
        internal const string RemainderLayer = "QH_DAT_CHUA_CHIA";

        internal static void EnsureLayers(Database db, Transaction tr)
        {
            var table = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            Make(tr, table, BlockLayer, 4);
            Make(tr, table, HoleLayer, 8);
            Make(tr, table, LotLayer, 2);
            Make(tr, table, LabelLayer, 7);
            Make(tr, table, TableLayer, 7);
            Make(tr, table, AccessRoadLayer, 6);
            Make(tr, table, RemainderLayer, 1);
        }

        internal static void SetRemainderVisible(Database db, Transaction tr, bool visible)
        {
            EnsureLayers(db, tr);
            var layers = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            var record = (LayerTableRecord)tr.GetObject(layers[RemainderLayer], OpenMode.ForWrite);
            record.IsOff = !visible;
        }

        internal static void PromoteBlockDrawOrder(Database db, Transaction tr)
        {
            // QH_O_DAT must remain easy to click even after thousands of lots
            // and bookkeeping remainders have been inserted above it.
            var ms = CadBridge.GetModelSpace(db, tr);
            var behind = new ObjectIdCollection();
            var onTop = new ObjectIdCollection();
            foreach (ObjectId id in ms)
            {
                if (id.IsErased) continue;
                var obj = tr.GetObject(id, OpenMode.ForRead) as Entity;
                if (obj == null || obj.IsErased) continue;
                if (obj.Layer == LotLayer || obj.Layer == RemainderLayer)
                    behind.Add(id);
                else if (obj.Layer == BlockLayer)
                    onTop.Add(id);
            }
            var order = (DrawOrderTable)tr.GetObject(ms.DrawOrderTableId, OpenMode.ForWrite);
            if (behind.Count > 0) order.MoveToBottom(behind);
            if (onTop.Count > 0) order.MoveToTop(onTop);
        }

        private static void Make(Transaction tr, LayerTable table, string layer, short color)
        {
            if (table.Has(layer)) return;
            table.UpgradeOpen();
            var record = new LayerTableRecord { Name = layer,
                Color = Color.FromColorIndex(ColorMethod.ByAci, color) };
            if (layer == RemainderLayer)
            {
                record.IsOff = true;
                record.IsPlottable = false;
            }
            table.Add(record); tr.AddNewlyCreatedDBObject(record, true);
        }

        internal static List<CadPolyline> Polylines(Database db, Transaction tr, string layer)
        {
            var result = new List<CadPolyline>();
            foreach (ObjectId id in CadBridge.GetModelSpace(db, tr))
            {
                if (id.IsErased) continue;
                var p = tr.GetObject(id, OpenMode.ForRead) as CadPolyline;
                if (p != null && !p.IsErased && p.Layer == layer) result.Add(p);
            }
            return result;
        }

        internal static LandMetadata Read(CadPolyline p)
        {
            using (var x = p.GetXDataForApplication(RegApp))
            {
                if (x == null) return null;
                foreach (var t in x.AsArray())
                {
                    if (t.TypeCode != (int)DxfCode.ExtendedDataAsciiString) continue;
                    var pieces = (t.Value as string ?? "").Split('|');
                    if (pieces.Length != 4 && pieces.Length != 7) return null;
                    var data = new LandMetadata { Kind = pieces[0], Code = pieces[1],
                        UseCode = pieces[2], ParentCode = pieces[3] };
                    if (pieces.Length == 7)
                    {
                        data.DensityPercent = pieces[4];
                        data.MaxFloors = pieces[5];
                        data.Far = pieces[6];
                    }
                    return data;
                }
            }
            return null;
        }

        internal static void Save(Database db, Transaction tr, CadPolyline p, LandMetadata data)
        {
            var apps = (RegAppTable)tr.GetObject(db.RegAppTableId, OpenMode.ForRead);
            if (!apps.Has(RegApp))
            {
                apps.UpgradeOpen();
                var rec = new RegAppTableRecord { Name = RegApp };
                apps.Add(rec); tr.AddNewlyCreatedDBObject(rec, true);
            }
            var fields = new[] { data.Kind, data.Code, data.UseCode, data.ParentCode,
                data.DensityPercent, data.MaxFloors, data.Far };
            foreach (string field in fields)
                if ((field ?? "").Contains("|") || (field ?? "").Length > 80)
                    throw new ArgumentException("Mã sử dụng đất chứa ký tự không hợp lệ hoặc quá dài.");
            if (!p.IsWriteEnabled) p.UpgradeOpen();
            using (var x = new ResultBuffer(
                new TypedValue((int)DxfCode.ExtendedDataRegAppName, RegApp),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString,
                    string.Join("|", fields))))
                p.XData = x;
        }

        internal static CadPolyline AddPolygon(Database db, Transaction tr, NtsPolygon poly,
            string layer, LandMetadata meta)
        {
            var ring = poly.ExteriorRing.Coordinates;
            var p = new CadPolyline(ring.Length - 1) { Layer = layer };
            for (int i = 0; i < ring.Length - 1; i++)
                p.AddVertexAt(i, new Point2d(ring[i].X, ring[i].Y), 0, 0, 0);
            p.Closed = true;
            var ms = CadBridge.GetModelSpace(db, tr);
            ms.UpgradeOpen();
            ms.AppendEntity(p); tr.AddNewlyCreatedDBObject(p, true);
            Save(db, tr, p, meta);
            return p;
        }

        internal static NtsPolygon ReconstructBlock(Database db, Transaction tr,
            CadPolyline block, double curveTolerance)
        {
            var data = Read(block);
            if (data == null || data.Kind != "BLOCK")
                throw new ArgumentException("Không phải ô đất do plugin quản lý.");
            var outer = CadBridge.ToPolygon(block, curveTolerance);
            var inner = new List<LinearRing>();
            foreach (var hole in Polylines(db, tr, HoleLayer))
            {
                var h = Read(hole);
                if (h == null || h.Kind != "HOLE" || h.ParentCode != data.Code) continue;
                var polygon = CadBridge.ToPolygon(hole, curveTolerance);
                inner.Add(new GeometryFactory().CreateLinearRing(polygon.ExteriorRing.Coordinates));
            }
            var gf = new GeometryFactory();
            var reconstructed = gf.CreatePolygon(gf.CreateLinearRing(outer.ExteriorRing.Coordinates), inner.ToArray());
            if (!reconstructed.IsValid)
                throw new InvalidOperationException("Ô đất " + data.Code + " hoặc lỗ rỗng không hợp lệ.");
            return reconstructed;
        }

        internal static void ClearManaged(Database db, Transaction tr, params string[] layers)
        {
            var names = new HashSet<string>(layers, StringComparer.OrdinalIgnoreCase);
            foreach (ObjectId id in CadBridge.GetModelSpace(db, tr))
            {
                if (id.IsErased) continue;
                var e = tr.GetObject(id, OpenMode.ForRead) as Entity;
                if (e == null || !names.Contains(e.Layer)) continue;
                e.UpgradeOpen(); e.Erase();
            }
        }

        internal static void ClearLots(Database db, Transaction tr, string blockCode)
        {
            foreach (var lot in Polylines(db, tr, LotLayer))
            {
                var d = Read(lot);
                if (d != null && d.ParentCode == blockCode)
                {
                    lot.UpgradeOpen(); lot.Erase();
                }
            }
            foreach (string layer in new[] { AccessRoadLayer, RemainderLayer })
                foreach (var part in Polylines(db, tr, layer))
                {
                    var data = Read(part);
                    if (data != null && data.ParentCode == blockCode)
                    {
                        part.UpgradeOpen(); part.Erase();
                    }
                }
            // Labels are rebuilt globally using QHLABEL after subdivision.
            ClearManaged(db, tr, LabelLayer);
        }
    }
}
