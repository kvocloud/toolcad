using System;
using System.Collections.Generic;
using System.Linq;
using NetTopologySuite.Geometries;
using NetTopologySuite.Operation.Buffer;
using NetTopologySuite.Operation.Union;

namespace QHPlanningRoads
{
    // Topology engine khong phu thuoc AutoCAD. Met la don vi du lieu dau vao.
    internal sealed class RoadGeometry
    {
        private sealed class JunctionSetting
        {
            public Coordinate Point;
            public double RoundRadius;
            public double Chamfer;
            // Distinct centerline arms pointing away from the junction.
            public List<Coordinate> Arms = new List<Coordinate>();
        }
        private readonly GeometryFactory gf = new GeometryFactory(new PrecisionModel(), 0);
        private const double Eps = 1e-8;

        public BuildResult Build(Polygon site, IList<RoadInput> original, ProjectSettings settings)
        {
            if (site != null && (!site.IsValid || site.Area <= 0))
                throw new ArgumentException("Ranh quy hoạch phải là polygon khép kín hợp lệ.");
            if (original == null || original.Count == 0)
                throw new ArgumentException("Chưa có tim đường được gán mặt cắt.");

            var result = new BuildResult { HasPlanningBoundary = site != null };
            foreach (var r in original)
            {
                r.Profile.Validate();
                var points = RemoveRepeated(r.Points);
                if (points.Count < 2) throw new ArgumentException("Tuyến " + r.RoadCode + " có ít hơn 2 điểm.");
                result.CleanedRoads.Add(new RoadInput
                {
                    Handle = r.Handle, RoadCode = r.RoadCode, Profile = r.Profile.Copy(),
                    Points = points, HasUnmanagedArcs = r.HasUnmanagedArcs
                });
            }

            if (site == null)
            {
                // Unbounded concept mode: build a computational frame safely beyond
                // every roadway. It does NOT represent a real planning boundary.
                var extent = new Envelope();
                double pad = 100.0;
                foreach (var r in result.CleanedRoads)
                {
                    foreach (var pt in r.Points) extent.ExpandToInclude(pt);
                    pad = Math.Max(pad, Math.Max(r.Profile.RedLeft, r.Profile.RedRight)
                        + Math.Max(r.Profile.BuildingSetbackLeft, r.Profile.BuildingSetbackRight)
                        + Math.Max(r.Profile.CurbRadius, r.Profile.RedChamfer)
                        + settings.SnapTolerance + 20.0);
                }
                if (extent.IsNull) throw new ArgumentException("Tim đường không có tọa độ hợp lệ.");
                extent.ExpandBy(pad);
                site = gf.ToGeometry(extent) as Polygon;
                if (site == null || !site.IsValid)
                    throw new InvalidOperationException("Không thể tạo vùng tính toán tạm cho mạng đường.");
                result.Warnings.Add("Chưa thiết lập ranh quy hoạch: diện tích đang tính theo toàn mạng đường, CHƯA cắt theo ranh.");
            }
            result.ComputationSite = site;

            result.ExtendedEndpoints = ExtendNearlyPerpendicular(result.CleanedRoads, settings, result.Warnings);
            var nodes = FindJunctionSettings(result.CleanedRoads);
            result.Junctions = nodes.Select(n => n.Point).ToList();
            result.CenterlineCurves = FindLCenterlineCurves(result.CleanedRoads, nodes, result.Warnings);

            var curbStrips = new List<Geometry>();
            var redStrips = new List<Geometry>();
            var buildingStrips = new List<Geometry>();
            var medians = new List<Geometry>();
            double maxRoadHalf = 0;
            bool hasBuildingSetback = result.CleanedRoads.Any(r =>
                r.Profile.BuildingSetbackLeft > Eps || r.Profile.BuildingSetbackRight > Eps);
            foreach (var r in result.CleanedRoads)
            {
                LineString line = gf.CreateLineString(r.Points.ToArray());
                curbStrips.Add(Strip(line, r.Profile.CurbLeft, r.Profile.CurbRight, r.RoadCode));
                redStrips.Add(Strip(line, r.Profile.RedLeft, r.Profile.RedRight, r.RoadCode));
                if (hasBuildingSetback)
                    buildingStrips.Add(Strip(line,
                        r.Profile.RedLeft + r.Profile.BuildingSetbackLeft,
                        r.Profile.RedRight + r.Profile.BuildingSetbackRight, r.RoadCode));
                maxRoadHalf = Math.Max(maxRoadHalf, Math.Max(r.Profile.RedLeft, r.Profile.RedRight));
                maxRoadHalf = Math.Max(maxRoadHalf, Math.Max(
                    r.Profile.RedLeft + r.Profile.BuildingSetbackLeft,
                    r.Profile.RedRight + r.Profile.BuildingSetbackRight));
                if (r.Profile.Median > Eps)
                {
                    Geometry medianAxis = line;
                    if (nodes.Count > 0)
                    {
                        // Remove the axis near junction centers. Round cap noses
                        // stop roughly MedianSetback meters before the node.
                        var excludes = nodes.Select(n =>
                            (Geometry)gf.CreatePoint(n.Point).Buffer(
                                r.Profile.MedianSetback + r.Profile.Median / 2.0, 16)).ToList();
                        medianAxis = line.Difference(UnaryUnionOp.Union(excludes));
                    }
                    if (!medianAxis.IsEmpty)
                        medians.Add(medianAxis.Buffer(r.Profile.Median / 2.0, 16, EndCapStyle.Round));
                }
            }

            // Close the outside BACK of a genuine two-arm L only. This works
            // both for one bent PLINE and TWO separate routes ending at one
            // corner; do not affect degree-3 T or degree-4 X intersections.
            AddTwoArmLBacks(result.CleanedRoads, nodes, curbStrips, false, false, result.Warnings);
            AddTwoArmLBacks(result.CleanedRoads, nodes, redStrips, true, false, result.Warnings);
            if (hasBuildingSetback)
                AddTwoArmLBacks(result.CleanedRoads, nodes, buildingStrips, true, true, result.Warnings);

            Geometry curbSurface = UnaryUnionOp.Union(curbStrips).Intersection(site);
            Geometry redSurface = UnaryUnionOp.Union(redStrips).Intersection(site);
            if (!curbSurface.IsValid || !redSurface.IsValid)
                throw new InvalidOperationException("Vùng đường tự giao hoặc không hợp lệ. Kiểm tra tim đường.");

            // Bo/vat cac goc LO DAT quanh nut giao. Phan duong la phan bu cua lo dat.
            // Do cong duoc roi rac hoa theo CurveTolerance; khong nhan la cung ARC native.
            result.Curb = TreatLandCorners(site, curbSurface, nodes, maxRoadHalf,
                CornerMode.Round, settings.CurveTolerance, result.Warnings);
            result.RedLine = TreatLandCorners(site, redSurface, nodes, maxRoadHalf,
                CornerMode.Chamfer, settings.CurveTolerance, result.Warnings);
            if (hasBuildingSetback)
            {
                Geometry buildingSurface = UnaryUnionOp.Union(buildingStrips).Intersection(site);
                if (!buildingSurface.IsValid)
                    throw new InvalidOperationException("Vung chi gioi xay dung khong hop le.");
                result.BuildingLine = TreatLandCorners(site, buildingSurface,
                    nodes, maxRoadHalf, CornerMode.Chamfer, settings.CurveTolerance, result.Warnings);
            }
            result.Median = medians.Count == 0 ? gf.CreateGeometryCollection(new Geometry[0])
                : UnaryUnionOp.Union(medians).Intersection(site);
            return result;
        }

        private static List<Coordinate> RemoveRepeated(IList<Coordinate> input)
        {
            var output = new List<Coordinate>();
            foreach (Coordinate p in input)
                if (output.Count == 0 || p.Distance(output[output.Count - 1]) > Eps)
                    output.Add(new Coordinate(p.X, p.Y));
            return output;
        }

        // Flat-ended rectangles keep the strip engine topology stable for T/X.
        // The OUTER miter wedge is added SEPARATELY only at two-arm L nodes.
        private Geometry Strip(LineString centerline, double left, double right, string roadCode)
        {
            var segments = new List<Geometry>();
            var coords = centerline.Coordinates;
            for (int i = 0; i < coords.Length - 1; i++)
            {
                Coordinate a = coords[i], b = coords[i + 1];
                double dx = b.X - a.X, dy = b.Y - a.Y;
                double length = Math.Sqrt(dx * dx + dy * dy);
                if (length < Eps) continue;
                double nx = -dy / length, ny = dx / length;
                Coordinate l0 = new Coordinate(a.X + nx * left, a.Y + ny * left);
                Coordinate l1 = new Coordinate(b.X + nx * left, b.Y + ny * left);
                Coordinate r1 = new Coordinate(b.X - nx * right, b.Y - ny * right);
                Coordinate r0 = new Coordinate(a.X - nx * right, a.Y - ny * right);
                var poly = gf.CreatePolygon(new[] { l0, l1, r1, r0, l0 });
                if (!poly.IsValid || poly.Area <= Eps)
                    throw new InvalidOperationException("Đoạn dải đường không hợp lệ: " + roadCode);
                segments.Add(poly);
            }
            if (segments.Count == 0)
                throw new InvalidOperationException("Không đủ đoạn tim đường: " + roadCode);
            return UnaryUnionOp.Union(segments);
        }

        private void AddTwoArmLBacks(IList<RoadInput> roads,
            IEnumerable<JunctionSetting> nodes, IList<Geometry> strips,
            bool redLine, bool buildingLine, IList<string> warnings)
        {
            foreach (var j in nodes)
            {
                if (j.Arms.Count != 2) continue;
                Coordinate u = j.Arms[0], v = j.Arms[1];
                double dot = u.X * v.X + u.Y * v.Y;
                if (Math.Abs(dot) > Math.Sin(15 * Math.PI / 180.0)) continue;
                double width0, width1;
                Coordinate norm0, norm1;
                if (!TryOutsideWidth(roads, j.Point, u, v, redLine, buildingLine, out width0, out norm0)
                    || !TryOutsideWidth(roads, j.Point, v, u, redLine, buildingLine, out width1, out norm1))
                {
                    warnings.Add("Góc L hai nhánh tại " + j.Point.X.ToString("0.##")
                        + "," + j.Point.Y.ToString("0.##")
                        + " chưa có đủ mặt cắt để nối lưng.");
                    continue;
                }
                var first = new Coordinate(j.Point.X + norm0.X * width0,
                    j.Point.Y + norm0.Y * width0);
                var second = new Coordinate(j.Point.X + norm1.X * width1,
                    j.Point.Y + norm1.Y * width1);
                double determinant = Cross(u.X, u.Y, v.X, v.Y);
                if (Math.Abs(determinant) < 0.3) continue;
                double t = Cross(second.X - first.X, second.Y - first.Y,
                    v.X, v.Y) / determinant;
                var miter = new Coordinate(first.X + t * u.X, first.Y + t * u.Y);
                double maximum = Math.Max(width0, width1);
                if (miter.Distance(j.Point) > 4 * maximum) continue;
                // Previous V1.5 triangle FIRST-MITER-SECOND touched each
                // road strip at only ONE vertex.  The missing triangle
                // FIRST-NODE-SECOND became a separate OD-xxx land island.
                // A four-sided miter closure shares WHOLE EDGES with both
                // strips and closes the back exactly (FILLET radius = 0).
                var closure = gf.CreatePolygon(new[] {
                    first, miter, second, new Coordinate(j.Point), first
                });
                if (closure.IsValid && closure.Area > Eps) strips.Add(closure);
            }
        }

        // Outward-facing normal of one arm points AWAY from the other arm.
        // Resolve width against the original polyline direction for asymmetric
        // carriageways and sidewalks, not against the direction of the arm.
        private static bool TryOutsideWidth(IList<RoadInput> roads, Coordinate node,
            Coordinate arm, Coordinate other, bool redLine, bool buildingLine,
            out double width, out Coordinate outside)
        {
            width = 0;
            double leftX = -arm.Y, leftY = arm.X;
            bool otherToLeft = leftX * other.X + leftY * other.Y > 0;
            outside = new Coordinate(otherToLeft ? -leftX : leftX,
                otherToLeft ? -leftY : leftY);
            foreach (var road in roads)
                for (int i = 0; i < road.Points.Count - 1; i++)
                {
                    var a = road.Points[i]; var b = road.Points[i + 1];
                    double dx = b.X - a.X, dy = b.Y - a.Y;
                    double length = Math.Sqrt(dx * dx + dy * dy);
                    if (length < Eps) continue;
                    double nx = -dy / length, ny = dx / length;
                    bool start = a.Distance(node) < 0.05;
                    bool end = b.Distance(node) < 0.05;
                    if (!start && !end) continue;
                    double armX = start ? dx / length : -dx / length;
                    double armY = start ? dy / length : -dy / length;
                    if (armX * arm.X + armY * arm.Y < 0.995) continue;
                    bool isLeft = nx * outside.X + ny * outside.Y > 0;
                    width = redLine ? (isLeft ? road.Profile.RedLeft : road.Profile.RedRight)
                        : (isLeft ? road.Profile.CurbLeft : road.Profile.CurbRight);
                    if (buildingLine)
                        width += isLeft ? road.Profile.BuildingSetbackLeft : road.Profile.BuildingSetbackRight;
                    return width > Eps;
                }
            return false;
        }

        // Only an L bent inside ONE PLINE is eligible for native centerline
        // smoothing. Do NOT smooth T/X intersections (three/four outward arms).
        // The NTS roadway strips are still generated from original square
        // design vertices, preserving a squared back side and C6 red chamfer.
        private static List<CenterlineCurve> FindLCenterlineCurves(IList<RoadInput> roads,
            IList<JunctionSetting> junctions, IList<string> warnings)
        {
            var curves = new List<CenterlineCurve>();
            foreach (var road in roads)
            {
                if (road.HasUnmanagedArcs)
                {
                    warnings.Add("Tuyến " + road.RoadCode
                        + " có cung ARC người dùng: giữ nguyên tim, không tự bo L để tránh xóa cung nguồn.");
                    continue;
                }
                var points = road.Points;
                for (int i = 1; i < points.Count - 1; i++)
                {
                    var a = points[i - 1]; var c = points[i]; var b = points[i + 1];
                    double ix = c.X - a.X, iy = c.Y - a.Y;
                    double ox = b.X - c.X, oy = b.Y - c.Y;
                    double lenIn = Math.Sqrt(ix * ix + iy * iy);
                    double lenOut = Math.Sqrt(ox * ox + oy * oy);
                    if (lenIn < 0.01 || lenOut < 0.01) continue;
                    ix /= lenIn; iy /= lenIn; ox /= lenOut; oy /= lenOut;
                    double theta = Math.Acos(Math.Max(-1, Math.Min(1, ix * ox + iy * oy)));
                    if (Math.Abs(theta - Math.PI / 2) > Math.PI / 18) continue; // 90 +/- 10 deg.
                    double turn = Cross(ix, iy, ox, oy);
                    var node = junctions.FirstOrDefault(j => j.Point.Distance(c) < 0.05);
                    if (node == null || node.Arms.Count != 2) continue;
                    double innerWidth = turn > 0 ? road.Profile.CurbLeft : road.Profile.CurbRight;
                    double radius = road.Profile.CurbRadius + innerWidth;
                    if (road.Profile.CurbRadius <= 0 || radius < Eps) continue;
                    double tangent = radius * Math.Tan(theta / 2.0);
                    // A genuine R8 curb requires centerline R8+carriageway.
                    // Do not reject a valid 90-degree bend just because its
                    // tangent consumes more than 45% of one arm.
                    if (tangent >= Math.Min(lenIn, lenOut) - 0.05)
                    {
                        warnings.Add("Góc L trên " + road.RoadCode
                            + " thiếu đoạn thẳng để bo tim R=" + radius.ToString("0.##") + "m.");
                        continue;
                    }
                    // Adjacent L fillets must not consume the same straight segment.
                    var previous = curves.LastOrDefault(x => x.Handle == road.Handle && x.VertexIndex == i - 1);
                    if (previous != null && previous.Exit.Distance(c) < tangent * 1.1)
                    {
                        warnings.Add("Hai góc L quá gần nhau trên " + road.RoadCode + "; bỏ bo góc sau.");
                        continue;
                    }
                    curves.Add(new CenterlineCurve {
                        Handle = road.Handle, VertexIndex = i,
                        Entry = new Coordinate(c.X - ix * tangent, c.Y - iy * tangent),
                        Exit = new Coordinate(c.X + ox * tangent, c.Y + oy * tangent),
                        Bulge = Math.Sign(turn) * Math.Tan(theta / 4.0),
                        CenterlineRadius = radius
                    });
                }
            }
            return curves;
        }

        private enum CornerMode { Round, Chamfer }

        private Geometry TreatLandCorners(Polygon site, Geometry road, List<JunctionSetting> junctions,
            double halfWidth, CornerMode mode, double curveTolerance, List<string> warnings)
        {
            if (junctions.Count == 0) return road;
            Geometry land = site.Difference(road);
            var modified = new List<Geometry>();
            foreach (var p in Polygons(land))
            {
                var pts = p.ExteriorRing.Coordinates;
                var newRing = CornerRing(pts, junctions, halfWidth, mode,
                    curveTolerance, warnings, false);
                var holes = new LinearRing[p.NumInteriorRings];
                for (int i = 0; i < p.NumInteriorRings; i++)
                {
                    // IMPORTANT: a finite L-shaped roadway entirely inside
                    // the planning site is a HOLE of the land polygon. The
                    // belly corner is a convex LAND corner on that inner ring;
                    // ignoring holes silently skipped R8/C6 for such L roads.
                    var holeRing = CornerRing(p.GetInteriorRingN(i).Coordinates,
                        junctions, halfWidth, mode, curveTolerance, warnings, true);
                    holes[i] = gf.CreateLinearRing(holeRing);
                }
                var trial = gf.CreatePolygon(gf.CreateLinearRing(newRing), holes);
                if (!trial.IsValid || trial.IsEmpty || trial.Area <= Eps)
                {
                    warnings.Add("Một vùng đất không đủ chỗ bo/vát góc; giữ nguyên vùng này.");
                    modified.Add(p);
                }
                else modified.Add(trial);
            }
            if (modified.Count == 0) return road;
            var newLand = UnaryUnionOp.Union(modified);
            var changedRoad = site.Difference(newLand);
            if (!changedRoad.IsValid) throw new InvalidOperationException("Bo/vát tạo polygon không hợp lệ; không cập nhật bản vẽ.");
            return changedRoad;
        }

        private static IEnumerable<Polygon> Polygons(Geometry g)
        {
            if (g is Polygon) { yield return (Polygon)g; yield break; }
            for (int i = 0; i < g.NumGeometries; i++)
                if (g.GetGeometryN(i) is Polygon) yield return (Polygon)g.GetGeometryN(i);
        }

        private static Coordinate[] CornerRing(Coordinate[] closed, IList<JunctionSetting> junctions,
            double maxHalfWidth, CornerMode mode, double chordError, IList<string> warnings,
            bool isHole)
        {
            int n = closed.Length - 1;
            if (n < 3) return closed;
            double signedArea = 0;
            for (int i = 0; i < n; i++)
                signedArea += closed[i].X * closed[(i + 1) % n].Y - closed[(i + 1) % n].X * closed[i].Y;
            double orientation = signedArea >= 0 ? 1 : -1;
            var output = new List<Coordinate>();
            for (int i = 0; i < n; i++)
            {
                var prev = closed[(i + n - 1) % n];
                var corner = closed[i];
                var next = closed[(i + 1) % n];
                double ax = prev.X - corner.X, ay = prev.Y - corner.Y;
                double bx = next.X - corner.X, by = next.Y - corner.Y;
                double la = Math.Sqrt(ax * ax + ay * ay), lb = Math.Sqrt(bx * bx + by * by);
                double turn = ((corner.X - prev.X) * (next.Y - corner.Y)
                    - (corner.Y - prev.Y) * (next.X - corner.X)) * orientation
                    * (isHole ? -1 : 1);
                var closest = junctions.OrderBy(j => j.Point.Distance(corner)).First();
                double size = mode == CornerMode.Round ? closest.RoundRadius : closest.Chamfer;
                bool nearNode = closest.Point.Distance(corner) <= 2.2 * maxHalfWidth + size;
                // A valid inside corner must look toward TWO outgoing arms.
                // At a T, the opposite/back side has only one matching arm;
                // this prevents fillet/chamfer appearing on the back of the T.
                bool insideJunction = IsInsideJunctionQuadrant(closest, corner);
                if (size < Eps || la < Eps || lb < Eps || turn <= Eps || !nearNode || !insideJunction)
                {
                    output.Add(new Coordinate(corner)); continue;
                }
                ax /= la; ay /= la; bx /= lb; by /= lb;
                double alpha = Math.Acos(Math.Max(-1, Math.Min(1, ax * bx + ay * by)));
                if (alpha < Math.PI / 6 || alpha > 5 * Math.PI / 6)
                {
                    output.Add(new Coordinate(corner)); continue;
                }
                double tangent = mode == CornerMode.Round ? size / Math.Tan(alpha / 2.0) : size;
                if (tangent >= Math.Min(la, lb) * 0.90)
                {
                    warnings.Add("Góc tại " + corner.X.ToString("0.##") + "," + corner.Y.ToString("0.##")
                        + " quá ngắn để bo/vát với kích thước yêu cầu.");
                    output.Add(new Coordinate(corner)); continue;
                }
                var t1 = new Coordinate(corner.X + ax * tangent, corner.Y + ay * tangent);
                var t2 = new Coordinate(corner.X + bx * tangent, corner.Y + by * tangent);
                output.Add(t1);
                if (mode == CornerMode.Round)
                {
                    double vx = ax + bx, vy = ay + by, blen = Math.Sqrt(vx * vx + vy * vy);
                    double centerDist = size / Math.Sin(alpha / 2.0);
                    var c = new Coordinate(corner.X + vx / blen * centerDist,
                        corner.Y + vy / blen * centerDist);
                    double a1 = Math.Atan2(t1.Y - c.Y, t1.X - c.X);
                    double a2 = Math.Atan2(t2.Y - c.Y, t2.X - c.X);
                    double sweep = a2 - a1;
                    while (sweep > Math.PI) sweep -= 2 * Math.PI;
                    while (sweep < -Math.PI) sweep += 2 * Math.PI;
                    // Nho hon chordError; voi R8 va 90 do sai lech thuc te rat nho.
                    double safeError = Math.Min(Math.Max(chordError, 0.001), size * 0.25);
                    double step = 2 * Math.Acos(Math.Max(-1, 1 - safeError / size));
                    int count = Math.Max(2, Math.Min(256, (int)Math.Ceiling(Math.Abs(sweep) / step)));
                    for (int k = 1; k < count; k++)
                    {
                        double a = a1 + sweep * k / count;
                        output.Add(new Coordinate(c.X + size * Math.Cos(a), c.Y + size * Math.Sin(a)));
                    }
                }
                output.Add(t2);
            }
            if (output.Count < 3) return closed;
            output.Add(new Coordinate(output[0]));
            return output.ToArray();
        }

        private static bool IsInsideJunctionQuadrant(JunctionSetting junction, Coordinate corner)
        {
            double dx = corner.X - junction.Point.X;
            double dy = corner.Y - junction.Point.Y;
            double length = Math.Sqrt(dx * dx + dy * dy);
            if (length < Eps || junction.Arms.Count < 2) return false;
            dx /= length;
            dy /= length;
            int towardArms = 0;
            foreach (var arm in junction.Arms)
                if (dx * arm.X + dy * arm.Y > 0.15) towardArms++;
            return towardArms >= 2;
        }

        // Chi keo dau/cuoi voi giao tuong doi vuong goc, khong lam thay doi duong goc tren DWG.
        private static int ExtendNearlyPerpendicular(IList<RoadInput> roads, ProjectSettings settings, IList<string> warnings)
        {
            int count = 0;
            for (int i = 0; i < roads.Count; i++)
            {
                var points = roads[i].Points;
                for (int endpoint = 0; endpoint < 2; endpoint++)
                {
                    int idx = endpoint == 0 ? 0 : points.Count - 1;
                    int neighbor = endpoint == 0 ? 1 : points.Count - 2;
                    Coordinate p = points[idx], prev = points[neighbor];
                    double dx = p.X - prev.X, dy = p.Y - prev.Y;
                    double len = Math.Sqrt(dx * dx + dy * dy);
                    if (len < Eps) continue;
                    dx /= len; dy /= len;
                    double best = settings.SnapTolerance + Eps;
                    Coordinate candidate = null;
                    for (int j = 0; j < roads.Count; j++)
                    {
                        if (j == i) continue;
                        var other = roads[j].Points;
                        for (int k = 0; k < other.Count - 1; k++)
                        {
                            var q = other[k]; var s = other[k + 1];
                            double ex = s.X - q.X, ey = s.Y - q.Y;
                            double elen = Math.Sqrt(ex * ex + ey * ey);
                            if (elen < Eps) continue;
                            double cosine = Math.Abs((dx * ex + dy * ey) / elen);
                            double angle = Math.Acos(Math.Min(1, cosine)) * 180.0 / Math.PI;
                            // Abs cosine => goc nho giua 2 truc: chi chap nhan gan 90 do.
                            if (angle < settings.MinAngle || angle > 90) continue;
                            double det = Cross(dx, dy, ex, ey);
                            if (Math.Abs(det) < Eps) continue;
                            double rx = q.X - p.X, ry = q.Y - p.Y;
                            double t = Cross(rx, ry, ex, ey) / det;
                            double u = Cross(rx, ry, dx, dy) / det;
                            if (t <= 0.000001 || t > best || u < -settings.SnapTolerance / elen
                                || u > 1 + settings.SnapTolerance / elen) continue;
                            best = t; candidate = new Coordinate(p.X + dx * t, p.Y + dy * t);
                        }
                    }
                    if (candidate != null)
                    {
                        points[idx] = candidate;
                        count++;
                    }
                }
            }
            if (count > 0) warnings.Add("Đã nối " + count + " đầu tim đường gần vuông góc; QHBUILD cập nhật tim chính.");
            return count;
        }

        private static List<JunctionSetting> FindJunctionSettings(IList<RoadInput> roads)
        {
            var nodes = new List<JunctionSetting>();
            // An L-bend within ONE polyline is also a junction corner. The old
            // code only considered intersections between distinct roads.
            foreach (var road in roads)
                for (int k = 1; k < road.Points.Count - 1; k++)
                {
                    var prev = road.Points[k - 1];
                    var c = road.Points[k];
                    var next = road.Points[k + 1];
                    double ax = prev.X - c.X, ay = prev.Y - c.Y;
                    double bx = next.X - c.X, by = next.Y - c.Y;
                    double lenA = Math.Sqrt(ax * ax + ay * ay);
                    double lenB = Math.Sqrt(bx * bx + by * by);
                    if (lenA < 0.1 || lenB < 0.1) continue;
                    double dot = (ax * bx + ay * by) / (lenA * lenB);
                    double angle = Math.Acos(Math.Max(-1, Math.Min(1, dot))) * 180.0 / Math.PI;
                    if (angle < 60 || angle > 120) continue;
                    var node = new JunctionSetting {
                        Point = new Coordinate(c.X, c.Y),
                        RoundRadius = road.Profile.CurbRadius,
                        Chamfer = road.Profile.RedChamfer
                    };
                    AddArm(node.Arms, ax, ay);
                    AddArm(node.Arms, bx, by);
                    nodes.Add(node);
                }
            for (int i = 0; i < roads.Count; i++)
                for (int j = i + 1; j < roads.Count; j++)
                    for (int a = 0; a < roads[i].Points.Count - 1; a++)
                        for (int b = 0; b < roads[j].Points.Count - 1; b++)
                        {
                            Coordinate p = roads[i].Points[a], p2 = roads[i].Points[a + 1];
                            Coordinate q = roads[j].Points[b], q2 = roads[j].Points[b + 1];
                            double ax = p2.X - p.X, ay = p2.Y - p.Y;
                            double bx = q2.X - q.X, by = q2.Y - q.Y;
                            double det = Cross(ax, ay, bx, by);
                            if (Math.Abs(det) < Eps) continue;
                            double t = Cross(q.X - p.X, q.Y - p.Y, bx, by) / det;
                            double u = Cross(q.X - p.X, q.Y - p.Y, ax, ay) / det;
                            if (t < -Eps || t > 1 + Eps || u < -Eps || u > 1 + Eps) continue;
                            var node = new Coordinate(p.X + t * ax, p.Y + t * ay);
                            var existing = nodes.FirstOrDefault(x => x.Point.Distance(node) < 0.01);
                            double r = Math.Max(roads[i].Profile.CurbRadius, roads[j].Profile.CurbRadius);
                            double c = Math.Max(roads[i].Profile.RedChamfer, roads[j].Profile.RedChamfer);
                            if (existing == null)
                                nodes.Add(new JunctionSetting { Point = node, RoundRadius = r, Chamfer = c });
                            else
                            {
                                existing.RoundRadius = Math.Max(existing.RoundRadius, r);
                                existing.Chamfer = Math.Max(existing.Chamfer, c);
                            }
                        }
            foreach (var node in nodes)
            {
                foreach (var road in roads)
                    for (int i = 0; i < road.Points.Count - 1; i++)
                    {
                        var a = road.Points[i]; var b = road.Points[i + 1];
                        double vx = b.X - a.X, vy = b.Y - a.Y;
                        double len2 = vx * vx + vy * vy;
                        if (len2 < Eps) continue;
                        double t = ((node.Point.X - a.X) * vx + (node.Point.Y - a.Y) * vy) / len2;
                        if (t < -0.001 || t > 1.001) continue;
                        double nx = a.X + t * vx, ny = a.Y + t * vy;
                        if (Math.Sqrt((nx - node.Point.X) * (nx - node.Point.X)
                            + (ny - node.Point.Y) * (ny - node.Point.Y)) > 0.02) continue;
                        AddArm(node.Arms, a.X - node.Point.X, a.Y - node.Point.Y);
                        AddArm(node.Arms, b.X - node.Point.X, b.Y - node.Point.Y);
                    }
            }
            return nodes;
        }

        private static void AddArm(IList<Coordinate> arms, double dx, double dy)
        {
            double length = Math.Sqrt(dx * dx + dy * dy);
            if (length < 0.05) return;
            double x = dx / length, y = dy / length;
            if (arms.Any(v => v.X * x + v.Y * y > 0.995)) return;
            arms.Add(new Coordinate(x, y));
        }

        private static double Cross(double ax, double ay, double bx, double by) { return ax * by - ay * bx; }
    }
}
