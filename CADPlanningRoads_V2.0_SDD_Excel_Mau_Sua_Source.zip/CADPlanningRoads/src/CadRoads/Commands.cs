using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CadPolyline = Autodesk.AutoCAD.DatabaseServices.Polyline;

[assembly: Autodesk.AutoCAD.Runtime.ExtensionApplication(typeof(QHPlanningRoads.Commands))]
[assembly: Autodesk.AutoCAD.Runtime.CommandClass(typeof(QHPlanningRoads.Commands))]

namespace QHPlanningRoads
{
    public sealed partial class Commands : IExtensionApplication
    {
        private static readonly ProjectSettings Settings = new ProjectSettings();

        public void Initialize()
        {
            AppDomain.CurrentDomain.AssemblyResolve += ResolveDependency;
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            if (doc != null) doc.Editor.WriteMessage("\nQH Planning Roads V2.0: QHSETUP QHROADS QHNAME QHEDIT QHBUILD QHLA QHDU QHLAND QHZONE QHLOT QHTENLO QHLABEL QHLABELSCALE QHSCALEO QHSCALELO QHMCBANG QHMCGAN QHMCSCALE QHMCFIX QHMCVE QHSTYLE QHCHITIEU QHSDDEXPORT QHSDDIMPORT QHAUDIT QHEXPORT QHSHIFT QHHELP.\n");
        }

        public void Terminate() { AppDomain.CurrentDomain.AssemblyResolve -= ResolveDependency; }

        private static Assembly ResolveDependency(object sender, ResolveEventArgs args)
        {
            string simpleName = new AssemblyName(args.Name).Name;
            if (simpleName.Equals("QHPlanningRoads", StringComparison.OrdinalIgnoreCase)) return null;
            string folder = Path.GetDirectoryName(typeof(Commands).Assembly.Location);
            string candidate = Path.Combine(folder, simpleName + ".dll");
            return File.Exists(candidate) ? Assembly.LoadFrom(candidate) : null;
        }

        [CommandMethod("QHSETUP")]
        public void Setup()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            var options = new PromptEntityOptions("\nChọn LWPOLYLINE làm ranh quy hoạch (có thể đang Open): ");
            options.SetRejectMessage("\nYêu cầu Polyline 2D.");
            options.AddAllowedClass(typeof(CadPolyline), true);
            var choice = ed.GetEntity(options);
            if (choice.Status != PromptStatus.OK) return;
            try
            {
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var p = (CadPolyline)tr.GetObject(choice.ObjectId, OpenMode.ForRead);
                    bool closeOpenCopy = !p.Closed;
                    if (p.NumberOfVertices < 3)
                        throw new ArgumentException("Ranh quy hoạch cần ít nhất 3 đỉnh.");
                    if (closeOpenCopy)
                    {
                        var a = p.GetPoint2dAt(0);
                        var b = p.GetPoint2dAt(p.NumberOfVertices - 1);
                        double gap = a.GetDistanceTo(b);
                        ed.WriteMessage("\nRanh hiện đang ở trạng thái Open. Khoảng cách đầu-cuối: "
                            + gap.ToString("N3") + " m.");
                        ed.WriteMessage("\nNếu đóng, sẽ tạo đoạn nối THẲNG từ điểm cuối về điểm đầu. Nét gốc không bị sửa.");
                        var closeOpt = new PromptKeywordOptions("\nĐóng bản SAO làm ranh quy hoạch? [CloseCopy/Cancel] <Cancel>: ");
                        closeOpt.Keywords.Add("CloseCopy");
                        closeOpt.Keywords.Add("Cancel");
                        closeOpt.Keywords.Default = "Cancel";
                        var closeChoice = ed.GetKeywords(closeOpt);
                        if (closeChoice.Status != PromptStatus.OK || closeChoice.StringResult != "CloseCopy")
                        {
                            ed.WriteMessage("\nĐã hủy thiết lập ranh. Có thể chạy QHBUILD không cần ranh ở chế độ ý tưởng.");
                            return;
                        }
                    }
                    CadBridge.ToPolygon(p, Settings.CurveTolerance, closeOpenCopy);
                    int insunits = Convert.ToInt32(AcadApp.GetSystemVariable("INSUNITS"));
                    if (insunits != 6)
                    {
                        var yn = new PromptKeywordOptions("\nBản vẽ chưa khai báo đơn vị Mét (INSUNITS=6). Tọa độ vẫn được hiểu là mét. Tiếp tục? [Yes/No] ");
                        yn.Keywords.Add("Yes"); yn.Keywords.Add("No"); yn.Keywords.Default = "No";
                        if (ed.GetKeywords(yn).StringResult != "Yes") return;
                    }
                    CadBridge.EnsureLayers(doc.Database, tr);
                    CadBridge.ReplaceBoundary(doc.Database, tr, p, closeOpenCopy);
                    tr.Commit();
                }
                ed.WriteMessage("\nĐã lưu bản sao ranh quy hoạch khép kín và tạo các layer. Nét nguồn được giữ nguyên.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        [CommandMethod("QHROADS")]
        public void RegisterRoads()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            var opt = new PromptSelectionOptions { MessageForAdding = "\nChọn các tim đường LINE hoặc LWPOLYLINE: " };
            var filter = new SelectionFilter(new[] { new TypedValue((int)DxfCode.Start, "LINE,LWPOLYLINE") });
            var selection = ed.GetSelection(opt, filter);
            if (selection.Status != PromptStatus.OK) return;
            ApplyProfile(doc, selection.Value.GetObjectIds(), true);
        }

        [CommandMethod("QHEDIT")]
        public void EditRoad()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var opt = new PromptEntityOptions("\nChọn tim đường đã đăng ký để sửa mặt cắt: ");
            opt.SetRejectMessage("\nYêu cầu LWPOLYLINE.");
            opt.AddAllowedClass(typeof(CadPolyline), true);
            var p = doc.Editor.GetEntity(opt);
            if (p.Status != PromptStatus.OK) return;
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                var entity = (CadPolyline)tr.GetObject(p.ObjectId, OpenMode.ForRead);
                if (CadBridge.ReadProfile(entity) == null)
                {
                    doc.Editor.WriteMessage("\nTim chưa được đăng ký. Hãy chạy QHROADS trước.");
                    return;
                }
            }
            ApplyProfile(doc, new[] { p.ObjectId }, false);
        }

        private static void ApplyProfile(Autodesk.AutoCAD.ApplicationServices.Document doc,
            ObjectId[] selected, bool askRoadNames)
        {
            var ed = doc.Editor;
            try
            {
                RoadProfile previous = new RoadProfile();
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var first = tr.GetObject(selected[0], OpenMode.ForRead) as Entity;
                    var firstPolyline = first as CadPolyline;
                    if (firstPolyline != null)
                        previous = CadBridge.ReadProfile(firstPolyline) ?? new RoadProfile();
                    foreach (ObjectId id in selected)
                    {
                        var e = tr.GetObject(id, OpenMode.ForRead) as Entity;
                        if (e == null || CadBridge.IsPluginOwnedLayer(e.Layer))
                            throw new ArgumentException("Có đối tượng nằm trên layer kết quả, không phải tim nguồn.");
                        var p = e as CadPolyline;
                        var l = e as Line;
                        if (p != null && p.Layer == CadBridge.CleanLayer
                            && CadBridge.ReadProfile(p) == null)
                            throw new ArgumentException("Đây là tim kết quả cũ không có XData; không đăng ký lại. Chọn tim nguồn gốc hoặc chạy QHBUILD để dọn tim trùng.");
                        if (p != null && (p.Closed || p.NumberOfVertices < 2))
                            throw new ArgumentException("Tim polyline phải hở và có ít nhất 2 đỉnh.");
                        if (l != null && (Math.Abs(l.StartPoint.Z) > 0.00001
                            || Math.Abs(l.EndPoint.Z) > 0.00001
                            || l.StartPoint.DistanceTo(l.EndPoint) < 0.000001))
                            throw new ArgumentException("LINE phải nằm trên XY (Z=0) và có chiều dài dương.");
                        if (p == null && l == null)
                            throw new ArgumentException("QHROADS chỉ nhận LINE hoặc LWPOLYLINE.");
                    }
                }

                using (var form = new SectionForm(previous, selected.Length))
                {
                    if (AcadApp.ShowModalDialog(form) != System.Windows.Forms.DialogResult.OK) return;
                    var roadNames = new Dictionary<ObjectId, string>();
                    if (askRoadNames)
                    {
                        var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                        using (var tr = doc.Database.TransactionManager.StartTransaction())
                        {
                            foreach (var r in CadBridge.RegisteredRoads(doc.Database, tr,
                                Settings.CurveTolerance))
                                if (!string.IsNullOrWhiteSpace(r.Profile.RoadName))
                                    used.Add(r.Profile.RoadName);
                            int next = 1;
                            foreach (var name in used)
                            {
                                int n;
                                if (name.StartsWith("N", StringComparison.OrdinalIgnoreCase)
                                    && int.TryParse(name.Substring(1), out n))
                                    next = Math.Max(next, n + 1);
                            }
                            for (int i = 0; i < selected.Length; i++)
                            {
                                var source = tr.GetObject(selected[i], OpenMode.ForRead) as CadPolyline;
                                string existingName = source == null ? "" :
                                    (CadBridge.ReadProfile(source) ?? new RoadProfile()).RoadName;
                                if (!string.IsNullOrWhiteSpace(existingName)) continue;
                                string generated;
                                do { generated = "N" + next++; } while (used.Contains(generated));
                                used.Add(generated);
                                roadNames[selected[i]] = generated;
                            }
                        }
                    }
                    var set = new HashSet<ObjectId>(selected);
                    int changed = 0;
                    using (var tr = doc.Database.TransactionManager.StartTransaction())
                    {
                        if (form.Scope != EditScope.Selected)
                        {
                            foreach (ObjectId id in CadBridge.GetModelSpace(doc.Database, tr))
                            {
                                var p = tr.GetObject(id, OpenMode.ForRead) as CadPolyline;
                                if (p == null || p.Closed) continue;
                                var existing = CadBridge.ReadProfile(p);
                                if (existing == null) continue;
                                if (form.Scope == EditScope.All || existing.SameSection(previous)) set.Add(id);
                            }
                        }
                        CadBridge.EnsureLayers(doc.Database, tr);
                        var ms = CadBridge.GetModelSpace(doc.Database, tr);
                        foreach (ObjectId id in set)
                        {
                            var entity = tr.GetObject(id, OpenMode.ForWrite) as Entity;
                            if (entity == null) continue;
                            var p = entity as CadPolyline;
                            var sourceLine = entity as Line;
                            if (sourceLine != null)
                            {
                                // One centerline only: transfer LINE -> LWPOLYLINE,
                                // then erase the original LINE in the same transaction.
                                p = new CadPolyline(2) { Layer = CadBridge.CleanLayer };
                                p.AddVertexAt(0, new Autodesk.AutoCAD.Geometry.Point2d(
                                    sourceLine.StartPoint.X, sourceLine.StartPoint.Y), 0, 0, 0);
                                p.AddVertexAt(1, new Autodesk.AutoCAD.Geometry.Point2d(
                                    sourceLine.EndPoint.X, sourceLine.EndPoint.Y), 0, 0, 0);
                                ms.UpgradeOpen();
                                ms.AppendEntity(p);
                                tr.AddNewlyCreatedDBObject(p, true);
                                sourceLine.Erase();
                            }
                            if (p == null) continue;
                            p.Layer = CadBridge.CleanLayer;
                            var updatedProfile = form.ResultProfile.Copy();
                            var existingProfile = CadBridge.ReadProfile(p);
                            // QHEDIT must not erase the metadata that lets
                            // QHBUILD recover square design vertices from
                            // auto-generated L-centerline bulge arcs.
                            if (existingProfile != null)
                            {
                                updatedProfile.ManagedLCurves = existingProfile.ManagedLCurves;
                                updatedProfile.RoadName = existingProfile.RoadName;
                            }
                            string newName;
                            if (roadNames.TryGetValue(id, out newName)) updatedProfile.RoadName = newName;
                            CadBridge.SaveProfile(doc.Database, tr, p, updatedProfile);
                            changed++;
                        }
                        tr.Commit();
                    }
                    RoadNameLabels.Refresh(doc.Database, Settings.CurveTolerance);
                    ed.WriteMessage("\nĐã gán mặt cắt cho " + changed
                        + " tim đường trên layer QH_TIM_DUONG_SACH. LINE đã được đổi thành PLINE. Chạy QHBUILD.");
                }
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        [CommandMethod("QHNAME")]
        public void RenameRoad()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var opt = new PromptEntityOptions("\nChọn tim đường cần đổi tên: ");
            opt.SetRejectMessage("\nChỉ chọn tim đường LWPOLYLINE.");
            opt.AddAllowedClass(typeof(CadPolyline), true);
            var pick = doc.Editor.GetEntity(opt);
            if (pick.Status != PromptStatus.OK) return;
            var input = doc.Editor.GetString(new PromptStringOptions("\nNhập tên tuyến mới (1–30 ký tự): ")
                { AllowSpaces = true });
            if (input.Status != PromptStatus.OK) return;
            string name = (input.StringResult ?? "").Trim();
            if (name.Length < 1 || name.Length > 30)
            { doc.Editor.WriteMessage("\nTên tuyến phải có 1–30 ký tự."); return; }
            try
            {
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var road = (CadPolyline)tr.GetObject(pick.ObjectId, OpenMode.ForWrite);
                    var profile = CadBridge.ReadProfile(road);
                    if (profile == null) throw new ArgumentException("Tim chưa được QHROADS đăng ký.");
                    profile.RoadName = name;
                    CadBridge.SaveProfile(doc.Database, tr, road, profile);
                    tr.Commit();
                }
                RoadNameLabels.Refresh(doc.Database, Settings.CurveTolerance);
                doc.Editor.WriteMessage("\nĐã đổi tên tuyến: " + name + ". Dùng QHMCBANG để thống kê.");
            }
            catch (System.Exception ex) { Report(doc.Editor, ex); }
        }

        [CommandMethod("QHBUILD")]
        public void BuildRoads()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            try
            {
                NetTopologySuite.Geometries.Polygon boundary;
                List<RoadInput> inputs;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var boundaryPline = CadBridge.TryReadBoundary(doc.Database, tr);
                    boundary = boundaryPline == null ? null : CadBridge.ToPolygon(boundaryPline, Settings.CurveTolerance);
                    inputs = CadBridge.RegisteredRoads(doc.Database, tr, Settings.CurveTolerance);
                }

                var result = new RoadGeometry().Build(boundary, inputs, Settings);
                // Toan bo ket qua duoc tinh xong truoc khi thay the layer dau ra.
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    CadBridge.EnsureLayers(doc.Database, tr);
                    CadBridge.UpdateAuthoritativeCenterlines(doc.Database, tr,
                        result.CleanedRoads, result.CenterlineCurves);
                    CadBridge.ReplaceGenerated(doc.Database, tr, result, result.ComputationSite, 0.005);
                    tr.Commit();
                }
                RoadNameLabels.Refresh(doc.Database, Settings.CurveTolerance);
                ed.WriteMessage("\nQHBUILD hoàn tất: " + inputs.Count + " tuyến, "
                    + result.Junctions.Count + " nút giao, " + result.ExtendedEndpoints + " đầu được nối.");
                ed.WriteMessage("\nTim L (một PLINE gấp 90°): đã bo " + result.CenterlineCurves.Count
                    + " góc bằng ARC/bulge native; tim tại nút T/X giữ nguyên.");
                ed.WriteMessage(result.BuildingLine == null
                    ? "\nChỉ giới xây dựng: lùi 0 m, trùng CGDD (không vẽ nét trùng)."
                    : "\nChỉ giới xây dựng: đã dựng trên layer QH_CHI_GIOI_XAY_DUNG, không thay đổi diện tích đường.");
                ed.WriteMessage((result.HasPlanningBoundary
                    ? "\nDiện tích theo chỉ giới đỏ (đã cắt ranh quy hoạch): "
                    : "\n[CẢNH BÁO] Diện tích theo chỉ giới đỏ (TẠM, chưa cắt ranh quy hoạch): ")
                    + result.RedLine.Area.ToString("N2") + " m2 ("
                    + (result.RedLine.Area / 10000.0).ToString("N4") + " ha).");
                ed.WriteMessage("\nBó vỉa được nhận dạng về cung ARC/bulge khi đủ điểm; các đoạn không nhận dạng vẫn là polyline mẫu.");
                foreach (var warning in result.Warnings.Take(25)) ed.WriteMessage("\n[CẢNH BÁO] " + warning);
                if (result.Warnings.Count > 25) ed.WriteMessage("\n... còn cảnh báo khác chưa hiển thị.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        [CommandMethod("QHTOL")]
        public void SetSnapTolerance()
        {
            var ed = AcadApp.DocumentManager.MdiActiveDocument.Editor;
            var opt = new PromptDoubleOptions("\nDung sai nối đầu tim đường vuông góc (m): ")
            { AllowNegative = false, AllowZero = false, DefaultValue = Settings.SnapTolerance, UseDefaultValue = true };
            var value = ed.GetDouble(opt);
            if (value.Status != PromptStatus.OK) return;
            if (value.Value > 20) { ed.WriteMessage("\nDung sai không được quá 20 m."); return; }
            Settings.SnapTolerance = value.Value;
            ed.WriteMessage("\nDung sai mới: " + Settings.SnapTolerance + " m.");
        }

        [CommandMethod("QHAREA")]
        public void RoadArea()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            try
            {
                NetTopologySuite.Geometries.Polygon boundary;
                List<RoadInput> roads;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var boundaryPline = CadBridge.TryReadBoundary(doc.Database, tr);
                    boundary = boundaryPline == null ? null : CadBridge.ToPolygon(boundaryPline, Settings.CurveTolerance);
                    roads = CadBridge.RegisteredRoads(doc.Database, tr, Settings.CurveTolerance);
                }
                var result = new RoadGeometry().Build(boundary, roads, Settings);
                doc.Editor.WriteMessage(result.HasPlanningBoundary
                    ? "\nĐẤT GIAO THÔNG (đã cắt ranh): "
                    : "\nDIỆN TÍCH SƠ BỘ (chưa cắt ranh): ");
                doc.Editor.WriteMessage(result.RedLine.Area.ToString("N2")
                    + " m2 = " + (result.RedLine.Area / 10000.0).ToString("N4") + " ha.");
                doc.Editor.WriteMessage("\nVùng mặt đường theo bó vỉa: " + result.Curb.Area.ToString("N2") + " m2.");
            }
            catch (System.Exception ex) { Report(doc.Editor, ex); }
        }

        [CommandMethod("QHHELP")]
        public void Help()
        {
            var ed = AcadApp.DocumentManager.MdiActiveDocument.Editor;
            ed.WriteMessage("\nCAD Planning Roads V2.0 / AutoCAD 2020-2024 (Windows)");
            ed.WriteMessage("\n1. QHSETUP: chọn ranh; nếu Open thì có thể đóng bản sao theo xác nhận.");
            ed.WriteMessage("\n2. QHROADS: chon LINE/LWPOLYLINE; ten N1, N2...; them lui CGXD trai/phai mac dinh 0m.");
            ed.WriteMessage("\n3. QHBUILD: tự bo cung thật tim chữ L (một PLINE 90°), phía lưng góc vuông; không bo tim nút T/X.");
            ed.WriteMessage("\n4. QHEDIT: sửa một tuyến / cùng mặt cắt / tất cả rồi chạy QHBUILD.");
            ed.WriteMessage("\n5. QHTOL: đổi dung sai nối đầu tim. QHAREA: diện tích đường.");
            ed.WriteMessage("\n6. QHLAND: nhận diện ô đất (PHẢI có ranh); QHZONE: gán chức năng.");
            ed.WriteMessage("\n7. QHLOT: chia mặt tiền/chiều sâu, 1/2 dãy, đường nội bộ; QHLABEL: block ATTRIB.");
            ed.WriteMessage("\n8. QHAUDIT: kiểm tra tổng diện tích, lô và chồng lấn.");
            ed.WriteMessage("\n9. QHEXPORT: xuất Excel .xlsx và đặt bảng tổng hợp trên CAD.");
            ed.WriteMessage("\n10. QHSHIFT: dịch 1 tuyến và cập nhật toàn mạng. QHCLCURVE: lệnh tương thích gọi QHBUILD.");
            ed.WriteMessage("\n11. QHLA: chon Lo va bam lien tuc trong vung kin, Enter de dung; Pline/Nhieu de chon net.");
            ed.WriteMessage("\n11a. QHTENLO (QHLOTNAME): nhap tien to CN.1., so bat dau 1, click nhan o sdd HOAC lo sdd2.");
            ed.WriteMessage("\n12. QHZONE: nhận mã CN.1, CN.10; QHLABEL: dùng block sdd/sdd2 mẫu DXF.");
            ed.WriteMessage("\n13. QHNAME: đổi tên đường. QHMCBANG: gom nhóm mặt cắt theo bề rộng.");
            ed.WriteMessage("\n14. QHMCGAN: block 2 dau net cat + PLINE dut; khi co CGXD, duong cat keo den hai CGXD.");
            ed.WriteMessage("\n14a. QHMCSCALE: sua co dau net cat/chu; QHMCFIX: sua huong cac block nhom cu, khong doi net dut.");
            ed.WriteMessage("\n15. QHMCVE: DIM 0.4m Arial, day -0.60/-0.20m, CGDD + CGXD offset, khong hoa gio.");
            ed.WriteMessage("\n16. QHSTYLE: tao QH_ARIAL va QH_DIM_040, khong doi style cua nguoi dung.");
            ed.WriteMessage("\n17. QHCHITIEU: nhap mat do/tang cao/FAR trong CAD, cap nhat nhan ngay.");
            ed.WriteMessage("\n18. QHSDDEXPORT: o me + lo con, cong thuc SUMIF/SUMIFS, 2 sheet lien ket; QHSDDIMPORT: nap lai G,H,I cua o me.");
            ed.WriteMessage("\n19. QHLABELSCALE: chon o/lo/ca hai; QHSCALEO va QHSCALELO: doi co nhan doc lap.");
            ed.WriteMessage("\nĐơn vị hình học phải là m. Lưu DWG dự phòng trước khi thử nghiệm.");
        }

        private static void Report(Editor ed, System.Exception ex)
        {
            ed.WriteMessage("\n[QH ROAD - LỖI] " + ex.Message
                + "\nHãy kiểm tra bản vẽ và chạy QHAUDIT khi có dữ liệu ô/lô."
                + " Lệnh lỗi trước khi commit transaction sẽ không lưu thay đổi CAD trong transaction đó.\n");
        }
    }
}
