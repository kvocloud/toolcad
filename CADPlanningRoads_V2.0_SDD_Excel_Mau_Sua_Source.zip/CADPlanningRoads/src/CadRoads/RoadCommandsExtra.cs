using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using NetTopologySuite.Geometries;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CadPolyline = Autodesk.AutoCAD.DatabaseServices.Polyline;

namespace QHPlanningRoads
{
    public sealed partial class Commands
    {
        // QHSHIFT translates one complete logical route. Its curb, redline,
        // median and surrounding road area are regenerated in ONE transaction.
        [CommandMethod("QHSHIFT")]
        public void ShiftEntireRoute()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            ObjectId selected = SelectRegisteredCenterline(ed);
            if (selected == ObjectId.Null) return;
            var options = new PromptKeywordOptions("\nDịch theo chiều vẽ tim sang [Left/Right] <Left>: ");
            options.Keywords.Add("Left"); options.Keywords.Add("Right");
            options.Keywords.Default = "Left";
            var direction = ed.GetKeywords(options);
            if (direction.Status != PromptStatus.OK) return;
            double distance;
            if (!ReadPositive(ed, "\nKhoảng cách dịch (m)", 2, out distance)) return;
            try
            {
                Polygon boundary;
                List<RoadInput> roads;
                string handle;
                Vector3d move;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var p = (CadPolyline)tr.GetObject(selected, OpenMode.ForRead);
                    handle = p.Handle.ToString();
                    var first = p.GetPoint2dAt(0);
                    var next = p.GetPoint2dAt(1);
                    double vx = next.X - first.X, vy = next.Y - first.Y;
                    double length = Math.Sqrt(vx * vx + vy * vy);
                    if (length < 1e-8)
                        throw new ArgumentException("Đầu tim không có đoạn xác định hướng trái/phải.");
                    double sign = direction.StringResult == "Left" ? 1 : -1;
                    move = new Vector3d(-vy / length * distance * sign,
                        vx / length * distance * sign, 0);
                    var boundaryLine = CadBridge.TryReadBoundary(doc.Database, tr);
                    boundary = boundaryLine == null ? null
                        : CadBridge.ToPolygon(boundaryLine, Settings.CurveTolerance);
                    roads = CadBridge.RegisteredRoads(doc.Database, tr, Settings.CurveTolerance);
                }
                RoadInput target = roads.FirstOrDefault(r => r.Handle == handle);
                if (target == null) throw new InvalidOperationException("Không tìm thấy dữ liệu tim đã đăng ký.");
                foreach (var point in target.Points)
                { point.X += move.X; point.Y += move.Y; }

                // Calculate and validate before mutating the DWG.
                var built = new RoadGeometry().Build(boundary, roads, Settings);
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var center = (CadPolyline)tr.GetObject(selected, OpenMode.ForWrite);
                    center.TransformBy(Matrix3d.Displacement(move));
                    CadBridge.EnsureLayers(doc.Database, tr);
                    CadBridge.UpdateAuthoritativeCenterlines(doc.Database, tr,
                        built.CleanedRoads, built.CenterlineCurves);
                    CadBridge.ReplaceGenerated(doc.Database, tr, built, built.ComputationSite, 0.005);
                    tr.Commit();
                }
                RoadNameLabels.Refresh(doc.Database, Settings.CurveTolerance);
                ed.WriteMessage("\nQHSHIFT: đã dịch tim và dựng lại toàn bộ đường theo vector ("
                    + move.X.ToString("0.###") + ", " + move.Y.ToString("0.###") + ") m."
                    + " Hãy làm mới ô/lô và chạy QHAUDIT nếu có thay đổi vị trí đường.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        // Kept for compatibility with prior instructions. QHBUILD now performs
        // exact native-arc centerline smoothing automatically for L turns.
        // Never fillet a T/X centerline or offset an already rounded L as a
        // replacement for the original squared road-surface design polygon.
        [CommandMethod("QHCLCURVE")]
        public void CurveSharpCenterlineBends()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            doc.Editor.WriteMessage("\nQHCLCURVE hiện được tích hợp vào QHBUILD: tự bo tim PLINE chữ L, giữ nguyên nút T/X.");
            BuildRoads();
        }

        private static ObjectId SelectRegisteredCenterline(Editor ed)
        {
            var opt = new PromptEntityOptions("\nChọn TIM PLINE đã đăng ký mặt cắt: ");
            opt.SetRejectMessage("\nChỉ chọn LWPOLYLINE tim đường.");
            opt.AddAllowedClass(typeof(CadPolyline), true);
            var selected = ed.GetEntity(opt);
            if (selected.Status != PromptStatus.OK) return ObjectId.Null;
            using (var tr = ed.Document.Database.TransactionManager.StartTransaction())
            {
                var center = (CadPolyline)tr.GetObject(selected.ObjectId, OpenMode.ForRead);
                if (center.Closed || CadBridge.ReadProfile(center) == null)
                {
                    ed.WriteMessage("\nTim chưa đăng ký. Chạy QHROADS trước.");
                    return ObjectId.Null;
                }
            }
            return selected.ObjectId;
        }
    }
}
