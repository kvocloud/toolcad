using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CadPolyline = Autodesk.AutoCAD.DatabaseServices.Polyline;

namespace QHPlanningRoads
{
    public sealed partial class Commands
    {
        private sealed class LandSheetRecord
        {
            public ObjectId Id;
            public string Handle, Code, DisplayCode, UseCode, ParentCode;
            public double Area;
            public LandMetadata Meta;
        }

        [CommandMethod("QHCHITIEU")]
        public void SetLandIndicators()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            ObjectId id = SelectBlock(ed);
            if (id == ObjectId.Null) return;
            try
            {
                LandMetadata current;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                    current = LandStore.Read((CadPolyline)tr.GetObject(id, OpenMode.ForRead));
                if (current == null || current.Kind != "BLOCK")
                    throw new ArgumentException("Khong phai o dat QH_O_DAT.");

                string density, floors, far;
                if (!AskIndicator(ed, "Mat do xay dung (%)", current.DensityPercent, 100, false, out density)
                    || !AskIndicator(ed, "So san/tang cao toi da", current.MaxFloors, 100, true, out floors)
                    || !AskIndicator(ed, "He so su dung dat (lan)", current.Far, 100, false, out far)) return;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var poly = (CadPolyline)tr.GetObject(id, OpenMode.ForRead);
                    current = LandStore.Read(poly);
                    current.DensityPercent = density;
                    current.MaxFloors = floors;
                    current.Far = far;
                    poly.UpgradeOpen();
                    LandStore.Save(doc.Database, tr, poly, current);
                    int updated = LandLabelBlocks.UpdateIndicators(doc.Database, tr,
                        current.Code, current);
                    tr.Commit();
                    ed.WriteMessage("\nDa luu 3 chi tieu cua " + current.Code
                        + "; cap nhat " + updated + " thuoc tinh nhan. Neu chua co nhan, chay QHLABEL.");
                }
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        private static bool AskIndicator(Editor ed, string label, string previous,
            double maximum, bool integer, out string value)
        {
            value = previous ?? "";
            var opt = new PromptStringOptions("\n" + label
                + " [so, '-' de xoa, '.' de giu nguyen] <.>: ") { AllowSpaces = false };
            var answer = ed.GetString(opt);
            if (answer.Status == PromptStatus.None) return true;
            if (answer.Status != PromptStatus.OK) return false;
            string input = (answer.StringResult ?? "").Trim();
            if (input == "." || input.Length == 0) return true;
            value = ValidateIndicator(input, maximum, integer);
            return true;
        }

        private static string ValidateIndicator(string input, double maximum, bool integer)
        {
            if (string.IsNullOrWhiteSpace(input) || input.Trim() == "-") return "";
            double result;
            if (!TryNumber(input, out result) || double.IsNaN(result)
                || double.IsInfinity(result) || result < 0 || result > maximum
                || (integer && Math.Abs(result - Math.Round(result)) > 0.000001))
                throw new ArgumentException("Chi tieu '" + input + "' khong hop le. Mat do nhap 70 de hieu 70%, khong nhap 0.7.");
            return result.ToString(integer ? "0" : "0.###", CultureInfo.InvariantCulture);
        }

        private static string UseDescription(string code)
        {
            if (string.Equals(code, "CHUA_GAN", StringComparison.OrdinalIgnoreCase)
                || string.IsNullOrWhiteSpace(code))
                return "Chưa gán chức năng sử dụng đất (QHZONE)";
            string prefix = (code ?? "").ToUpperInvariant().Split('.')[0];
            switch (prefix)
            {
                case "CN": case "CCN": return "Đất công nghiệp, kho tàng";
                case "ODT": return "Đất ở đô thị";
                case "CX": case "CXCL": return "Đất cây xanh";
                case "MN": return "Mặt nước";
                case "HT": case "HTKT": return "Đất hạ tầng kỹ thuật";
                case "TMDV": return "Đất thương mại dịch vụ";
                case "HCDV": return "Đất hành chính, dịch vụ";
                case "GT": return "Đất giao thông";
                case "CC": return "Đất công cộng";
                default: return ""; // unknown classification: user fills in Excel
            }
        }

        private static object IndicatorCell(
            Dictionary<string, Dictionary<string, string>> labels,
            LandMetadata m, string tag, string fallback)
        {
            string value = LandLabelBlocks.Get(labels, m.Code, tag, fallback);
            double number;
            return TryNumber(value, out number) && !double.IsNaN(number)
                && !double.IsInfinity(number) ? (object)number : null;
        }

        private static List<LandSheetRecord> ReadLandRecords(Database db, Transaction tr,
            double tolerance, Dictionary<string, Dictionary<string, string>> labels)
        {
            var rows = new List<LandSheetRecord>();
            foreach (var poly in LandStore.Polylines(db, tr, LandStore.BlockLayer))
            {
                var meta = LandStore.Read(poly);
                if (meta == null || meta.Kind != "BLOCK") continue;
                rows.Add(new LandSheetRecord {
                    Id = poly.ObjectId, Handle = poly.Handle.ToString(),
                    Code = meta.Code, DisplayCode = LandLabelBlocks.Get(labels,
                        meta.Code, "LOT_CODE", meta.Code), UseCode = meta.UseCode,
                    Meta = meta, Area = LandStore.ReconstructBlock(db, tr, poly, tolerance).Area
                });
            }
            // QHLABEL may rename a visible symbol; ordering uses stable CAD identifiers.
            return rows.OrderBy(x => x.Code, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static List<LandSheetRecord> ReadLotRecords(Database db, Transaction tr,
            double tolerance, Dictionary<string, Dictionary<string, string>> labels)
        {
            var rows = new List<LandSheetRecord>();
            foreach (var poly in LandStore.Polylines(db, tr, LandStore.LotLayer))
            {
                var meta = LandStore.Read(poly);
                if (meta == null || meta.Kind != "LOT") continue;
                rows.Add(new LandSheetRecord {
                    Id = poly.ObjectId, Handle = poly.Handle.ToString(),
                    Code = meta.Code,
                    DisplayCode = LandLabelBlocks.Get(labels, meta.Code, "LOT_CODE", meta.Code),
                    UseCode = meta.UseCode, ParentCode = meta.ParentCode,
                    Meta = meta, Area = CadBridge.ToPolygon(poly, tolerance).Area
                });
            }
            return rows.OrderBy(x => x.ParentCode, StringComparer.OrdinalIgnoreCase)
                .ThenBy(x => x.Code, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static ExcelWriter.FormulaCell Calc(string formula, double result)
        {
            return new ExcelWriter.FormulaCell(formula, result);
        }

        [CommandMethod("QHSDDEXPORT")]
        public void ExportLandUseTemplate()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            try
            {
                // Header/merges follow 285HA and GON from SuDungDat.xls.
                // Detail columns J:M preserve hidden CAD identity for import.
                var detail = new List<object[]> {
                    new object[] { "BẢNG THỐNG KÊ CHI TIẾT SỬ DỤNG ĐẤT" },
                    new object[] { "STT", "KÝ HIỆU", "CHỨC NĂNG SỬ DỤNG ĐẤT",
                        "TỔNG CỘNG", null, null, "MẬT ĐỘ XD (%)", "SỐ SÀN TỐI ĐA",
                        "HỆ SỐ SỬ DỤNG ĐẤT", "CAD_HANDLE", "CAD_KIND", "CAD_USE_CODE", "CAD_PARENT" },
                    new object[] { null, null, null, "DIỆN TÍCH TỔNG (M2)",
                        "DIỆN TÍCH (HA)", "TỶ LỆ (%)" },
                    new object[] { "TỔNG DIỆN TÍCH CÁC Ô ĐẤT (KHÔNG CỘNG LÔ CON)" }
                };
                var summary = new List<object[]> {
                    new object[] { "BẢNG TỔNG HỢP SỬ DỤNG ĐẤT" },
                    new object[] { "STT", "KÝ HIỆU", "CHỨC NĂNG SỬ DỤNG ĐẤT",
                        "TỔNG CỘNG", null, null, "MẬT ĐỘ XD (%)", "SỐ SÀN TỐI ĐA",
                        "HỆ SỐ SỬ DỤNG ĐẤT", "CAD_USE_CODE" },
                    new object[] { null, null, null, "DIỆN TÍCH TỔNG (M2)",
                        "DIỆN TÍCH (HA)", "TỶ LỆ (%)" },
                    new object[] { "TỔNG DIỆN TÍCH CÁC Ô ĐẤT (LIÊN KẾT BẢNG CHI TIẾT)" }
                };
                int parentCount = 0, lotCount = 0;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var labels = LandLabelBlocks.ReadAll(doc.Database, tr);
                    var records = ReadLandRecords(doc.Database, tr,
                        Settings.CurveTolerance, labels);
                    if (records.Count == 0) throw new ArgumentException("Chua co o dat QH_O_DAT.");
                    var lots = ReadLotRecords(doc.Database, tr, Settings.CurveTolerance, labels);
                    double denominator = records.Sum(r => r.Area);
                    if (denominator <= 0) throw new ArgumentException("Tong dien tich o dat khong hop le.");
                    var byParent = lots.GroupBy(r => r.ParentCode ?? "", StringComparer.OrdinalIgnoreCase)
                        .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);
                    var registered = new HashSet<string>(records.Select(r => r.Code),
                        StringComparer.OrdinalIgnoreCase);
                    double totalLotArea = 0;
                    for (int i = 0; i < records.Count; i++)
                    {
                        var r = records[i];
                        int parentExcelRow = detail.Count + 1;
                        detail.Add(new object[] { i+1, r.DisplayCode, UseDescription(r.UseCode),
                            r.Area, Calc("D" + parentExcelRow + "/10000", r.Area / 10000.0),
                            Calc("IFERROR(D" + parentExcelRow + "/$D$4*100,0)",
                                r.Area / denominator * 100.0),
                            IndicatorCell(labels, r.Meta, "DENSITY", r.Meta.DensityPercent),
                            IndicatorCell(labels, r.Meta, "FLOORS", r.Meta.MaxFloors),
                            IndicatorCell(labels, r.Meta, "FAR", r.Meta.Far), r.Handle,
                            "BLOCK", string.IsNullOrWhiteSpace(r.UseCode) ? "CHUA_GAN" : r.UseCode, "" });
                        List<LandSheetRecord> children;
                        if (!byParent.TryGetValue(r.Code, out children)) continue;
                        for (int j = 0; j < children.Count; j++)
                        {
                            var lot = children[j];
                            int lotExcelRow = detail.Count + 1;
                            detail.Add(new object[] { (i + 1) + "." + (j + 1),
                                lot.DisplayCode, UseDescription(string.IsNullOrWhiteSpace(lot.UseCode)
                                    ? r.UseCode : lot.UseCode), lot.Area,
                                Calc("D" + lotExcelRow + "/10000", lot.Area / 10000.0),
                                null, null, null, null, lot.Handle, "LOT",
                                string.IsNullOrWhiteSpace(lot.UseCode) ? r.UseCode : lot.UseCode,
                                r.Code });
                            totalLotArea += lot.Area;
                            lotCount++;
                        }
                    }
                    // Orphan lots must not silently disappear from an exported audit.
                    foreach (var lot in lots.Where(l => !registered.Contains(l.ParentCode ?? "")))
                    {
                        int excelRow = detail.Count + 1;
                        detail.Add(new object[] { "!", lot.DisplayCode,
                            "Lô chưa liên kết ô mẹ", lot.Area,
                            Calc("D" + excelRow + "/10000", lot.Area / 10000.0),
                            null, null, null, null, lot.Handle, "LOT", lot.UseCode, lot.ParentCode });
                        totalLotArea += lot.Area;
                        lotCount++;
                    }
                    parentCount = records.Count;
                    int lastDataRow = detail.Count;
                    string kindRange = "$K$5:$K$" + lastDataRow;
                    string areaRange = "$D$5:$D$" + lastDataRow;
                    // D4 always totals only the parent plots, never nested sublots.
                    detail[3] = new object[] { "TỔNG DIỆN TÍCH CÁC Ô ĐẤT (KHÔNG CỘNG LÔ CON)",
                        null, null,
                        Calc("SUMIF(" + kindRange + ",\"BLOCK\"," + areaRange + ")", denominator),
                        Calc("D4/10000", denominator / 10000.0),
                        Calc("IF(D4>0,100,0)", 100.0),
                        null, null, null, null, null, null, null };
                    int lotsTotalRow = detail.Count + 1;
                    detail.Add(new object[] { null, "TỔNG DIỆN TÍCH LÔ CON (THAM KHẢO)", "",
                        Calc("SUMIF(" + kindRange + ",\"LOT\"," + areaRange + ")", totalLotArea),
                        Calc("D" + lotsTotalRow + "/10000", totalLotArea / 10000.0),
                        null, null, null, null, null, null, null, null });
                    var groups = records.GroupBy(r => string.IsNullOrWhiteSpace(r.UseCode)
                            ? "CHUA_GAN" : r.UseCode, StringComparer.OrdinalIgnoreCase)
                        .OrderBy(g => g.Key, StringComparer.OrdinalIgnoreCase).ToList();
                    string detailSheet = "'Bang SDD'!";
                    summary[3] = new object[] {
                        "TỔNG DIỆN TÍCH CÁC Ô ĐẤT (LIÊN KẾT BẢNG CHI TIẾT)", null, null,
                        Calc(detailSheet + "D4", denominator),
                        Calc(detailSheet + "E4", denominator / 10000.0),
                        Calc("IF(D4>0,100,0)", 100.0)
                    };
                    for (int i = 0; i < groups.Count; i++)
                    {
                        double area = groups[i].Sum(r => r.Area);
                        int rowNo = summary.Count + 1;
                        string visibleCode = string.Equals(groups[i].Key, "CHUA_GAN",
                            StringComparison.OrdinalIgnoreCase) ? "CHƯA GÁN" : groups[i].Key;
                        summary.Add(new object[] { i+1, visibleCode,
                            UseDescription(groups[i].Key),
                            Calc("SUMIFS(" + detailSheet + areaRange + ","
                                + detailSheet + kindRange + ",\"BLOCK\","
                                + detailSheet + "$L$5:$L$" + lastDataRow + ",J" + rowNo + ")", area),
                            Calc("D" + rowNo + "/10000", area / 10000.0),
                            Calc("IFERROR(D" + rowNo + "/$D$4*100,0)",
                                area / denominator * 100.0), null, null, null, groups[i].Key });
                    }
                    int summaryTotal = summary.Count + 1;
                    int lastSummary = summary.Count;
                    summary.Add(new object[] { null, "TỔNG", "",
                        Calc("SUM(D5:D" + lastSummary + ")", denominator),
                        Calc("D" + summaryTotal + "/10000", denominator / 10000.0),
                        Calc("IFERROR(D" + summaryTotal + "/$D$4*100,0)", 100.0),
                        null, null, null });
                }
                var file = ed.GetFileNameForSave(new PromptSaveFileOptions(
                    "\nLuu bang thong ke su dung dat .xlsx: ") {
                        Filter = "Excel workbook (*.xlsx)|*.xlsx"
                    });
                if (file.Status != PromptStatus.OK) return;
                string filename = Path.ChangeExtension(file.StringResult, ".xlsx");
                if (File.Exists(filename) && !Confirm(ed,
                    "\nFile da ton tai. Ghi de? [Overwrite/Cancel] <Cancel>: ",
                    "Overwrite", "Cancel")) return;
                ExcelWriter.WriteLandUse(filename, detail, summary);
                ed.WriteMessage("\nDa xuat " + parentCount + " o me va " + lotCount + " lo con: " + filename
                    + "\nTỷ lệ (%) chia cho tổng diện tích các ô mẹ, không tính trùng lô con hoặc đất đường."
                    + "\nMau SuDungDat.xls: tieu de 2 hang, cac lo con nam ngay duoi o me."
                    + "\nBang SDD D4 = SUMIF, Tong hop SDD D4/E4 lien ket va cac nhom = SUMIFS."
                    + "\nChỉ sửa cột G,H,I, không sửa B,D,J (mã, diện tích, CAD_HANDLE)."
                    + " Sau đó chạy QHSDDIMPORT.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        [CommandMethod("QHSDDIMPORT")]
        public void ImportLandIndicators()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            var choice = ed.GetFileNameForOpen(new PromptOpenFileOptions(
                "\nChon file .xlsx do QHSDDEXPORT tao va da sua cot G,H,I: ") {
                    Filter = "Excel workbook (*.xlsx)|*.xlsx"
                });
            if (choice.Status != PromptStatus.OK) return;
            try
            {
                var inputs = ExcelReader.ReadLandIndicators(choice.StringResult);
                // Validate EVERY row before opening a write transaction.
                var planned = new List<Tuple<ObjectId, string, string, string>>();
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var labels = LandLabelBlocks.ReadAll(doc.Database, tr);
                    var records = ReadLandRecords(doc.Database, tr, Settings.CurveTolerance, labels)
                        .ToDictionary(r => r.Handle, StringComparer.OrdinalIgnoreCase);
                    foreach (var row in inputs)
                    {
                        LandSheetRecord found;
                        if (!records.TryGetValue(row.Handle, out found))
                            throw new ArgumentException("Excel dong " + row.ExcelRow
                                + ": CAD_HANDLE khong tim thay. File cu hoac o da duoc ve lai.");
                        double oldArea;
                        if (!string.Equals(row.Code, found.DisplayCode, StringComparison.OrdinalIgnoreCase)
                            || !TryNumber(row.Area, out oldArea)
                            || Math.Abs(oldArea - found.Area) > Math.Max(0.05, found.Area * 0.000001))
                            throw new ArgumentException("Excel dong " + row.ExcelRow
                                + ": ma hoac dien tich da thay doi. Hay xuat Excel moi.");
                        planned.Add(Tuple.Create(found.Id,
                            ValidateIndicator(row.Density, 100, false),
                            ValidateIndicator(row.Floors, 100, true),
                            ValidateIndicator(row.Far, 100, false)));
                    }
                }
                if (!Confirm(ed, "\nDa kiem tra " + planned.Count
                    + " o dat. Cap nhat 3 chi tieu tu Excel vao CAD? [Apply/Cancel] <Cancel>: ",
                    "Apply", "Cancel")) return;
                int updates = 0;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    foreach (var item in planned)
                    {
                        var poly = (CadPolyline)tr.GetObject(item.Item1, OpenMode.ForWrite);
                        var meta = LandStore.Read(poly);
                        if (meta == null || meta.Kind != "BLOCK")
                            throw new ArgumentException("O dat da thay doi trong khi import.");
                        meta.DensityPercent = item.Item2;
                        meta.MaxFloors = item.Item3;
                        meta.Far = item.Item4;
                        LandStore.Save(doc.Database, tr, poly, meta);
                        LandLabelBlocks.UpdateIndicators(doc.Database, tr, meta.Code, meta);
                        updates++;
                    }
                    tr.Commit();
                }
                ed.WriteMessage("\nQHSDDIMPORT hoan tat " + updates
                    + " o dat. Da cap nhat XData va thuoc tinh block nhan; chay QHAUDIT.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }
    }
}
