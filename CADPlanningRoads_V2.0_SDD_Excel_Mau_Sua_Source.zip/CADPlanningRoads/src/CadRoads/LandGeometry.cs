using System;
using System.Collections.Generic;
using System.Linq;
using NetTopologySuite.Geometries;
using NetTopologySuite.Operation.Union;

namespace QHPlanningRoads
{
    internal sealed class LotSplitOptions
    {
        public double Frontage = 8;
        public double Depth = 20;
        public bool TwoRows;
        public bool AccessRoad;
        public double AccessRoadWidth;
        public double MinArea = 80;
    }

    internal sealed class LotSplitCell
    {
        public Polygon Shape;
        public bool Corner;
        public int Row; // 1: front, 2: opposite frontage
    }

    internal sealed class LotSplitPlan
    {
        public readonly List<LotSplitCell> Lots = new List<LotSplitCell>();
        public readonly List<Polygon> InternalRoads = new List<Polygon>();
        public readonly List<Polygon> Remainders = new List<Polygon>();
        public readonly List<string> Warnings = new List<string>();
    }

    // Geometry-only planning operations, independent from AutoCAD.
    internal static class LandGeometry
    {
        private static readonly GeometryFactory Gf = new GeometryFactory();

        public static List<Polygon> FindLandBlocks(Polygon site, Geometry roadRedline,
            double minBlockArea = 1.0)
        {
            if (site == null || !site.IsValid || site.Area <= 0)
                throw new ArgumentException("Phải có ranh quy hoạch hợp lệ để tạo ô đất.");
            if (roadRedline == null || !roadRedline.IsValid)
                throw new ArgumentException("Vùng giao thông không hợp lệ.");
            Geometry left = site.Difference(roadRedline);
            if (!left.IsValid) throw new InvalidOperationException("Ô đất sau khi trừ đường bị lỗi topo.");
            return Polygons(left).Where(p => p.Area >= minBlockArea)
                .OrderBy(p => p.Centroid.Coordinate.X).ThenBy(p => p.Centroid.Coordinate.Y)
                .ToList();
        }

        // MVP deliberately supports blocks without holes, with a full-length
        // straight frontage edge. Complex blocks must be manually partitioned.
        public static List<Polygon> SplitByFrontage(Polygon land, Coordinate a, Coordinate b,
            double targetFrontage, double minFrontage, double minArea,
            double minAverageDepth)
        {
            if (land == null || !land.IsValid || land.IsEmpty)
                throw new ArgumentException("Ô đất không hợp lệ.");
            if (land.NumInteriorRings > 0)
                throw new ArgumentException("Ô đất có lỗ rỗng: cần tách ô phụ trước khi chia lô tự động.");
            if (targetFrontage <= 0 || minFrontage <= 0 || minArea <= 0 || minAverageDepth <= 0)
                throw new ArgumentException("Các chỉ tiêu chia lô phải lớn hơn 0.");

            double dx = b.X - a.X, dy = b.Y - a.Y;
            double length = Math.Sqrt(dx * dx + dy * dy);
            if (length < minFrontage - 1e-7)
                throw new ArgumentException("Cạnh mặt tiền nhỏ hơn mặt tiền tối thiểu.");
            double ux = dx / length, uy = dy / length;
            double nx = -uy, ny = ux;

            // The chosen frontage must span the polygon's entire projected width.
            // Otherwise a 2D strip could create lots with no street access.
            foreach (var pt in land.ExteriorRing.Coordinates)
            {
                double u = (pt.X - a.X) * ux + (pt.Y - a.Y) * uy;
                if (u < -0.05 || u > length + 0.05)
                    throw new ArgumentException("Cạnh mặt tiền không phủ hết chiều ngang ô đất. Chọn cạnh khác hoặc chia ô thủ công.");
            }

            int count = Math.Max(1, (int)Math.Round(length / targetFrontage));
            while (count > 1 && length / count < minFrontage) count--;
            if (count > 500)
                throw new ArgumentException("Số lô một ô vượt 500. Hãy chia ô thành các ô phụ trước.");
            double step = length / count;
            if (step < minFrontage - 1e-7) throw new ArgumentException("Mặt tiền từng lô nhỏ hơn giới hạn.");

            var envelope = land.EnvelopeInternal;
            double far = Math.Sqrt(envelope.Width * envelope.Width
                + envelope.Height * envelope.Height) * 4 + 100;
            var result = new List<Polygon>();
            for (int i = 0; i < count; i++)
            {
                double u0 = step * i, u1 = i == count - 1 ? length : step * (i + 1);
                var p0 = new Coordinate(a.X + ux * u0, a.Y + uy * u0);
                var p1 = new Coordinate(a.X + ux * u1, a.Y + uy * u1);
                var strip = Gf.CreatePolygon(new[] {
                    new Coordinate(p0.X - nx * far, p0.Y - ny * far),
                    new Coordinate(p1.X - nx * far, p1.Y - ny * far),
                    new Coordinate(p1.X + nx * far, p1.Y + ny * far),
                    new Coordinate(p0.X + nx * far, p0.Y + ny * far),
                    new Coordinate(p0.X - nx * far, p0.Y - ny * far)
                });
                var cells = Polygons(land.Intersection(strip)).Where(p => p.Area > 0.001).ToList();
                if (cells.Count != 1)
                    throw new InvalidOperationException("Đường chia tạo lô rời/đa phần. Cần chọn cạnh hoặc điều chỉnh chia thủ công.");
                var lot = cells[0];
                if (!lot.IsValid || lot.Area < minArea)
                    throw new InvalidOperationException("Lô " + (i + 1) + " không đạt diện tích tối thiểu.");
                var actualFrontage = lot.Boundary.Intersection(Gf.CreateLineString(new[] { p0, p1 })).Length;
                if (actualFrontage + 0.01 < u1 - u0)
                    throw new InvalidOperationException("Lô " + (i + 1)
                        + " không tiếp xúc đủ mặt tiền đường đã chọn.");
                // This is AVERAGE depth, not a verified minimum local depth.
                if (lot.Area / (u1 - u0) < minAverageDepth)
                    throw new InvalidOperationException("Lô " + (i + 1) + " không đạt chiều sâu bình quân tối thiểu.");
                result.Add(lot);
            }
            var united = UnaryUnionOp.Union(result.Cast<Geometry>().ToList());
            if (united.SymmetricDifference(land).Area > Math.Max(0.01, land.Area * 0.00001))
                throw new InvalidOperationException("Tổng diện tích các lô không bằng diện tích ô đất.");
            return result;
        }

        public static IEnumerable<Polygon> Polygons(Geometry shape)
        {
            if (shape == null || shape.IsEmpty) yield break;
            var one = shape as Polygon;
            if (one != null) { yield return one; yield break; }
            for (int i = 0; i < shape.NumGeometries; i++)
            {
                var sub = shape.GetGeometryN(i);
                if (Object.ReferenceEquals(shape, sub)) continue;
                foreach (var poly in Polygons(sub)) yield return poly;
            }
        }

        // CAD-08 v2: middle lots follow exact width/depth, irregular leftovers go
        // to side-corner lots. A back-to-back option builds a second row. Every
        // square metre belongs to LOT, INTERNAL_ROAD or REMAINDER (no silent loss).
        public static LotSplitPlan SplitByWidthAndDepth(Polygon land, Coordinate a,
            Coordinate b, LotSplitOptions options)
        {
            if (land == null || land.IsEmpty || !land.IsValid || land.NumInteriorRings != 0)
                throw new ArgumentException("Ô đất phải là polygon hợp lệ, chưa hỗ trợ ô có lỗ.");
            if (options == null || options.Frontage <= 0 || options.Depth <= 0 || options.MinArea < 0)
                throw new ArgumentException("Mặt tiền, chiều sâu phải dương và diện tích tối thiểu không âm.");
            if (options.AccessRoad && (!options.TwoRows || options.AccessRoadWidth <= 0))
                throw new ArgumentException("Đường giữa chỉ dùng khi chia hai dãy; bề rộng đường phải dương.");

            double dx = b.X - a.X, dy = b.Y - a.Y;
            double length = Math.Sqrt(dx * dx + dy * dy);
            if (length < 0.1) throw new ArgumentException("Cạnh mặt tiền không đủ dài.");
            double ux = dx / length, uy = dy / length;
            double nx = -uy, ny = ux;
            var centroid = land.Centroid.Coordinate;
            if ((centroid.X - a.X) * nx + (centroid.Y - a.Y) * ny < 0)
            { nx = -nx; ny = -ny; }
            double minU = double.MaxValue, maxU = double.MinValue;
            double minV = double.MaxValue, maxV = double.MinValue;
            foreach (var c in land.ExteriorRing.Coordinates)
            {
                double u = (c.X - a.X) * ux + (c.Y - a.Y) * uy;
                double v = (c.X - a.X) * nx + (c.Y - a.Y) * ny;
                minU = Math.Min(minU, u); maxU = Math.Max(maxU, u);
                minV = Math.Min(minV, v); maxV = Math.Max(maxV, v);
            }
            if (minV < -0.1)
                throw new ArgumentException("Cạnh mặt tiền được chọn không nằm ở rìa trước của ô. Hãy chọn cạnh khác.");
            if (maxV <= options.Depth * 0.5)
                throw new ArgumentException("Chiều sâu ô quá nhỏ so với chiều sâu đã nhập.");

            int middleCount = (int)Math.Floor((length + 0.000001) / options.Frontage);
            if (middleCount > 500)
                throw new ArgumentException("Số lô giữa vượt 500, cần tách ô phụ.");
            double side = (length - middleCount * options.Frontage) / 2.0;
            var plan = new LotSplitPlan();
            if (middleCount == 0)
                plan.Warnings.Add("Mặt tiền ngắn hơn kích thước chọn: toàn bộ hàng sẽ thành lô góc.");

            // A small outward pad covers digitization noise near the frontage.
            double fromFront = minV - 0.01;
            var rows = new List<Tuple<double, double, int>>();
            rows.Add(Tuple.Create(fromFront, Math.Min(options.Depth, maxV), 1));
            double rearStart = 0;
            if (options.TwoRows)
            {
                rearStart = maxV - options.Depth;
                if (rearStart < options.Depth + (options.AccessRoad ? options.AccessRoadWidth : 0) - 0.01)
                    throw new ArgumentException("Ô không đủ chiều sâu cho 2 dãy và đường giữa với các kích thước đã nhập.");
                rows.Add(Tuple.Create(rearStart, maxV, 2));
            }

            double boundMinU = minU - 0.01, boundMaxU = maxU + 0.01;
            foreach (var row in rows)
            {
                // Outer corners can have any frontage; only central cells target
                // the exact chosen frontage. Side remainders are included as lots.
                AddLotCell(plan, land, a, ux, uy, nx, ny,
                    boundMinU, side, row.Item1, row.Item2, true, row.Item3, options.MinArea);
                for (int i = 0; i < middleCount; i++)
                    AddLotCell(plan, land, a, ux, uy, nx, ny,
                        side + i * options.Frontage, side + (i + 1) * options.Frontage,
                        row.Item1, row.Item2, false, row.Item3, options.MinArea);
                AddLotCell(plan, land, a, ux, uy, nx, ny,
                    side + middleCount * options.Frontage, boundMaxU,
                    row.Item1, row.Item2, true, row.Item3, options.MinArea);
            }

            if (options.TwoRows)
            {
                if (options.AccessRoad)
                {
                    double middleV = (options.Depth + rearStart) / 2.0;
                    double lowerRoad = middleV - options.AccessRoadWidth / 2.0;
                    double upperRoad = middleV + options.AccessRoadWidth / 2.0;
                    AddParts(plan.InternalRoads, Clip(land, a, ux, uy, nx, ny,
                        boundMinU, boundMaxU, lowerRoad, upperRoad));
                    AddParts(plan.Remainders, Clip(land, a, ux, uy, nx, ny,
                        boundMinU, boundMaxU, options.Depth, lowerRoad));
                    AddParts(plan.Remainders, Clip(land, a, ux, uy, nx, ny,
                        boundMinU, boundMaxU, upperRoad, rearStart));
                }
                else AddParts(plan.Remainders, Clip(land, a, ux, uy, nx, ny,
                    boundMinU, boundMaxU, options.Depth, rearStart));
            }
            else AddParts(plan.Remainders, Clip(land, a, ux, uy, nx, ny,
                boundMinU, boundMaxU, options.Depth, maxV + 0.01));

            if (plan.Lots.Count == 0)
                throw new ArgumentException("Không tạo được lô trong phần mặt tiền đã chọn.");
            var pieces = new List<Geometry>();
            pieces.AddRange(plan.Lots.Select(x => (Geometry)x.Shape));
            pieces.AddRange(plan.InternalRoads.Cast<Geometry>());
            pieces.AddRange(plan.Remainders.Cast<Geometry>());
            Geometry union = UnaryUnionOp.Union(pieces);
            double discrepancy = union.SymmetricDifference(land).Area;
            if (discrepancy > Math.Max(0.02, land.Area * 0.00002))
                throw new InvalidOperationException("Sai lệch chia ô " + discrepancy.ToString("0.###")
                    + " m2; không lưu để tránh mất diện tích.");
            if (plan.Remainders.Count > 0)
                plan.Warnings.Add("Còn vùng chưa chia giữa/sau các dãy; xem layer QH_DAT_CHUA_CHIA.");
            return plan;
        }

        private static void AddLotCell(LotSplitPlan plan, Polygon land, Coordinate a,
            double ux, double uy, double nx, double ny, double u0, double u1,
            double v0, double v1, bool corner, int row, double minArea)
        {
            foreach (var poly in Polygons(Clip(land, a, ux, uy, nx, ny, u0, u1, v0, v1)))
            {
                if (poly.Area < 0.01) continue;
                if (poly.NumInteriorRings > 0)
                    throw new ArgumentException("Lô sau chia có lỗ rỗng; cần chia thủ công.");
                if (poly.Area < minArea)
                    plan.Warnings.Add("Lô hàng " + row + (corner ? " (góc)" : " (giữa)")
                        + " chưa đạt diện tích tối thiểu: " + poly.Area.ToString("0.##") + " m2.");
                plan.Lots.Add(new LotSplitCell { Shape = poly, Corner = corner, Row = row });
            }
        }

        private static Geometry Clip(Polygon land, Coordinate a, double ux, double uy,
            double nx, double ny, double u0, double u1, double v0, double v1)
        {
            if (u1 - u0 <= 1e-7 || v1 - v0 <= 1e-7)
                return Gf.CreateGeometryCollection(new Geometry[0]);
            var p = new[] {
                At(a, ux, uy, nx, ny, u0, v0), At(a, ux, uy, nx, ny, u1, v0),
                At(a, ux, uy, nx, ny, u1, v1), At(a, ux, uy, nx, ny, u0, v1),
                At(a, ux, uy, nx, ny, u0, v0)
            };
            return land.Intersection(Gf.CreatePolygon(p));
        }

        private static Coordinate At(Coordinate a, double ux, double uy, double nx,
            double ny, double u, double v)
        {
            return new Coordinate(a.X + ux * u + nx * v, a.Y + uy * u + ny * v);
        }

        private static void AddParts(List<Polygon> target, Geometry g)
        {
            foreach (var part in Polygons(g))
                if (part.Area > 0.01)
                {
                    if (part.NumInteriorRings > 0)
                        throw new ArgumentException("Vùng còn lại có lỗ rỗng; cần chia ô thủ công.");
                    target.Add(part);
                }
        }
    }
}
