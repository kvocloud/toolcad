using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using NetTopologySuite.Geometries;

namespace QHPlanningRoads
{
    internal sealed class RoadProfile
    {
        // Tim duong nam giua dai phan cach (neu co), huong trai/phai theo chieu ve polyline.
        public double LaneLeft = 3.5;
        public double LaneRight = 3.5;
        public double SidewalkLeft = 3.0;
        public double SidewalkRight = 3.0;
        public double Median = 0.0;
        public double CurbRadius = 8.0;
        public double RedChamfer = 6.0;
        public double MedianSetback = 20.0; // Khoang lui mui dai giua tinh tu tam nut giao.
        // Khoang lui chi gioi xay dung tinh tu chi gioi duong do ra phia o dat.
        public double BuildingSetbackLeft = 0.0;
        public double BuildingSetbackRight = 0.0;
        // Internal geometry flag: QHBUILD owns L-corner native bulge arcs.
        // Kept in the section XData so a second QHBUILD can recover the original
        // right-angle design vertex instead of offsetting the already curved tim.
        public bool ManagedLCurves = false;
        public string RoadName = "";

        public double CurbLeft { get { return Median / 2.0 + LaneLeft; } }
        public double CurbRight { get { return Median / 2.0 + LaneRight; } }
        public double RedLeft { get { return CurbLeft + SidewalkLeft; } }
        public double RedRight { get { return CurbRight + SidewalkRight; } }
        public double RightOfWay { get { return RedLeft + RedRight; } }

        public string WidthSignature()
        {
            // Five components, ordered from the left red line to the right.
            // Node radii and road name do not change the cross-section shape.
            return string.Join("|", new[] { SidewalkLeft, LaneLeft,
                Median, LaneRight, SidewalkRight,
                BuildingSetbackLeft, BuildingSetbackRight }.SelectInvariant());
        }

        public RoadProfile Copy() { return (RoadProfile)MemberwiseClone(); }

        public bool SameSection(RoadProfile p)
        {
            return Near(LaneLeft, p.LaneLeft) && Near(LaneRight, p.LaneRight)
                && Near(SidewalkLeft, p.SidewalkLeft) && Near(SidewalkRight, p.SidewalkRight)
                && Near(Median, p.Median) && Near(CurbRadius, p.CurbRadius)
                && Near(RedChamfer, p.RedChamfer)
                && Near(MedianSetback, p.MedianSetback)
                && Near(BuildingSetbackLeft, p.BuildingSetbackLeft)
                && Near(BuildingSetbackRight, p.BuildingSetbackRight);
        }

        private static bool Near(double a, double b) { return Math.Abs(a - b) < 0.00001; }

        public void Validate()
        {
            if (LaneLeft <= 0 || LaneRight <= 0 || SidewalkLeft < 0 || SidewalkRight < 0 || Median < 0
                || CurbRadius < 0 || RedChamfer < 0 || MedianSetback < 0
                || MedianSetback > 1000 || RightOfWay > 200
                || BuildingSetbackLeft < 0 || BuildingSetbackRight < 0
                || BuildingSetbackLeft > 200 || BuildingSetbackRight > 200
                || (RoadName ?? "").Length > 30)
                throw new ArgumentException("Thông số mặt cắt không hợp lệ. Đơn vị sử dụng: mét.");
        }

        public string Serialize()
        {
            string serialized = string.Join(";", new[] { LaneLeft, LaneRight, SidewalkLeft, SidewalkRight, Median, CurbRadius, RedChamfer, MedianSetback,
                BuildingSetbackLeft, BuildingSetbackRight }
                .SelectInvariant()) + ";" + (ManagedLCurves ? "1" : "0")
                + ";" + Convert.ToBase64String(Encoding.UTF8.GetBytes(RoadName ?? ""));
            if (serialized.Length > 250)
                throw new ArgumentException("Tên tuyến quá dài để lưu vào metadata AutoCAD.");
            return serialized;
        }

        public static RoadProfile Parse(string value)
        {
            var result = new RoadProfile();
            var fields = (value ?? "").Split(';');
            if (fields.Length != 7 && fields.Length != 8
                && fields.Length != 9 && fields.Length != 10 && fields.Length != 12) return result;
            int numericLength = Math.Min(fields.Length, 8);
            double[] nums = new double[numericLength];
            for (int i = 0; i < numericLength; i++)
                if (!double.TryParse(fields[i], NumberStyles.Float, CultureInfo.InvariantCulture, out nums[i]))
                    return result;
            result.LaneLeft = nums[0]; result.LaneRight = nums[1];
            result.SidewalkLeft = nums[2]; result.SidewalkRight = nums[3];
            result.Median = nums[4]; result.CurbRadius = nums[5]; result.RedChamfer = nums[6];
            if (nums.Length >= 8) result.MedianSetback = nums[7];
            if (fields.Length == 12)
            {
                if (!double.TryParse(fields[8], NumberStyles.Float, CultureInfo.InvariantCulture, out result.BuildingSetbackLeft)
                    || !double.TryParse(fields[9], NumberStyles.Float, CultureInfo.InvariantCulture, out result.BuildingSetbackRight))
                    return new RoadProfile();
            }
            if (fields.Length >= 9) result.ManagedLCurves = fields[fields.Length == 12 ? 10 : 8] == "1";
            if (fields.Length == 10 || fields.Length == 12)
            {
                try { result.RoadName = Encoding.UTF8.GetString(Convert.FromBase64String(fields[fields.Length == 12 ? 11 : 9])); }
                catch (FormatException) { result.RoadName = ""; }
            }
            result.Validate();
            return result;
        }
    }

    internal static class EnumerableExtensions
    {
        public static IEnumerable<string> SelectInvariant(this IEnumerable<double> source)
        {
            foreach (var number in source) yield return number.ToString("R", CultureInfo.InvariantCulture);
        }
    }

    internal sealed class RoadInput
    {
        public string Handle;
        public string RoadCode;
        public RoadProfile Profile;
        public List<Coordinate> Points;
        // A centerline with user-authored ARC/bulge segments is left as drawn.
        // Automated L smoothing is only applied to straight polyline input.
        public bool HasUnmanagedArcs;
    }

    internal sealed class CenterlineCurve
    {
        public string Handle;
        public int VertexIndex;
        public Coordinate Entry;
        public Coordinate Exit;
        public double Bulge;
        public double CenterlineRadius;
    }

    internal sealed class ProjectSettings
    {
        public double SnapTolerance = 1.5;
        public double CurveTolerance = 0.02; // Dung sai roi rac hoa cung trong xu ly topology (m).
        public int MinAngle = 65;
        public int MaxAngle = 115;
    }

    internal sealed class BuildResult
    {
        // The planning boundary may be absent during concept design. In that case
        // ComputationSite is only a generous temporary envelope, not an approved site.
        public Polygon ComputationSite;
        public bool HasPlanningBoundary;
        public Geometry Curb;
        public Geometry RedLine;
        public Geometry BuildingLine;
        public Geometry Median;
        public List<RoadInput> CleanedRoads = new List<RoadInput>();
        public List<CenterlineCurve> CenterlineCurves = new List<CenterlineCurve>();
        public List<Coordinate> Junctions = new List<Coordinate>();
        public List<string> Warnings = new List<string>();
        public int ExtendedEndpoints;
    }
}
