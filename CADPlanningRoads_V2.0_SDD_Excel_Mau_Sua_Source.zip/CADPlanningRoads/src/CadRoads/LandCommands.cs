using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using NetTopologySuite.Geometries;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CadPolyline = Autodesk.AutoCAD.DatabaseServices.Polyline;
using NtsPolygon = NetTopologySuite.Geometries.Polygon;

namespace QHPlanningRoads
{
    public sealed partial class Commands
    {
        // CAD-06: remaining land blocks after deducting the red-line roadway.
        [CommandMethod("QHLAND")]
        public void DetectLandBlocks()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            try
            {
                NtsPolygon boundary;
                List<RoadInput> roads;
                bool existing;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    boundary = CadBridge.ToPolygon(CadBridge.ReadBoundary(doc.Database, tr), Settings.CurveTolerance);
                    roads = CadBridge.RegisteredRoads(doc.Database, tr, Settings.CurveTolerance);
                    existing = LandStore.Polylines(doc.Database, tr, LandStore.BlockLayer).Count > 0
                        || LandStore.Polylines(doc.Database, tr, LandStore.LotLayer).Count > 0;
                }
                if (existing && !Confirm(ed,
                    "\nĐã có ô đất/lô đất. TẠO LẠI sẽ mất chức năng và phân lô cũ. [Replace/Cancel] <Cancel>: ",
                    "Replace", "Cancel")) return;

                var built = new RoadGeometry().Build(boundary, roads, Settings);
                var blocks = LandGeometry.FindLandBlocks(boundary, built.RedLine);
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    LandStore.EnsureLayers(doc.Database, tr);
                    LandStore.ClearManaged(doc.Database, tr, LandStore.BlockLayer,
                        LandStore.HoleLayer, LandStore.LotLayer, LandStore.LabelLayer,
                        LandStore.TableLayer, LandStore.AccessRoadLayer, LandStore.RemainderLayer);
                    for (int i = 0; i < blocks.Count; i++)
                    {
                        string code = "OD-" + (i + 1).ToString("000");
                        LandStore.AddPolygon(doc.Database, tr, blocks[i], LandStore.BlockLayer,
                            new LandMetadata { Kind = "BLOCK", Code = code, UseCode = "CHUA_GAN", ParentCode = "" });
                        for (int h = 0; h < blocks[i].NumInteriorRings; h++)
                        {
                            var hole = new GeometryFactory().CreatePolygon(
                                blocks[i].GetInteriorRingN(h).Coordinates);
                            LandStore.AddPolygon(doc.Database, tr, hole, LandStore.HoleLayer,
                                new LandMetadata { Kind = "HOLE", Code = code + "-H" + (h + 1),
                                    UseCode = "", ParentCode = code });
                        }
                    }
                    LandStore.PromoteBlockDrawOrder(doc.Database, tr);
                    tr.Commit();
                }
                ed.WriteMessage("\nQHLAND: nhận diện " + blocks.Count + " ô đất; tổng diện tích "
                    + blocks.Sum(b => b.Area).ToString("N2") + " m2. Dùng QHZONE để gán chức năng.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        // CAD-07: assign one use code to a block; sync existing child lots.
        [CommandMethod("QHZONE")]
        public void AssignLandUse()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            var selected = SelectBlock(ed);
            if (selected == ObjectId.Null) return;
            var prompt = new PromptStringOptions(
                "\nNhập mã chức năng (ODT, CX, CC, TMDV, HTKT hoặc mã khác KHÔNG DẤU): ")
                { AllowSpaces = false };
            var answer = ed.GetString(prompt);
            if (answer.Status != PromptStatus.OK) return;
            string use = answer.StringResult.Trim().ToUpperInvariant();
            // Quy hoach often uses CN.1, CN.2 ... CN.10 for industrial blocks.
            // Permit an internal dot, but not leading/trailing or repeated dots.
            if (use.Length == 0 || use.Length > 30
                || use.StartsWith(".") || use.EndsWith(".") || use.Contains("..")
                || use.Any(c => !(c >= 'A' && c <= 'Z')
                    && !(c >= '0' && c <= '9') && c != '_' && c != '.'))
            {
                ed.WriteMessage("\nMã chức năng nhận A-Z, 0-9, dấu _ và dấu chấm nội bộ (ví dụ CN.1). ");
                return;
            }
            try
            {
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var block = (CadPolyline)tr.GetObject(selected, OpenMode.ForWrite);
                    var d = LandStore.Read(block);
                    if (d == null || d.Kind != "BLOCK") throw new ArgumentException("Không phải ô đất plugin.");
                    d.UseCode = use;
                    LandStore.Save(doc.Database, tr, block, d);
                    foreach (var lot in LandStore.Polylines(doc.Database, tr, LandStore.LotLayer))
                    {
                        var child = LandStore.Read(lot);
                        if (child == null || child.ParentCode != d.Code) continue;
                        child.UseCode = use;
                        LandStore.Save(doc.Database, tr, lot, child);
                    }
                    tr.Commit();
                }
                ed.WriteMessage("\nĐã gán chức năng " + use + ". Chạy QHLABEL để cập nhật nhãn.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        // CAD-08 v2: exact-width middle lots, irregular corner lots, optional
        // opposite row and internal access road. Unallocated land is retained.
        [CommandMethod("QHLOT")]
        public void SubdivideLot()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            ObjectId selected = SelectBlock(ed);
            if (selected == ObjectId.Null) return;
            var pick = ed.GetPoint("\nChọn một điểm trên CẠNH MẶT TIỀN (cạnh thẳng) của ô đất: ");
            if (pick.Status != PromptStatus.OK) return;
            double target, depth, minArea, roadWidth = 0;
            if (!ReadPositive(ed, "\nMặt tiền mục tiêu mỗi lô (m)", 8, out target)
                || !ReadPositive(ed, "\nChiều sâu lô (m)", 20, out depth)
                || !ReadPositive(ed, "\nDiện tích tối thiểu CẢNH BÁO (m2)", 80, out minArea)) return;
            bool twoRows, accessRoad = false;
            if (!AskYesNo(ed,
                "\nChia thành HAI DÃY quay lưng vào nhau? [Yes/No] <No>: ", out twoRows)) return;
            if (twoRows && !AskYesNo(ed,
                "\nGiữa hai dãy có ĐƯỜNG NỘI BỘ? [Yes/No] <No>: ", out accessRoad)) return;
            if (accessRoad && !ReadPositive(ed, "\nBề rộng đường nội bộ (m)", 6, out roadWidth)) return;

            try
            {
                NtsPolygon blockPolygon;
                LandMetadata meta;
                Coordinate frontA, frontB;
                bool hasLots;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var block = (CadPolyline)tr.GetObject(selected, OpenMode.ForRead);
                    blockPolygon = LandStore.ReconstructBlock(doc.Database, tr, block, Settings.CurveTolerance);
                    meta = LandStore.Read(block);
                    FindFrontage(block, pick.Value, out frontA, out frontB);
                    hasLots = new[] { LandStore.LotLayer, LandStore.AccessRoadLayer,
                        LandStore.RemainderLayer }.Any(layer =>
                            LandStore.Polylines(doc.Database, tr, layer).Any(p => {
                                var m = LandStore.Read(p); return m != null && m.ParentCode == meta.Code;
                            }));
                }
                var plan = LandGeometry.SplitByWidthAndDepth(blockPolygon, frontA, frontB,
                    new LotSplitOptions { Frontage = target, Depth = depth,
                        TwoRows = twoRows, AccessRoad = accessRoad,
                        AccessRoadWidth = roadWidth, MinArea = minArea });
                if (hasLots && !Confirm(ed,
                    "\nÔ này đã có lô. Thay toàn bộ lô của ô này? [Replace/Cancel] <Cancel>: ",
                    "Replace", "Cancel")) return;

                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    LandStore.EnsureLayers(doc.Database, tr);
                    LandStore.ClearLots(doc.Database, tr, meta.Code);
                    int lotId = 0, cornerId = 0;
                    foreach (var cell in plan.Lots)
                    {
                        string code = meta.Code + (cell.Corner
                            ? "-G" + (++cornerId).ToString("000")
                            : "-L" + (++lotId).ToString("000"));
                        LandStore.AddPolygon(doc.Database, tr, cell.Shape, LandStore.LotLayer,
                            new LandMetadata { Kind = "LOT",
                                Code = code,
                                ParentCode = meta.Code, UseCode = meta.UseCode });
                    }
                    for (int i = 0; i < plan.InternalRoads.Count; i++)
                        LandStore.AddPolygon(doc.Database, tr, plan.InternalRoads[i],
                            LandStore.AccessRoadLayer,
                            new LandMetadata { Kind = "ROAD",
                                Code = meta.Code + "-GT" + (i + 1).ToString("00"),
                                ParentCode = meta.Code, UseCode = "GT" });
                    for (int i = 0; i < plan.Remainders.Count; i++)
                        LandStore.AddPolygon(doc.Database, tr, plan.Remainders[i],
                            LandStore.RemainderLayer,
                            new LandMetadata { Kind = "REMAINDER",
                                Code = meta.Code + "-DU" + (i + 1).ToString("00"),
                                ParentCode = meta.Code, UseCode = "CHUA_CHIA" });
                    LandStore.PromoteBlockDrawOrder(doc.Database, tr);
                    tr.Commit();
                }
                ed.WriteMessage("\nQHLOT: tạo " + plan.Lots.Count + " lô thuộc " + meta.Code
                    + ", diện tích " + plan.Lots.Sum(p => p.Shape.Area).ToString("N2")
                    + " m2; đường nội bộ " + plan.InternalRoads.Sum(p => p.Area).ToString("N2")
                    + " m2; chưa chia " + plan.Remainders.Sum(p => p.Area).ToString("N2") + " m2.");
                foreach (var warning in plan.Warnings.Take(15)) ed.WriteMessage("\n[CẢNH BÁO] " + warning);
                ed.WriteMessage("\nChạy QHLABEL, QHAUDIT để kiểm tra.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        // CAD-09 v2: editable AttributeReference circles, like the supplied DWG image.
        [CommandMethod("QHLABEL")]
        public void LabelLandAndLots()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            try
            {
                var filter = new PromptKeywordOptions(
                    "\nTao nhan o, lo hay ca hai? [Blocks/Lots/Both] <Both>: ");
                filter.Keywords.Add("Blocks"); filter.Keywords.Add("Lots");
                filter.Keywords.Add("Both"); filter.Keywords.Default = "Both";
                var choice = ed.GetKeywords(filter);
                if (choice.Status != PromptStatus.OK) return;
                string[] layers = choice.StringResult == "Lots"
                    ? new[] { LandStore.LotLayer }
                    : choice.StringResult == "Both"
                        ? new[] { LandStore.BlockLayer, LandStore.LotLayer }
                    : new[] { LandStore.BlockLayer };
                // Import user-supplied DXF blocks before starting the DWG
                // label transaction. If DxfIn fails, old labels remain intact.
                LandLabelBlocks.EnsureDefinitions(doc.Database);
                int count = 0;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    LandStore.EnsureLayers(doc.Database, tr);
                    var existingLabels = LandLabelBlocks.ReadAll(doc.Database, tr);
                    var existingDiameters = LandLabelBlocks.ReadExistingDiameters(doc.Database, tr);
                    var targetCodes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach (var layer in layers)
                        foreach (var poly in LandStore.Polylines(doc.Database, tr, layer))
                        {
                            var m = LandStore.Read(poly);
                            if (m != null) targetCodes.Add(m.Code);
                        }
                    LandLabelBlocks.ClearForCodes(doc.Database, tr, targetCodes);
                    foreach (var layer in layers)
                        foreach (var poly in LandStore.Polylines(doc.Database, tr, layer))
                        {
                            var meta = LandStore.Read(poly);
                            if (meta == null) continue;
                            NtsPolygon shape = layer == LandStore.BlockLayer
                                ? LandStore.ReconstructBlock(doc.Database, tr, poly, Settings.CurveTolerance)
                                : CadBridge.ToPolygon(poly, Settings.CurveTolerance);
                            var inside = shape.InteriorPoint.Coordinate;
                            Dictionary<string, string> old;
                            existingLabels.TryGetValue(meta.Code, out old);
                            double previousDiameter;
                            double? originalDiameter = existingDiameters.TryGetValue(meta.Code,
                                out previousDiameter) ? (double?)previousDiameter : null;
                            LandLabelBlocks.Insert(doc.Database, tr, meta,
                                new Point3d(inside.X, inside.Y, 0), shape.Area, old, originalDiameter);
                            count++;
                        }
                    tr.Commit();
                }
                ed.WriteMessage("\nQHLABEL: tạo " + count + " block attribute."
                    + " Dùng EATTEDIT để chỉnh mật độ, tầng cao, FAR; QHEXPORT đọc các thuộc tính này."
                    + " Dùng QHLABELSCALE / QHSCALEO / QHSCALELO để đổi đường kính ký hiệu (m).");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        [CommandMethod("QHLABELSCALE")]
        public void SetLabelDiameter()
        {
            var ed = AcadApp.DocumentManager.MdiActiveDocument.Editor;
            var opt = new PromptKeywordOptions(
                "\nChọn loại nhãn cần đổi tỷ lệ [ODat/LoDat/CaHai] <ODat>: ");
            opt.Keywords.Add("ODat"); opt.Keywords.Add("LoDat"); opt.Keywords.Add("CaHai");
            opt.Keywords.Default = "ODat";
            var selected = ed.GetKeywords(opt);
            if (selected.Status != PromptStatus.OK) return;
            string choice = selected.StringResult;
            SetLabelDiameterFor(choice == "ODat" || choice == "CaHai",
                choice == "LoDat" || choice == "CaHai");
        }

        [CommandMethod("QHSCALEO")]
        public void ScaleBlockLabels() { SetLabelDiameterFor(true, false); }

        [CommandMethod("QHSCALELO")]
        public void ScaleLotLabels() { SetLabelDiameterFor(false, true); }

        private static void SetLabelDiameterFor(bool blocks, bool lots)
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            double diameterBlock = LandLabelBlocks.BlockSymbolDiameterMeters;
            double diameterLot = LandLabelBlocks.LotSymbolDiameterMeters;
            if (blocks && !ReadPositive(ed, "\nĐường kính nhãn Ô ĐẤT (m)",
                diameterBlock, out diameterBlock)) return;
            if (lots && !ReadPositive(ed, "\nĐường kính nhãn LÔ ĐẤT (m)",
                diameterLot, out diameterLot)) return;
            if ((blocks && (diameterBlock < 0.5 || diameterBlock > 100))
                || (lots && (diameterLot < 0.5 || diameterLot > 100)))
            { ed.WriteMessage("\nĐường kính hợp lệ từ 0,5 đến 100 m."); return; }
            try
            {
                int updated = 0;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    if (blocks) updated += LandLabelBlocks.RescaleAll(
                        doc.Database, tr, diameterBlock, false);
                    if (lots) updated += LandLabelBlocks.RescaleAll(
                        doc.Database, tr, diameterLot, true);
                    tr.Commit();
                }
                if (blocks) LandLabelBlocks.BlockSymbolDiameterMeters = diameterBlock;
                if (lots) LandLabelBlocks.LotSymbolDiameterMeters = diameterLot;
                ed.WriteMessage("\nĐã cập nhật " + updated + " nhãn. Ô đất: "
                    + LandLabelBlocks.BlockSymbolDiameterMeters.ToString("0.##")
                    + " m; lô đất: " + LandLabelBlocks.LotSymbolDiameterMeters.ToString("0.##")
                    + " m. Không cần chạy lại QHLABEL chỉ để đổi tỷ lệ.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        // CAD-10: reconcile redline + blocks against site; check lot sums.
        [CommandMethod("QHAUDIT")]
        public void AuditLandGeometry()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            try
            {
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var boundary = CadBridge.ToPolygon(
                        CadBridge.ReadBoundary(doc.Database, tr), Settings.CurveTolerance);
                    var roads = CadBridge.RegisteredRoads(doc.Database, tr, Settings.CurveTolerance);
                    var road = new RoadGeometry().Build(boundary, roads, Settings);
                    var labelValues = LandLabelBlocks.ReadAll(doc.Database, tr);
                    var blocks = LandStore.Polylines(doc.Database, tr, LandStore.BlockLayer);
                    var lots = LandStore.Polylines(doc.Database, tr, LandStore.LotLayer);
                    var innerRoads = LandStore.Polylines(doc.Database, tr, LandStore.AccessRoadLayer);
                    var remainders = LandStore.Polylines(doc.Database, tr, LandStore.RemainderLayer);
                    double sumLand = 0;
                    int issues = 0;
                    var codes = new HashSet<string>();
                    var blockShapes = new Dictionary<string, NtsPolygon>();
                    var lotShapes = new List<Tuple<LandMetadata, NtsPolygon>>();
                    foreach (var p in blocks)
                    {
                        var m = LandStore.Read(p);
                        if (m == null || m.Kind != "BLOCK" || !codes.Add(m.Code))
                        { issues++; ed.WriteMessage("\n[SAI] Ô đất không có mã hợp lệ hoặc trùng mã."); continue; }
                        try
                        {
                            var shape = LandStore.ReconstructBlock(doc.Database, tr, p, Settings.CurveTolerance);
                            sumLand += shape.Area;
                            blockShapes.Add(m.Code, shape);
                            double attrArea;
                            if (TryNumber(LandLabelBlocks.Get(labelValues, m.Code, "AREA_M2", ""), out attrArea)
                                && Math.Abs(attrArea - shape.Area) > 0.1)
                            { issues++; ed.WriteMessage("\n[SAI] Diện tích block attribute lệch hình học ô " + m.Code); }
                        }
                        catch (System.Exception ex)
                        {
                            issues++;
                            ed.WriteMessage("\n[SAI] Ô " + m.Code + ": " + ex.Message);
                        }
                    }
                    foreach (var p in lots.Concat(innerRoads).Concat(remainders))
                    {
                        var m = LandStore.Read(p);
                        if (m == null || !new[] { "LOT", "ROAD", "REMAINDER" }.Contains(m.Kind)
                            || !codes.Add(m.Code))
                        { issues++; ed.WriteMessage("\n[SAI] Lô/đường/dư không có mã hợp lệ hoặc trùng mã."); continue; }
                        try
                        {
                            var shape = CadBridge.ToPolygon(p, Settings.CurveTolerance);
                            lotShapes.Add(Tuple.Create(m, shape));
                            double attrArea;
                            if (TryNumber(LandLabelBlocks.Get(labelValues, m.Code, "AREA_M2", ""), out attrArea)
                                && Math.Abs(attrArea - shape.Area) > 0.1)
                            { issues++; ed.WriteMessage("\n[SAI] Diện tích block attribute lệch hình học lô " + m.Code); }
                            NtsPolygon parent;
                            if (!blockShapes.TryGetValue(m.ParentCode, out parent))
                            { issues++; ed.WriteMessage("\n[SAI] Lô " + m.Code + " không có ô mẹ."); }
                            else if (shape.Difference(parent).Area > 0.05)
                            { issues++; ed.WriteMessage("\n[SAI] Lô " + m.Code + " vượt ranh ô mẹ."); }
                        }
                        catch (System.Exception ex)
                        {
                            issues++;
                            ed.WriteMessage("\n[SAI] Lô " + m.Code + ": " + ex.Message);
                        }
                    }
                    foreach (var pair in blockShapes)
                    {
                        double childrenArea = lotShapes.Where(l => l.Item1.ParentCode == pair.Key)
                            .Sum(l => l.Item2.Area);
                        if (childrenArea > 0 && Math.Abs(childrenArea - pair.Value.Area) > 0.05)
                        { issues++; ed.WriteMessage("\n[SAI] Tổng lô + đường nội bộ + đất dư không khớp ô " + pair.Key); }
                    }
                    // Bounding-box filter avoids expensive geometry checks for distant lots.
                    for (int i = 0; i < lotShapes.Count; i++)
                        for (int j = i + 1; j < lotShapes.Count; j++)
                            if (lotShapes[i].Item2.EnvelopeInternal.Intersects(
                                lotShapes[j].Item2.EnvelopeInternal)
                                && lotShapes[i].Item2.Intersection(lotShapes[j].Item2).Area > 0.05)
                            {
                                issues++;
                                ed.WriteMessage("\n[SAI] Chồng lấn lô " + lotShapes[i].Item1.Code
                                    + " và " + lotShapes[j].Item1.Code);
                            }
                    var uniqueBlocks = blockShapes.ToList();
                    for (int i = 0; i < uniqueBlocks.Count; i++)
                        for (int j = i + 1; j < uniqueBlocks.Count; j++)
                            if (uniqueBlocks[i].Value.EnvelopeInternal.Intersects(
                                uniqueBlocks[j].Value.EnvelopeInternal)
                                && uniqueBlocks[i].Value.Intersection(uniqueBlocks[j].Value).Area > 0.05)
                            { issues++; ed.WriteMessage("\n[SAI] Hai ô đất chồng lấn."); }
                    double delta = boundary.Area - road.RedLine.Area - sumLand;
                    if (Math.Abs(delta) > Math.Max(0.1, boundary.Area * 0.00001))
                    { issues++; ed.WriteMessage("\n[SAI] Chênh lệch giữa diện tích ranh, đường và ô đất."); }
                    ed.WriteMessage("\nQHAUDIT: ranh " + boundary.Area.ToString("N2")
                        + " m2; đường " + road.RedLine.Area.ToString("N2")
                        + " m2; ô đất " + sumLand.ToString("N2")
                        + " m2; sai lệch " + delta.ToString("N3") + " m2.");
                    ed.WriteMessage("\nSố ô " + blocks.Count + ", số lô " + lots.Count
                        + ", vùng đường nội bộ " + innerRoads.Count
                        + ", vùng chưa chia " + remainders.Count
                        + ", vấn đề phát hiện " + issues + ". "
                        + (issues == 0 ? "KIỂM TRA HÌNH HỌC SƠ BỘ ĐẠT."
                            : "CẦN SỬA TRƯỚC KHI XUẤT HỒ SƠ."));
                }
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        // CAD-11: CAD summary table and real .xlsx workbook, numeric cells typed.
        [CommandMethod("QHEXPORT")]
        public void ExportPlanningStatistics()
        {
            var doc = AcadApp.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;
            try
            {
                var detail = new List<object[]> {
                    new object[] { "Loại", "Mã", "Ô mẹ", "Chức năng", "Mật độ XD (%)",
                        "Tầng cao tối đa", "Diện tích (m2)", "Diện tích (ha)", "Hệ số SDĐ (lần)" }
                };
                var roadDetail = new List<object[]> { new object[] {
                    "Mặt cắt", "Tên tuyến", "Handle", "Vỉa trái (m)", "Lòng trái (m)",
                    "Dải giữa (m)", "Lòng phải (m)", "Vỉa phải (m)", "Lộ giới (m)" }
                };
                var areas = new SortedDictionary<string, double>();
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    var labels = LandLabelBlocks.ReadAll(doc.Database, tr);
                    var roads = CadBridge.RegisteredRoads(doc.Database, tr, Settings.CurveTolerance);
                    foreach (var group in RoadSections.Group(roads))
                        foreach (var r in group.Roads)
                            roadDetail.Add(new object[] {
                                group.Id, r.Profile.RoadName, r.Handle,
                                r.Profile.SidewalkLeft, r.Profile.LaneLeft, r.Profile.Median,
                                r.Profile.LaneRight, r.Profile.SidewalkRight, r.Profile.RightOfWay
                            });
                    foreach (var block in LandStore.Polylines(doc.Database, tr, LandStore.BlockLayer))
                    {
                        var m = LandStore.Read(block);
                        if (m == null) continue;
                        double geometric = LandStore.ReconstructBlock(doc.Database, tr, block, Settings.CurveTolerance).Area;
                        double area = AttributeArea(labels, m.Code, geometric);
                        detail.Add(ReportRow("Ô đất", m, area, labels));
                        if (!areas.ContainsKey(m.UseCode)) areas[m.UseCode] = 0;
                        areas[m.UseCode] += area;
                    }
                    foreach (var lot in LandStore.Polylines(doc.Database, tr, LandStore.LotLayer))
                    {
                        var m = LandStore.Read(lot);
                        if (m == null) continue;
                        double geometric = CadBridge.ToPolygon(lot, Settings.CurveTolerance).Area;
                        detail.Add(ReportRow("Lô", m, AttributeArea(labels, m.Code, geometric), labels));
                    }
                    foreach (string layer in new[] { LandStore.AccessRoadLayer, LandStore.RemainderLayer })
                        foreach (var poly in LandStore.Polylines(doc.Database, tr, layer))
                        {
                            var m = LandStore.Read(poly);
                            if (m == null) continue;
                            double area = CadBridge.ToPolygon(poly, Settings.CurveTolerance).Area;
                            detail.Add(ReportRow(layer == LandStore.AccessRoadLayer
                                ? "Đường nội bộ" : "Đất chưa chia", m, area, labels));
                        }
                }
                if (detail.Count == 1 && roadDetail.Count == 1)
                    throw new InvalidOperationException("Chưa có tim QHROADS hoặc ô/lô đất để thống kê.");
                var summary = new List<object[]> { new object[] { "Chức năng", "Diện tích (m2)", "Diện tích (ha)" } };
                foreach (var pair in areas)
                    summary.Add(new object[] { pair.Key, pair.Value, pair.Value / 10000.0 });
                summary.Add(new object[] { "TỔNG ĐẤT KHÔNG GỒM ĐƯỜNG", areas.Values.Sum(),
                    areas.Values.Sum() / 10000.0 });

                var option = new PromptSaveFileOptions("\nChọn nơi lưu Excel thống kê QH (.xlsx): ")
                    { Filter = "Excel workbook (*.xlsx)|*.xlsx" };
                var path = ed.GetFileNameForSave(option);
                if (path.Status != PromptStatus.OK) return;
                string filename = Path.ChangeExtension(path.StringResult, ".xlsx");
                if (File.Exists(filename) && !Confirm(ed,
                    "\nFile đã tồn tại. Ghi đè? [Overwrite/Cancel] <Cancel>: ",
                    "Overwrite", "Cancel")) return;
                ExcelWriter.Write(filename, detail, summary, roadDetail);
                ed.WriteMessage("\nĐã xuất Excel: " + filename);

                var pick = ed.GetPoint("\nChọn điểm đặt bảng thống kê CAD (Esc để bỏ qua): ");
                if (pick.Status != PromptStatus.OK) return;
                using (var tr = doc.Database.TransactionManager.StartTransaction())
                {
                    LandStore.EnsureLayers(doc.Database, tr);
                    LandStore.ClearManaged(doc.Database, tr, LandStore.TableLayer);
                    var tab = new Table { TableStyle = doc.Database.Tablestyle,
                        Position = pick.Value, Layer = LandStore.TableLayer };
                    tab.SetSize(summary.Count, 3);
                    tab.SetRowHeight(4);
                    tab.SetColumnWidth(27);
                    for (int i = 0; i < summary.Count; i++)
                        for (int j = 0; j < 3; j++)
                            tab.Cells[i, j].TextString = summary[i][j] is double
                                ? ((double)summary[i][j]).ToString("N2", CultureInfo.InvariantCulture)
                                : Convert.ToString(summary[i][j], CultureInfo.InvariantCulture);
                    tab.GenerateLayout();
                    var ms = CadBridge.GetModelSpace(doc.Database, tr);
                    ms.UpgradeOpen(); ms.AppendEntity(tab); tr.AddNewlyCreatedDBObject(tab, true);
                    tr.Commit();
                }
                ed.WriteMessage("\nĐã đặt bảng tổng hợp trên CAD. Tổng " + areas.Values.Sum().ToString("N2") + " m2.");
            }
            catch (System.Exception ex) { Report(ed, ex); }
        }

        private static object[] ReportRow(string kind, LandMetadata m, double area,
            Dictionary<string, Dictionary<string, string>> labels)
        {
            bool simple = LandLabelBlocks.SimpleUse(m.UseCode)
                || m.Kind == "ROAD" || m.Kind == "REMAINDER";
            string displayCode = LandLabelBlocks.Get(labels, m.Code, "LOT_CODE", m.Code);
            object density = simple ? "" : NumericCell(
                LandLabelBlocks.Get(labels, m.Code, "DENSITY", m.DensityPercent));
            object floors = simple ? "" : NumericCell(
                LandLabelBlocks.Get(labels, m.Code, "FLOORS", m.MaxFloors));
            object far = simple ? "" : NumericCell(
                LandLabelBlocks.Get(labels, m.Code, "FAR", m.Far));
            return new object[] { kind, displayCode, m.ParentCode, m.UseCode,
                density, floors, area, area / 10000.0, far };
        }

        private static double AttributeArea(
            Dictionary<string, Dictionary<string, string>> labels,
            string code, double fallback)
        {
            string text = LandLabelBlocks.Get(labels, code, "AREA_M2", "");
            double number;
            return TryNumber(text, out number) && number > 0 ? number : fallback;
        }

        private static object NumericCell(string value)
        {
            double number;
            return TryNumber(value, out number) ? (object)number : (object)(value ?? "");
        }

        private static bool TryNumber(string s, out double value)
        {
            string text = (s ?? "").Trim();
            var vi = CultureInfo.GetCultureInfo("vi-VN");
            var invariant = CultureInfo.InvariantCulture;
            var first = text.LastIndexOf(',') > text.LastIndexOf('.') ? vi : invariant;
            var second = first == vi ? invariant : vi;
            if (double.TryParse(text, NumberStyles.Float | NumberStyles.AllowThousands,
                first, out value)) return true;
            return double.TryParse(text, NumberStyles.Float | NumberStyles.AllowThousands,
                second, out value);
        }

        private static ObjectId SelectBlock(Editor ed)
        {
            var opt = new PromptEntityOptions("\nChọn ô đất trên layer QH_O_DAT: ");
            opt.SetRejectMessage("\nChỉ chọn LWPOLYLINE ô đất.");
            opt.AddAllowedClass(typeof(CadPolyline), true);
            var answer = ed.GetEntity(opt);
            if (answer.Status != PromptStatus.OK) return ObjectId.Null;
            using (var tr = ed.Document.Database.TransactionManager.StartTransaction())
            {
                var p = (CadPolyline)tr.GetObject(answer.ObjectId, OpenMode.ForRead);
                var meta = LandStore.Read(p);
                if (p.Layer != LandStore.BlockLayer || meta == null || meta.Kind != "BLOCK")
                {
                    ed.WriteMessage("\nPhải chọn ô đất do QHLAND tạo ra.");
                    return ObjectId.Null;
                }
            }
            return answer.ObjectId;
        }

        private static void FindFrontage(CadPolyline p, Point3d pick,
            out Coordinate a, out Coordinate b)
        {
            double best = double.MaxValue;
            a = null; b = null;
            int bestIndex = -1;
            for (int i = 0; i < p.NumberOfVertices; i++)
            {
                if (Math.Abs(p.GetBulgeAt(i)) > 1e-8) continue;
                var segmentStart = p.GetPoint2dAt(i);
                var segmentEnd = p.GetPoint2dAt((i + 1) % p.NumberOfVertices);
                var segment = new NetTopologySuite.Geometries.LineSegment(
                    new Coordinate(segmentStart.X, segmentStart.Y),
                    new Coordinate(segmentEnd.X, segmentEnd.Y));
                double distance = segment.Distance(new Coordinate(pick.X, pick.Y));
                if (distance < best)
                {
                    best = distance;
                    bestIndex = i;
                    a = segment.P0;
                    b = segment.P1;
                }
            }
            if (a == null || b == null || best > 10)
                throw new ArgumentException("Không tìm thấy cạnh mặt tiền THẲNG trong phạm vi 10 m từ điểm chọn.");

            // NTS operations may split one long straight frontage into many
            // collinear segments. Merge neighboring segments for the user's pick.
            int n = p.NumberOfVertices;
            int start = bestIndex, end = (bestIndex + 1) % n;
            for (int guard = 0; guard < n - 2; guard++)
            {
                int previous = (start + n - 1) % n;
                if (previous == end || Math.Abs(p.GetBulgeAt(previous)) > 1e-8
                    || !StraightContinuation(p.GetPoint2dAt(previous),
                        p.GetPoint2dAt(start), p.GetPoint2dAt(end))) break;
                start = previous;
            }
            for (int guard = 0; guard < n - 2; guard++)
            {
                int next = (end + 1) % n;
                if (next == start || Math.Abs(p.GetBulgeAt(end)) > 1e-8
                    || !StraightContinuation(p.GetPoint2dAt(start),
                        p.GetPoint2dAt(end), p.GetPoint2dAt(next))) break;
                end = next;
            }
            var startPoint = p.GetPoint2dAt(start);
            var endPoint = p.GetPoint2dAt(end);
            a = new Coordinate(startPoint.X, startPoint.Y);
            b = new Coordinate(endPoint.X, endPoint.Y);
        }

        private static bool StraightContinuation(Point2d before, Point2d middle, Point2d after)
        {
            double ax = middle.X - before.X, ay = middle.Y - before.Y;
            double bx = after.X - middle.X, by = after.Y - middle.Y;
            double lenA = Math.Sqrt(ax * ax + ay * ay);
            double lenB = Math.Sqrt(bx * bx + by * by);
            if (lenA < 1e-8 || lenB < 1e-8) return false;
            double perpendicularError = Math.Abs(ax * by - ay * bx) / Math.Max(lenA, lenB);
            return perpendicularError < 0.01 && ax * bx + ay * by > 0;
        }

        private static bool ReadPositive(Editor ed, string label, double defaultValue, out double value)
        {
            var options = new PromptDoubleOptions(label + " <" + defaultValue + ">: ")
                { AllowNegative = false, AllowZero = false,
                    DefaultValue = defaultValue, UseDefaultValue = true };
            var result = ed.GetDouble(options);
            value = result.Status == PromptStatus.OK ? result.Value : defaultValue;
            return result.Status == PromptStatus.OK;
        }

        private static bool Confirm(Editor ed, string message, string yes, string no)
        {
            var opt = new PromptKeywordOptions(message);
            opt.Keywords.Add(yes); opt.Keywords.Add(no); opt.Keywords.Default = no;
            var result = ed.GetKeywords(opt);
            return result.Status == PromptStatus.OK && result.StringResult == yes;
        }

        private static bool AskYesNo(Editor ed, string message, out bool value)
        {
            value = false;
            var opt = new PromptKeywordOptions(message);
            opt.Keywords.Add("Yes"); opt.Keywords.Add("No");
            opt.Keywords.Default = "No";
            var result = ed.GetKeywords(opt);
            if (result.Status != PromptStatus.OK) return false;
            value = result.StringResult == "Yes";
            return true;
        }
    }
}
